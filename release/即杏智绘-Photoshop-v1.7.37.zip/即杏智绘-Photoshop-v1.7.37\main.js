"use strict";

const photoshop = require("photoshop");
const uxp = require("uxp");
const { API_CONFIG, UPDATE_CONFIG, MODEL_CONFIGS } = require("./lib/constants.js");
const {
  clampBounds,
  resolveOutputSize,
  computeCoverCrop,
  extractPricingSnapshot,
  base64ToArrayBuffer,
  detectImageType,
  extractImageCandidate,
  extractHistoryRecords,
  historyRecordMetadata,
  extractHistoryImageCandidate,
  historyRecordKey,
  extractErrorMessage,
  exactArrayBuffer,
  utf8BytesToString,
  normalizeRgbColor,
  recolorSelectedPixels,
  analyzeColorRegion,
  transferColorRegion
} = require("./lib/utils.js");

const { app, core, imaging, action, constants } = photoshop;
const { localFileSystem, formats, secureStorage } = uxp.storage;
const shell = uxp.shell;

const API_KEY_STORAGE = "llai_selection_editor_api_key";
const SETTINGS_STORAGE = "llai_selection_editor_settings_v2";
const PRICING_STORAGE = "llai_selection_editor_pricing_v2";
const UPDATE_CHECK_STORAGE = "llai_selection_editor_update_check_v1";
const SETTINGS_SCHEMA_VERSION = 5;
const MAX_REFERENCES = 10;
const MAX_RESULTS = 5;
const MAX_FAVORITE_PROMPTS = 8;
const MAX_ACTIVE_JOBS = 4;
const PRICING_SIZES = Object.freeze(["1K", "2K", "4K"]);
const PRICING_REFRESH_MS = 2 * 60 * 1000;
const PRICING_TIMEOUT_MS = 12 * 1000;
const PRICE_BYPASS_CONFIRM_MS = 60 * 1000;
const HISTORY_REQUEST_TIMEOUT_MS = 20 * 1000;
const HISTORY_RECOVERY_POLL_MS = 10 * 1000;
const HISTORY_RECOVERY_TIMEOUT_MS = 2 * 60 * 1000;
const HISTORY_RECORD_MATCH_MAX_LAG_MS = 20 * 60 * 1000;
const HISTORY_PENDING_RETENTION_MS = 3 * 24 * 60 * 60 * 1000;
const GENERATION_PROGRESS_TICK_MS = 560;
const GENERATION_PROGRESS_COMPLETION_MS = 620;
const PERSISTENT_HISTORY_SCHEMA_VERSION = 1;
const PERSISTENT_HISTORY_FOLDER = "generated-history";
const PERSISTENT_HISTORY_INDEX = "history-index.json";
const COLOR_SAMPLE_POLL_MS = 250;
const COLOR_SAMPLE_TIMEOUT_MS = 60 * 1000;
const COLOR_REPLACE_MAX_PIXELS = 12 * 1024 * 1024;
const COLOR_REPLACE_TOLERANCE = 0.55;
const PALETTE_MATCH_MAX_PIXELS = 6 * 1024 * 1024;
const LOCAL_EDIT_MODES = Object.freeze(["general", "head", "upper", "pants", "outfit"]);

const state = {
  references: [],
  targetSnapshot: null,
  results: [],
  selectedResultId: null,
  resultSequence: 0,
  favoritePrompts: [],
  apiKey: "",
  running: false,
  preparingJob: false,
  capturing: false,
  inserting: false,
  generationJobs: [],
  generationJobSequence: 0,
  selectionRevision: 0,
  referenceSequence: 0,
  resumeAfterKey: false,
  pricingRunConfirmation: null,
  pendingHistoryTasks: [],
  loadingPersistentHistory: false,
  recoveringPendingHistory: false,
  pendingHistoryRecoveryStopRequested: false,
  historyPersistenceError: "",
  paletteProcessing: false,
  paletteSample: null,
  checkingUpdate: false,
  updateAvailable: null,
  updateLastCheckedAt: 0,
  pricing: {
    prices: { "1K": null, "2K": null, "4K": null },
    enabled: { "1K": false, "2K": false, "4K": false },
    fetchedAt: 0,
    serviceUpdatedAt: "",
    source: "none",
    changes: {},
    unacknowledgedIncreases: {},
    error: "",
    checking: false
  }
};

const elements = {};
const islandSelectControls = new Map();
let islandSelectDocumentListenerAttached = false;
let pricingRefreshTimer = null;
let pricingRequest = null;
let fitNoticeBaseText = "";
let lastPromptSelection = null;
let promptSelectionCaptureTimer = null;
let promptHasFocus = false;
let promptPointerActive = false;
let promptSelectionFreezeUntil = 0;
let promptCaretMirror = null;
let referenceLayoutTimer = null;
let referenceListWidth = 0;
let referenceTileSize = 80;
let notificationLayoutTimer = null;
let generationProgressTimer = null;
let statusHideTimer = null;
let persistentHistoryFolderPromise = null;
let historyPersistenceQueue = Promise.resolve();
let pendingHistoryRecoveryController = null;
let colorSamplingTimer = null;
let colorSamplingInitialHex = "";
let colorSamplingStartedAt = 0;

function byId(id) {
  return document.getElementById(id);
}

function normalizeModelIdentifier(value) {
  return String(value || "").trim().toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]+/g, "");
}

function getModelConfig(modelName) {
  const direct = MODEL_CONFIGS[String(modelName || "")];
  if (direct) return direct;
  const normalized = normalizeModelIdentifier(modelName);
  if (normalized) {
    const match = Object.values(MODEL_CONFIGS).find((config) => (
      [config.apiModel, config.pricingModel].concat(config.aliases || [])
        .some((alias) => normalizeModelIdentifier(alias) === normalized)
    ));
    if (match) return match;
  }
  return MODEL_CONFIGS[API_CONFIG.model];
}

function getSelectedModelConfig() {
  const selected = String(elements.modelChannel && elements.modelChannel.value || API_CONFIG.model);
  return getModelConfig(selected);
}

function selectedApiModel() {
  return getSelectedModelConfig().apiModel;
}

function cacheElements() {
  const ids = [
    "pluginVersion",
    "captureSelection", "captureLayer", "captureCanvas", "clearReferences",
    "referenceStrip", "referenceList", "referenceAdd", "referenceEmptyHint", "referenceCount",
    "precisionPlacement", "targetSummary", "localEditMode", "prompt", "promptCount", "modelChannel", "aspectRatio", "resolution", "generationCount",
    "resolvedDimensions", "fitNotice", "run", "stop", "insert", "resultEmpty", "resultImage",
    "notificationLayer", "status", "statusIcon", "statusTitle", "statusDetail", "statusClose",
    "keyOverlay", "keyInput",
    "keyError", "cancelKey", "saveKey", "promptLibrary", "favoritePrompt",
    "resultHistory", "resultHistoryCount", "generationQueue",
    "capturePaletteSample", "paletteSampleSwatch", "paletteSampleLabel",
    "applyPaletteMatch", "clearPaletteSample"
  ];
  for (const id of ids) elements[id] = byId(id);
}

function getPromptValue() {
  return String(elements.prompt && elements.prompt.value || "").replace(/\r\n?/g, "\n");
}

function setPromptValue(value) {
  if (!elements.prompt) return;
  elements.prompt.value = String(value || "").slice(0, 20000);
  if (lastPromptSelection) {
    const valueLength = getPromptValue().length;
    const start = Math.max(0, Math.min(valueLength, lastPromptSelection.start));
    lastPromptSelection = {
      start,
      end: Math.max(start, Math.min(valueLength, lastPromptSelection.end))
    };
  }
}

function getKeyInputValue() {
  return String(elements.keyInput && elements.keyInput.value || "").replace(/\s+/g, "");
}

function setKeyInputValue(value) {
  if (elements.keyInput) elements.keyInput.value = String(value || "");
}

function isPromptDisabled() {
  return !elements.prompt || Boolean(elements.prompt.disabled);
}

function setPromptDisabled(disabled) {
  if (!elements.prompt) return;
  const locked = Boolean(disabled);
  if (Boolean(elements.prompt.disabled) !== locked) elements.prompt.disabled = locked;
}

function readPromptSelection() {
  const valueLength = getPromptValue().length;
  const rawStart = elements.prompt && elements.prompt.selectionStart;
  const rawEnd = elements.prompt && elements.prompt.selectionEnd;
  if (typeof rawStart !== "number" || typeof rawEnd !== "number") {
    return null;
  }
  return {
    start: Math.max(0, Math.min(valueLength, rawStart)),
    end: Math.max(0, Math.min(valueLength, rawEnd))
  };
}

function rememberPromptSelection() {
  const selection = readPromptSelection();
  if (selection) lastPromptSelection = selection;
  return selection;
}

function ensurePromptCaretMirror() {
  if (promptCaretMirror && promptCaretMirror.parentNode) return promptCaretMirror;
  const mirror = document.createElement("div");
  mirror.className = "prompt-caret-mirror";
  mirror.setAttribute("aria-hidden", "true");
  document.body.appendChild(mirror);
  promptCaretMirror = mirror;
  return mirror;
}

function updatePromptCaretMirrorLayout(mirror) {
  const editor = elements.prompt;
  if (!mirror || !editor) return { lineHeight: 18, paddingTop: 9, width: 1 };
  let computed = null;
  try {
    computed = typeof window.getComputedStyle === "function"
      ? window.getComputedStyle(editor)
      : null;
  } catch (_) {
    computed = null;
  }
  const editorWidth = Math.max(
    1,
    Number(editor.clientWidth) ||
    Number(editor.getBoundingClientRect && editor.getBoundingClientRect().width) ||
    1
  );
  const lineHeight = Math.max(1, parseFloat(computed && computed.lineHeight) || 18);
  const paddingTop = Math.max(0, parseFloat(computed && computed.paddingTop) || 9);
  mirror.style.width = `${editorWidth}px`;
  mirror.style.fontFamily = computed && computed.fontFamily
    ? computed.fontFamily
    : '"Microsoft YaHei UI", "Microsoft YaHei", "PingFang SC", Arial';
  mirror.style.fontSize = computed && computed.fontSize ? computed.fontSize : "12px";
  mirror.style.fontWeight = computed && computed.fontWeight ? computed.fontWeight : "500";
  mirror.style.letterSpacing = computed && computed.letterSpacing ? computed.letterSpacing : "0.01em";
  mirror.style.lineHeight = `${lineHeight}px`;
  mirror.style.paddingTop = computed && computed.paddingTop ? computed.paddingTop : "9px";
  mirror.style.paddingRight = computed && computed.paddingRight ? computed.paddingRight : "7px";
  mirror.style.paddingBottom = computed && computed.paddingBottom ? computed.paddingBottom : "9px";
  mirror.style.paddingLeft = computed && computed.paddingLeft ? computed.paddingLeft : "7px";
  return { lineHeight, paddingTop, width: editorWidth };
}

function measurePromptCaretPosition(mirror, value, index, layout) {
  mirror.textContent = value.slice(0, index);
  const marker = document.createElement("span");
  marker.className = "prompt-caret-marker";
  marker.textContent = "\u200b";
  mirror.appendChild(marker);
  try {
    const mirrorBounds = mirror.getBoundingClientRect();
    const markerBounds = marker.getBoundingClientRect();
    const x = Number(markerBounds.left) - Number(mirrorBounds.left);
    const y = Number(markerBounds.top) - Number(mirrorBounds.top);
    return {
      index,
      x: Number.isFinite(x) ? x : 0,
      y: Number.isFinite(y) ? y : 0,
      row: Math.max(0, Math.round(((Number.isFinite(y) ? y : 0) - layout.paddingTop) / layout.lineHeight))
    };
  } catch (_) {
    return null;
  }
}

function estimatePromptCaretFromPointer(event) {
  if (!elements.prompt || !event) return null;
  const value = getPromptValue();
  if (!value) return 0;
  let editorBounds = null;
  try {
    editorBounds = elements.prompt.getBoundingClientRect();
  } catch (_) {
    editorBounds = null;
  }
  if (!editorBounds) return null;
  const rawClientX = Number(event.clientX);
  const rawClientY = Number(event.clientY);
  const fallbackX = Number(event.offsetX);
  const fallbackY = Number(event.offsetY);
  const targetX = (
    Number.isFinite(rawClientX)
      ? rawClientX - Number(editorBounds.left)
      : (Number.isFinite(fallbackX) ? fallbackX : 0)
  ) + (Number(elements.prompt.scrollLeft) || 0);
  const targetY = (
    Number.isFinite(rawClientY)
      ? rawClientY - Number(editorBounds.top)
      : (Number.isFinite(fallbackY) ? fallbackY : 0)
  ) + (Number(elements.prompt.scrollTop) || 0);

  const mirror = ensurePromptCaretMirror();
  const layout = updatePromptCaretMirrorLayout(mirror);
  const targetRow = Math.max(0, Math.floor((targetY - layout.paddingTop) / layout.lineHeight));
  const cache = new Map();
  const measure = (index) => {
    const boundedIndex = Math.max(0, Math.min(value.length, index));
    if (!cache.has(boundedIndex)) {
      cache.set(
        boundedIndex,
        measurePromptCaretPosition(mirror, value, boundedIndex, layout)
      );
    }
    return cache.get(boundedIndex);
  };

  let low = 0;
  let high = value.length;
  while (low < high) {
    const middle = Math.floor((low + high) / 2);
    const position = measure(middle);
    if (!position) return null;
    if (
      position.row < targetRow ||
      (position.row === targetRow && position.x < targetX)
    ) {
      low = middle + 1;
    } else {
      high = middle;
    }
  }

  const candidates = [low - 1, low, low + 1]
    .filter((index, position, items) => (
      index >= 0 &&
      index <= value.length &&
      items.indexOf(index) === position
    ))
    .map(measure)
    .filter(Boolean);
  if (!candidates.length) return null;
  candidates.sort((first, second) => {
    const firstScore = Math.abs(first.row - targetRow) * Math.max(100, layout.width) +
      Math.abs(first.x - targetX);
    const secondScore = Math.abs(second.row - targetRow) * Math.max(100, layout.width) +
      Math.abs(second.x - targetX);
    return firstScore - secondScore;
  });
  return candidates[0].index;
}

function rememberPromptPointerSelection(event) {
  const nativeSelection = readPromptSelection();
  if (nativeSelection && nativeSelection.start !== nativeSelection.end) {
    lastPromptSelection = nativeSelection;
    promptSelectionFreezeUntil = Date.now() + 350;
    return nativeSelection;
  }
  const estimatedCaret = estimatePromptCaretFromPointer(event);
  if (Number.isInteger(estimatedCaret)) {
    lastPromptSelection = { start: estimatedCaret, end: estimatedCaret };
    promptSelectionFreezeUntil = Date.now() + 350;
    return lastPromptSelection;
  }
  return rememberPromptSelection();
}

function getPromptSelection() {
  const valueLength = getPromptValue().length;
  const liveSelection = promptHasFocus ? readPromptSelection() : null;
  const selection = liveSelection || lastPromptSelection || { start: valueLength, end: valueLength };
  const start = Math.max(0, Math.min(valueLength, Number(selection.start) || 0));
  const end = Math.max(start, Math.min(valueLength, Number(selection.end) || start));
  return { start, end };
}

function schedulePromptSelectionCapture(forceCapture = false) {
  if (promptSelectionCaptureTimer !== null) clearTimeout(promptSelectionCaptureTimer);
  promptSelectionCaptureTimer = setTimeout(() => {
    promptSelectionCaptureTimer = null;
    if (Date.now() < promptSelectionFreezeUntil) return;
    if (!forceCapture && !promptHasFocus && !promptPointerActive) return;
    rememberPromptSelection();
  }, 40);
}

function freezePromptSelectionCapture() {
  if (promptSelectionCaptureTimer !== null) {
    clearTimeout(promptSelectionCaptureTimer);
    promptSelectionCaptureTimer = null;
  }
}

function setPromptSelection(start, end, applyToEditor = true) {
  if (!elements.prompt) return;
  const value = getPromptValue();
  const boundedStart = Math.max(0, Math.min(value.length, Number(start) || 0));
  const boundedEnd = Math.max(boundedStart, Math.min(value.length, Number(end) || boundedStart));
  lastPromptSelection = { start: boundedStart, end: boundedEnd };
  if (!applyToEditor) return;
  try {
    if (typeof elements.prompt.setSelectionRange === "function") {
      elements.prompt.setSelectionRange(boundedStart, boundedEnd);
    } else if ("selectionStart" in elements.prompt && "selectionEnd" in elements.prompt) {
      elements.prompt.selectionStart = boundedStart;
      elements.prompt.selectionEnd = boundedEnd;
    }
  } catch (_) {
    // The editor remains usable when an older host does not expose caret APIs.
  }
}

function dispatchSelectChange(select) {
  let event = null;
  try {
    event = new Event("change", { bubbles: true });
  } catch (_) {
    event = document.createEvent("Event");
    event.initEvent("change", true, false);
  }
  select.dispatchEvent(event);
}

function closeIslandSelect(control, restoreFocus) {
  if (!control) return;
  control.root.classList.remove("is-open");
  control.menu.classList.add("is-hidden");
  control.trigger.setAttribute("aria-expanded", "false");
  if (restoreFocus) {
    try {
      control.trigger.focus();
    } catch (_) {
      // Focus restoration is non-critical.
    }
  }
}

function closeAllIslandSelects(exceptControl) {
  islandSelectControls.forEach((control) => {
    if (control !== exceptControl) closeIslandSelect(control, false);
  });
}

function focusIslandOption(control, direction) {
  if (!control) return;
  const items = Array.from(control.menu.children || []).filter(
    (child) => child.classList && child.classList.contains("island-select-option") && !child.disabled
  );
  if (!items.length) return;
  const activeIndex = items.indexOf(document.activeElement);
  const selectedIndex = items.findIndex((item) => item.classList.contains("is-selected"));
  let nextIndex = activeIndex;
  if (direction === "first") nextIndex = 0;
  else if (direction === "last") nextIndex = items.length - 1;
  else if (direction === "next") nextIndex = activeIndex < 0 ? Math.max(0, selectedIndex) : (activeIndex + 1) % items.length;
  else if (direction === "previous") nextIndex = activeIndex < 0 ? Math.max(0, selectedIndex) : (activeIndex - 1 + items.length) % items.length;
  else nextIndex = Math.max(0, selectedIndex);
  try {
    items[nextIndex].focus();
  } catch (_) {
    // Pointer selection remains available when focus APIs are limited.
  }
}

function openIslandSelect(select, control, focusOption) {
  if (!select || !control || select.disabled) return;
  closeAllIslandSelects(control);
  refreshIslandSelect(select, true);
  control.root.classList.add("is-open");
  control.menu.classList.remove("is-hidden");
  control.trigger.setAttribute("aria-expanded", "true");
  if (select === elements.resolution) {
    refreshLivePricing("resolution-menu").catch(() => {});
  }
  if (focusOption) setTimeout(() => focusIslandOption(control, "selected"), 0);
}

function selectIslandOption(select, control, index) {
  const option = select && select.options && select.options[index];
  if (!option || select.disabled || option.disabled) return;
  select.selectedIndex = index;
  dispatchSelectChange(select);
  syncIslandSelects();
  closeIslandSelect(control, true);
}

function refreshIslandSelect(select, rebuildOptions) {
  const control = islandSelectControls.get(select);
  if (!control) return;
  const options = Array.from(select.children || []).filter((child) => child.tagName === "OPTION");
  const selectedIndex = Math.max(0, options.findIndex((option) => option.value === select.value));
  const selectedOption = options[selectedIndex] || null;
  control.trigger.disabled = Boolean(select.disabled);
  control.root.classList.toggle("is-disabled", Boolean(select.disabled));
  control.value.textContent = selectedOption ? selectedOption.textContent : "请选择";
  control.value.title = selectedOption ? (selectedOption.title || selectedOption.textContent) : "请选择";

  if (rebuildOptions) {
    let menuItems = Array.from(control.menu.children || []).filter(
      (child) => child.classList && child.classList.contains("island-select-option")
    );
    if (menuItems.length !== options.length) {
      while (control.menu.firstChild) control.menu.removeChild(control.menu.firstChild);
      options.forEach(() => {
        const item = document.createElement("button");
        item.type = "button";
        item.className = "island-select-option";
        item.setAttribute("role", "option");
        item.addEventListener("click", () => {
          selectIslandOption(select, control, Number(item.__islandOptionIndex));
        });
        item.addEventListener("keydown", (event) => {
          if (event.key === "ArrowDown") {
            event.preventDefault();
            focusIslandOption(control, "next");
          } else if (event.key === "ArrowUp") {
            event.preventDefault();
            focusIslandOption(control, "previous");
          } else if (event.key === "Home") {
            event.preventDefault();
            focusIslandOption(control, "first");
          } else if (event.key === "End") {
            event.preventDefault();
            focusIslandOption(control, "last");
          } else if (event.key === "Escape") {
            event.preventDefault();
            closeIslandSelect(control, true);
          }
        });
        control.menu.appendChild(item);
      });
      menuItems = Array.from(control.menu.children || []).filter(
        (child) => child.classList && child.classList.contains("island-select-option")
      );
    }
    options.forEach((option, index) => {
      const item = menuItems[index];
      item.__islandOptionIndex = index;
      item.textContent = option.textContent;
      item.title = option.title || option.textContent;
      item.disabled = Boolean(option.disabled);
      item.classList.toggle("is-selected", index === selectedIndex);
      item.setAttribute("aria-selected", index === selectedIndex ? "true" : "false");
    });
  }
}

function syncIslandSelects() {
  islandSelectControls.forEach((_, select) => refreshIslandSelect(select, false));
}

function initializeIslandSelects() {
  [elements.promptLibrary, elements.localEditMode, elements.modelChannel, elements.aspectRatio, elements.resolution, elements.generationCount].forEach((select) => {
    if (!select || islandSelectControls.has(select)) return;
    select.classList.add("native-select-control");

    const root = document.createElement("div");
    root.className = `island-select-control island-select-${select.id}`;
    const trigger = document.createElement("button");
    trigger.type = "button";
    trigger.className = "island-select-trigger";
    trigger.setAttribute("aria-label", select.getAttribute("aria-label") || select.id);
    trigger.setAttribute("aria-haspopup", "listbox");
    trigger.setAttribute("aria-expanded", "false");
    const value = document.createElement("span");
    value.className = "island-select-value";
    const arrow = document.createElement("span");
    arrow.className = "island-select-arrow";
    arrow.setAttribute("aria-hidden", "true");
    const menu = document.createElement("div");
    menu.className = "island-select-menu is-hidden";
    menu.setAttribute("role", "listbox");
    menu.setAttribute("aria-label", select.getAttribute("aria-label") || select.id);
    trigger.appendChild(value);
    trigger.appendChild(arrow);
    root.appendChild(trigger);
    root.appendChild(menu);
    select.parentNode.insertBefore(root, select.nextSibling);
    const control = { root, trigger, value, arrow, menu };
    islandSelectControls.set(select, control);

    root.addEventListener("click", (event) => event.stopPropagation());
    trigger.addEventListener("click", () => {
      if (select.disabled) return;
      if (root.classList.contains("is-open")) closeIslandSelect(control, false);
      else openIslandSelect(select, control, false);
    });
    trigger.addEventListener("keydown", (event) => {
      if (select.disabled) return;
      if (event.key === "Enter" || event.key === " " || event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        if (!root.classList.contains("is-open")) openIslandSelect(select, control, true);
        else focusIslandOption(control, event.key === "ArrowUp" ? "previous" : "next");
      } else if (event.key === "Escape" && root.classList.contains("is-open")) {
        event.preventDefault();
        closeIslandSelect(control, false);
      }
    });
    refreshIslandSelect(select, true);
  });

  if (!islandSelectDocumentListenerAttached) {
    document.addEventListener("click", () => closeAllIslandSelects(null));
    islandSelectDocumentListenerAttached = true;
  }
}

function sanitizeMessage(value) {
  let message = String(value || "未知错误");
  if (state.apiKey) message = message.split(state.apiKey).join("[已隐藏]");
  message = message.replace(/katu-sk-[A-Za-z0-9_-]+/gi, "[已隐藏的 API Key]");
  message = message.replace(/Bearer\s+[A-Za-z0-9._~+/=-]+/gi, "Bearer [已隐藏]");
  return message.replace(/\s+/g, " ").trim().slice(0, 360);
}

function hideStatus() {
  if (statusHideTimer !== null) {
    clearTimeout(statusHideTimer);
    statusHideTimer = null;
  }
  if (elements.status) elements.status.classList.add("is-hidden");
}

function setStatus(kind, title, detail) {
  const resolvedKind = kind || "idle";
  if (statusHideTimer !== null) {
    clearTimeout(statusHideTimer);
    statusHideTimer = null;
  }
  syncNotificationLayout();
  elements.status.dataset.kind = resolvedKind;
  elements.statusIcon.textContent = {
    idle: "i",
    working: "…",
    success: "✓",
    warning: "!",
    error: "×"
  }[resolvedKind] || "i";
  elements.statusTitle.textContent = sanitizeMessage(title);
  elements.statusDetail.textContent = sanitizeMessage(detail || "");
  elements.status.classList.remove("is-hidden");
  const hideDelay = resolvedKind === "idle" ? 8600 : (resolvedKind === "success" ? 9500 : 0);
  if (hideDelay) {
    statusHideTimer = setTimeout(() => {
      statusHideTimer = null;
      if (elements.status) elements.status.classList.add("is-hidden");
    }, hideDelay);
  }
}

function normalizeUpdateVersion(value) {
  const text = String(value || "").trim().replace(/^v/i, "").split(/[+-]/)[0];
  return /^\d+\.\d+\.\d+$/.test(text) ? text : "";
}

function compareUpdateVersions(left, right) {
  const a = normalizeUpdateVersion(left).split(".").map(Number);
  const b = normalizeUpdateVersion(right).split(".").map(Number);
  if (a.length !== 3 || b.length !== 3) return 0;
  for (let index = 0; index < 3; index += 1) {
    if (a[index] !== b[index]) return a[index] > b[index] ? 1 : -1;
  }
  return 0;
}

function renderUpdateControl() {
  if (!elements.pluginVersion) return;
  const availableVersion = state.updateAvailable && state.updateAvailable.version;
  const hasUpdate = Boolean(
    availableVersion && compareUpdateVersions(availableVersion, UPDATE_CONFIG.currentVersion) > 0
  );
  elements.pluginVersion.classList.toggle("has-update", hasUpdate);
  elements.pluginVersion.textContent = hasUpdate
    ? `v${UPDATE_CONFIG.currentVersion} · 更新`
    : `v${UPDATE_CONFIG.currentVersion}`;
  elements.pluginVersion.title = hasUpdate
    ? `发现 v${availableVersion}，点击开始更新`
    : "检查更新";
  elements.pluginVersion.setAttribute(
    "aria-label",
    hasUpdate
      ? `当前版本 v${UPDATE_CONFIG.currentVersion}，发现新版 v${availableVersion}，点击开始更新`
      : `当前版本 v${UPDATE_CONFIG.currentVersion}，点击检查更新`
  );
}

function saveUpdateCheckCache() {
  try {
    localStorage.setItem(UPDATE_CHECK_STORAGE, JSON.stringify({
      checkedAt: state.updateLastCheckedAt,
      availableVersion: state.updateAvailable && state.updateAvailable.version || ""
    }));
  } catch (_) {
    // Update checking still works when localStorage is unavailable.
  }
}

function loadUpdateCheckCache() {
  try {
    const cached = JSON.parse(localStorage.getItem(UPDATE_CHECK_STORAGE) || "{}");
    state.updateLastCheckedAt = Number(cached.checkedAt) || 0;
    const availableVersion = normalizeUpdateVersion(cached.availableVersion);
    if (availableVersion && compareUpdateVersions(availableVersion, UPDATE_CONFIG.currentVersion) > 0) {
      state.updateAvailable = { version: availableVersion, cached: true };
    }
  } catch (_) {
    // Ignore a cleared or damaged optional cache.
  }
  renderUpdateControl();
}

async function fetchLatestPluginRelease() {
  const response = await fetch(`${UPDATE_CONFIG.latestReleaseApi}?_=${Date.now()}`, {
    method: "GET",
    headers: {
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28"
    },
    credentials: "omit",
    redirect: "error"
  });
  if (response.status === 404) {
    const error = new Error("GitHub 仓库还没有发布 Release");
    error.noRelease = true;
    throw error;
  }
  const rawBuffer = await readBoundedResponse(response, UPDATE_CONFIG.maxResponseBytes, "更新信息");
  const raw = utf8BytesToString(new Uint8Array(rawBuffer));
  let payload = null;
  try {
    payload = raw ? JSON.parse(raw) : null;
  } catch (_) {
    throw new Error("GitHub 返回了无法解析的更新信息");
  }
  if (!response.ok) throw new Error(`检查更新失败（HTTP ${response.status}）`);
  const version = normalizeUpdateVersion(payload && payload.tag_name);
  if (!version) throw new Error("最新 Release 的版本标签不正确");
  const assets = Array.isArray(payload.assets) ? payload.assets : [];
  const zipAsset = assets.find((asset) => (
    asset && /\.zip$/i.test(String(asset.name || "")) && Number(asset.size) > 0
  ));
  if (!zipAsset) throw new Error(`v${version} 还没有上传 ZIP 安装包`);
  return {
    version,
    tag: String(payload.tag_name || ""),
    assetName: String(zipAsset.name || ""),
    releaseUrl: String(payload.html_url || UPDATE_CONFIG.releasesPage)
  };
}

async function checkForPluginUpdate(manual) {
  if (state.checkingUpdate) return Boolean(state.updateAvailable);
  state.checkingUpdate = true;
  updateControls();
  if (manual) setStatus("working", "正在检查更新", "正在读取 GitHub Releases");
  try {
    const release = await fetchLatestPluginRelease();
    state.updateLastCheckedAt = Date.now();
    state.updateAvailable = compareUpdateVersions(release.version, UPDATE_CONFIG.currentVersion) > 0
      ? release
      : null;
    saveUpdateCheckCache();
    renderUpdateControl();
    if (state.updateAvailable) {
      if (manual || (!state.running && !state.recoveringPendingHistory && !state.preparingJob)) {
        setStatus(
          "warning",
          `发现新版 v${release.version}`,
          "点击右上角带“更新”的版本按钮，即可启动自动更新程序"
        );
      }
      return true;
    }
    if (manual) setStatus("success", "当前已经是最新版", `即杏智绘 v${UPDATE_CONFIG.currentVersion}`);
    return false;
  } catch (error) {
    state.updateLastCheckedAt = Date.now();
    saveUpdateCheckCache();
    if (manual) {
      setStatus(
        error && error.noRelease ? "idle" : "warning",
        error && error.noRelease ? "暂时没有可安装的更新" : "检查更新失败",
        error && (error.message || error)
      );
    }
    return false;
  } finally {
    state.checkingUpdate = false;
    updateControls();
  }
}

async function launchPluginUpdater() {
  const pluginFolder = await localFileSystem.getPluginFolder();
  const updaterFolder = await pluginFolder.getEntry(UPDATE_CONFIG.updaterFolder);
  const updaterFile = await updaterFolder.getEntry(UPDATE_CONFIG.updaterFile);
  const updaterPath = localFileSystem.getNativePath(updaterFile);
  if (!updaterPath) throw new Error("无法定位更新程序");
  const result = await shell.openPath(updaterPath, "用于下载并安装即杏智绘的新版本");
  if (result) throw new Error(result);
  setStatus(
    "working",
    "更新程序已经打开",
    "请按更新程序提示操作；安装前会让你保存并关闭 Photoshop"
  );
}

function updateControls() {
  state.running = state.generationJobs.length > 0;
  const busy = state.preparingJob || state.capturing || state.inserting || state.loadingPersistentHistory || state.paletteProcessing;
  const full = state.references.length >= MAX_REFERENCES;
  const selectedResult = getSelectedResult();
  elements.pluginVersion.disabled = state.checkingUpdate || busy || state.running || state.recoveringPendingHistory;
  elements.captureSelection.disabled = busy || full;
  elements.captureLayer.disabled = busy || full;
  elements.captureCanvas.disabled = busy || full;
  elements.clearReferences.disabled = busy || !state.references.length;
  elements.referenceAdd.disabled = busy || full;
  elements.run.disabled = busy || state.generationJobs.length >= MAX_ACTIVE_JOBS;
  elements.insert.disabled = busy || !selectedResult;
  const generationCanStop = state.generationJobs.some((job) => !job.controller.signal.aborted);
  const historyCanStop = Boolean(
    state.recoveringPendingHistory && pendingHistoryRecoveryController &&
    !pendingHistoryRecoveryController.signal.aborted
  );
  elements.stop.disabled = !generationCanStop && !historyCanStop;
  elements.aspectRatio.disabled = busy;
  elements.modelChannel.disabled = busy;
  elements.resolution.disabled = busy;
  elements.generationCount.disabled = busy;
  elements.localEditMode.disabled = busy;
  const precisionTargetAvailable = selectedResult
    ? hasPhotoshopTarget(selectedResult.snapshot)
    : Boolean(state.targetSnapshot);
  const precisionSnapshot = selectedResult ? selectedResult.snapshot : state.targetSnapshot;
  const smartLocalTarget = hasSmartLocalTarget(precisionSnapshot);
  if (smartLocalTarget) elements.precisionPlacement.checked = true;
  elements.precisionPlacement.disabled = busy || !precisionTargetAvailable || smartLocalTarget;
  setPromptDisabled(busy);
  elements.promptLibrary.disabled = busy || !state.favoritePrompts.length;
  elements.favoritePrompt.disabled = busy || !getPromptValue().trim();
  elements.capturePaletteSample.disabled = busy;
  elements.applyPaletteMatch.disabled = busy || !state.paletteSample;
  elements.clearPaletteSample.disabled = busy || !state.paletteSample;
  syncIslandSelects();
}

function updatePromptCount() {
  let prompt = getPromptValue();
  if (prompt.length > 20000) {
    const selection = getPromptSelection();
    prompt = prompt.slice(0, 20000);
    setPromptValue(prompt);
    setPromptSelection(Math.min(selection.start, prompt.length), Math.min(selection.end, prompt.length));
  }
  elements.promptCount.textContent = `${prompt.length} / 20000 · Ctrl+Enter 运行`;
  updateFavoriteButton();
  updateControls();
}

function normalizePromptList(value, limit) {
  if (!Array.isArray(value)) return [];
  const output = [];
  for (const item of value) {
    const prompt = String(item || "").trim();
    if (!prompt || output.includes(prompt)) continue;
    output.push(prompt.slice(0, 20000));
    if (output.length >= limit) break;
  }
  return output;
}

function truncatePromptLabel(prompt, limit) {
  const compact = String(prompt || "").replace(/\s+/g, " ").trim();
  const characters = Array.from(compact);
  return characters.length > limit ? `${characters.slice(0, limit).join("")}…` : compact;
}

function appendFavoritePromptOptions(prompts) {
  prompts.forEach((prompt, index) => {
    const option = document.createElement("option");
    option.value = `favorite:${index}`;
    option.textContent = truncatePromptLabel(prompt, 38);
    option.title = prompt;
    elements.promptLibrary.appendChild(option);
  });
}

function renderPromptLibrary() {
  while (elements.promptLibrary.firstChild) {
    elements.promptLibrary.removeChild(elements.promptLibrary.firstChild);
  }
  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = state.favoritePrompts.length ? "选择收藏提示词" : "暂无收藏提示词";
  elements.promptLibrary.appendChild(placeholder);
  appendFavoritePromptOptions(state.favoritePrompts);
  elements.promptLibrary.value = "";
  refreshIslandSelect(elements.promptLibrary, true);
  updateFavoriteButton();
}

function updateFavoriteButton() {
  if (!elements.favoritePrompt || !elements.prompt) return;
  const prompt = getPromptValue().trim();
  const saved = Boolean(prompt) && state.favoritePrompts.includes(prompt);
  elements.favoritePrompt.textContent = saved ? "取消收藏" : "收藏";
  elements.favoritePrompt.classList.toggle("is-saved", saved);
}

function toggleFavoritePrompt() {
  const prompt = getPromptValue().trim();
  if (!prompt) return;
  const index = state.favoritePrompts.indexOf(prompt);
  if (index >= 0) {
    state.favoritePrompts.splice(index, 1);
    setStatus("idle", "已取消收藏", truncatePromptLabel(prompt, 42));
  } else {
    state.favoritePrompts.unshift(prompt);
    state.favoritePrompts = normalizePromptList(state.favoritePrompts, MAX_FAVORITE_PROMPTS);
    setStatus("success", "提示词已收藏", `最多保留 ${MAX_FAVORITE_PROMPTS} 条收藏`);
  }
  saveSettings();
  renderPromptLibrary();
  updateControls();
}

function applyPromptLibrarySelection() {
  const value = String(elements.promptLibrary.value || "");
  const match = /^favorite:(\d+)$/.exec(value);
  if (!match) return;
  const prompt = state.favoritePrompts[Number(match[1])];
  if (prompt) {
    setPromptValue(prompt);
    elements.prompt.focus();
    setPromptSelection(prompt.length, prompt.length);
    updatePromptCount();
  }
  elements.promptLibrary.value = "";
  refreshIslandSelect(elements.promptLibrary, false);
}

function formatReferenceType(mode) {
  if (mode === "selection") return "选区";
  if (mode === "layer") return "图层";
  if (mode === "import") return "导入";
  return "全图";
}

function formatReferenceOrdinal(value) {
  const numerals = ["", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十"];
  return numerals[Number(value)] || String(value);
}

function formatReferenceLabel(reference, index) {
  if (!reference) return "参考图";
  const resolvedIndex = Number.isInteger(index)
    ? index
    : state.references.findIndex((item) => item.id === reference.id);
  let ordinal = 0;
  for (let position = 0; position <= resolvedIndex; position += 1) {
    if (state.references[position] && state.references[position].mode === reference.mode) ordinal += 1;
  }
  return `${formatReferenceType(reference.mode)}${formatReferenceOrdinal(Math.max(1, ordinal))}`;
}

function getPrimaryReference() {
  return state.references.find((reference) => reference && reference.snapshot) || null;
}

function getGenerationSnapshot() {
  if (state.targetSnapshot) return state.targetSnapshot;
  const primaryReference = getPrimaryReference();
  return primaryReference ? primaryReference.snapshot : null;
}

function hasPhotoshopTarget(snapshot) {
  return Boolean(
    snapshot && snapshot.mode === "selection" &&
    snapshot.documentId !== null && snapshot.documentId !== undefined
  );
}

function hasSmartLocalTarget(snapshot) {
  return Boolean(hasPhotoshopTarget(snapshot) && snapshot.editBounds && snapshot.mask);
}

function hasPhotoshopDocument(snapshot) {
  return Boolean(
    snapshot &&
    snapshot.documentId !== null &&
    snapshot.documentId !== undefined
  );
}

function syncNotificationLayout() {
  if (!elements.notificationLayer) return;
  const identity = document.querySelector(".plugin-identity");
  if (!identity) return;
  let bounds = null;
  try {
    bounds = identity.getBoundingClientRect();
  } catch (_) {
    bounds = null;
  }
  const left = Number(bounds && bounds.left);
  const width = Number(bounds && bounds.width);
  if (!Number.isFinite(left) || !Number.isFinite(width) || width <= 0) return;
  const leftValue = `${Math.floor(left * 10) / 10}px`;
  const widthValue = `${Math.floor(width * 10) / 10}px`;
  if (elements.notificationLayer.style.left !== leftValue) {
    elements.notificationLayer.style.left = leftValue;
  }
  if (elements.notificationLayer.style.width !== widthValue) {
    elements.notificationLayer.style.width = widthValue;
  }
  if (elements.notificationLayer.style.right !== "auto") {
    elements.notificationLayer.style.right = "auto";
  }
}

function scheduleNotificationLayout() {
  if (notificationLayoutTimer !== null) clearTimeout(notificationLayoutTimer);
  notificationLayoutTimer = setTimeout(() => {
    notificationLayoutTimer = null;
    syncNotificationLayout();
  }, 100);
}

function syncResultHistoryTileLayout(tileSize = referenceTileSize) {
  if (!elements.resultHistory) return;
  const resolvedSize = Number(tileSize);
  if (!Number.isFinite(resolvedSize) || resolvedSize <= 0) return;
  const sizeValue = `${Math.floor(resolvedSize * 10) / 10}px`;
  const items = Array.from(elements.resultHistory.children || []).filter((child) => (
    child.classList && child.classList.contains("result-history-item")
  ));
  items.forEach((item) => {
    if (item.style.width !== sizeValue) item.style.width = sizeValue;
    if (item.style.height !== sizeValue) item.style.height = sizeValue;
    if (item.style.flexBasis !== sizeValue) item.style.flexBasis = sizeValue;
  });
}

function syncReferenceTileLayout() {
  if (!elements.referenceList) return;
  const children = Array.from(elements.referenceList.children || []);
  const tiles = children.filter((child) => (
    child.classList &&
    (child.classList.contains("reference-thumb") || child.classList.contains("reference-add"))
  ));
  if (!tiles.length) return;

  let tileWidth = 0;
  const visibleTile = tiles.find((tile) => !tile.classList.contains("is-hidden")) || tiles[0];
  try {
    const bounds = visibleTile.getBoundingClientRect();
    tileWidth = Number(bounds && bounds.width) || 0;
  } catch (_) {
    tileWidth = Number(visibleTile.offsetWidth) || 0;
  }
  if (!tileWidth) {
    const listWidth = Number(elements.referenceList.clientWidth) || 0;
    tileWidth = listWidth > 0 ? (listWidth / 5) - 6 : 80;
  }
  const tileSize = Math.max(56, Math.floor(tileWidth * 10) / 10);
  referenceListWidth = Number(elements.referenceList.clientWidth) || referenceListWidth;
  referenceTileSize = tileSize;
  const sizeValue = `${tileSize}px`;
  tiles.forEach((tile) => {
    if (tile.style.height !== sizeValue) tile.style.height = sizeValue;
  });
  syncResultHistoryTileLayout(tileSize);
}

function scheduleReferenceTileLayout() {
  const currentWidth = Number(elements.referenceList && elements.referenceList.clientWidth) || 0;
  if (
    currentWidth > 0 &&
    referenceListWidth > 0 &&
    Math.abs(currentWidth - referenceListWidth) < 0.5
  ) return;
  if (referenceLayoutTimer !== null) clearTimeout(referenceLayoutTimer);
  referenceLayoutTimer = setTimeout(() => {
    referenceLayoutTimer = null;
    syncReferenceTileLayout();
  }, 100);
}

function renderReferences() {
  while (
    elements.referenceList.firstChild &&
    elements.referenceList.firstChild !== elements.referenceAdd
  ) {
    elements.referenceList.removeChild(elements.referenceList.firstChild);
  }

  state.references.forEach((reference, index) => {
    const displayLabel = formatReferenceLabel(reference, index);
    const thumb = document.createElement("div");
    thumb.className = "reference-thumb";
    thumb.setAttribute("data-reference-drag-id", reference.id);
    thumb.setAttribute("data-reference-prompt-id", reference.id);
    thumb.setAttribute("draggable", state.references.length > 1 ? "true" : "false");
    if (state.targetSnapshot && state.targetSnapshot.sourceReferenceId === reference.id) {
      thumb.classList.add("is-target");
    }
    const originalName = reference.originalName ? ` · ${reference.originalName}` : "";
    thumb.title = `${displayLabel}${originalName} · ${reference.bounds.width}×${reference.bounds.height} · 点击加入 @图片${formatReferenceOrdinal(index + 1)} · 可拖动调整顺序`;

    const image = document.createElement("img");
    image.alt = `参考图 ${index + 1}`;
    image.setAttribute("draggable", "false");
    try {
      image.src = reference.previewUrl || reference.file;
    } catch (_) {
      image.removeAttribute("src");
    }

    const number = document.createElement("span");
    number.className = "reference-index animal-reference-tag";
    number.textContent = String(index + 1);

    const type = document.createElement("span");
    type.className = "reference-type animal-reference-type";
    type.textContent = displayLabel;

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "reference-remove animal-thumb-button animal-thumb-danger";
    remove.textContent = "×";
    remove.setAttribute("aria-label", `移除${displayLabel}`);
    remove.setAttribute("data-reference-id", reference.id);

    const caption = document.createElement("div");
    caption.className = "reference-caption animal-reference-toolbar";
    caption.appendChild(type);

    thumb.appendChild(image);
    thumb.appendChild(number);
    thumb.appendChild(caption);
    thumb.appendChild(remove);
    elements.referenceList.insertBefore(thumb, elements.referenceAdd);
  });

  elements.referenceCount.textContent = `${state.references.length} / ${MAX_REFERENCES}`;
  elements.referenceEmptyHint.classList.toggle("is-hidden", state.references.length > 0);
  elements.referenceAdd.classList.toggle("is-hidden", state.references.length >= MAX_REFERENCES);
  syncReferenceTileLayout();
  scheduleReferenceTileLayout();

  const target = state.targetSnapshot;
  if (!target) {
    const primaryReference = getPrimaryReference();
    elements.targetSummary.textContent = primaryReference
      ? `主参考图：${formatReferenceLabel(primaryReference)} ${primaryReference.bounds.width}×${primaryReference.bounds.height} · 可直接生成`
      : "选区可精确回填；图层、全图和导入图片也可直接生成";
  } else {
    const targetReference = state.references.find((reference) => reference.id === target.sourceReferenceId);
    const targetLabel = targetReference ? formatReferenceLabel(targetReference) : formatReferenceType(target.mode);
    const visibleBounds = target.editBounds || target.bounds;
    const maskNote = target.mode === "selection" && target.mask ? " · 选区外受保护" : "";
    const contextNote = target.editBounds ? ` · 周边参考 ${target.bounds.width}×${target.bounds.height}` : "";
    elements.targetSummary.textContent = `回填目标：${targetLabel} ${visibleBounds.width}×${visibleBounds.height}${maskNote}${contextNote}`;
  }
  elements.targetSummary.title = elements.targetSummary.textContent;
  updateResolvedSize();
  updateControls();
}

function outputBasis() {
  return getGenerationSnapshot();
}

function ratioNumber(label) {
  const parts = String(label || "").split(":");
  const width = Number(parts[0]);
  const height = Number(parts[1]);
  return width > 0 && height > 0 ? width / height : NaN;
}

function closestSupportedRatio(width, height, supportedRatios) {
  const actual = Number(width) / Number(height);
  if (!(actual > 0) || !Number.isFinite(actual)) return supportedRatios[0] || "1:1";
  let best = supportedRatios[0] || "1:1";
  let bestDistance = Infinity;
  supportedRatios.forEach((ratio) => {
    const nominal = ratioNumber(ratio);
    if (!(nominal > 0)) return;
    const distance = Math.abs(Math.log(actual / nominal));
    if (distance < bestDistance) {
      best = ratio;
      bestDistance = distance;
    }
  });
  return best;
}

function resolveModelOutputSize(aspectRatio, resolution, sourceWidth, sourceHeight, modelConfig) {
  const model = modelConfig || getSelectedModelConfig();
  const automatic = aspectRatio === "auto";
  const ratio = automatic
    ? closestSupportedRatio(sourceWidth, sourceHeight, model.supportedRatios)
    : String(aspectRatio || "1:1");
  if (!model.supportedRatios.includes(ratio)) {
    throw new Error(`${model.shortLabel} 不支持 ${ratio} 比例`);
  }
  if (!model.supportedSizes.includes(String(resolution))) {
    throw new Error(`${model.shortLabel} 不支持 ${resolution} 分辨率`);
  }
  const resolved = resolveOutputSize(ratio, resolution, sourceWidth, sourceHeight);
  resolved.automatic = automatic;
  return resolved;
}

function syncModelCapabilities() {
  const model = getSelectedModelConfig();
  Array.from(elements.aspectRatio.options || []).forEach((option) => {
    option.disabled = option.value !== "auto" && !model.supportedRatios.includes(option.value);
  });
  if (elements.aspectRatio.value !== "auto" && !model.supportedRatios.includes(elements.aspectRatio.value)) {
    elements.aspectRatio.value = "auto";
  }
  Array.from(elements.resolution.options || []).forEach((option) => {
    option.disabled = !model.supportedSizes.includes(option.value) || (
      state.pricing.source === "live" && !state.pricing.enabled[option.value]
    );
  });
  if (!model.supportedSizes.includes(elements.resolution.value)) {
    elements.resolution.value = model.supportedSizes[0] || "1K";
  }
  refreshIslandSelect(elements.aspectRatio, true);
  refreshIslandSelect(elements.resolution, true);
}

function resetPricingStateForModel() {
  state.pricing.prices = { "1K": null, "2K": null, "4K": null };
  state.pricing.enabled = { "1K": false, "2K": false, "4K": false };
  state.pricing.fetchedAt = 0;
  state.pricing.serviceUpdatedAt = "";
  state.pricing.source = "none";
  state.pricing.changes = {};
  state.pricing.unacknowledgedIncreases = {};
  state.pricing.error = "";
  state.pricingRunConfirmation = null;
}

function normalizePriceValue(value) {
  const price = Number(value);
  return Number.isFinite(price) && price >= 0 ? Math.round(price * 10000) / 10000 : null;
}

function formatYuan(value) {
  const price = normalizePriceValue(value);
  if (price === null) return "--";
  return `¥${price < 0.01 && price > 0 ? price.toFixed(4) : price.toFixed(2)}`;
}

function hasUsablePricing() {
  return PRICING_SIZES.some((size) => normalizePriceValue(state.pricing.prices[size]) !== null);
}

function pricingCostNotice() {
  const selectedSize = elements.resolution ? String(elements.resolution.value || "1K") : "1K";
  const count = elements.generationCount ? getGenerationCount() : 1;
  const selectedPrice = normalizePriceValue(state.pricing.prices[selectedSize]);
  const pendingIncrease = state.pricing.unacknowledgedIncreases[selectedSize];

  if (pendingIncrease) {
    return `；${selectedSize} 已涨至 ${formatYuan(pendingIncrease.after)}，首次运行会暂停确认`;
  }
  if (state.pricing.source === "none" && !state.pricing.error) {
    return "；实时价格获取中";
  }
  if (state.pricing.error) {
    return "；实时价格不可用，运行前会重新核对";
  }
  if (state.pricing.source === "cache") {
    return selectedPrice === null
      ? "；实时价格获取中"
      : `；缓存单价 ${formatYuan(selectedPrice)}，正在核对实时价格`;
  }
  if (!state.pricing.enabled[selectedSize] || selectedPrice === null) {
    return `；${selectedSize} 已停用，本次不会发送付费请求`;
  }
  return `；单价 ${formatYuan(selectedPrice)}，${count} 张预计 ${formatYuan(selectedPrice * count)}`;
}

function setFitNotice(message) {
  fitNoticeBaseText = String(message || "");
  if (elements.fitNotice) {
    elements.fitNotice.textContent = `${fitNoticeBaseText}${pricingCostNotice()}`;
  }
}

function renderPricing() {
  if (!elements.resolution) return;
  const model = getSelectedModelConfig();
  const options = Array.from(elements.resolution.options || []);
  const waitingForFirstPrice = state.pricing.source === "none" && !state.pricing.error;
  let optionsChanged = false;

  PRICING_SIZES.forEach((size) => {
    const option = options.find((item) => item.value === size);
    if (!option) return;
    const price = normalizePriceValue(state.pricing.prices[size]);
    const enabled = Boolean(state.pricing.enabled[size]);
    const change = state.pricing.changes[size];
    let changeMark = "";
    let nextTitle = `${size} 实时 API 单价`;
    if (change && normalizePriceValue(change.before) !== null && normalizePriceValue(change.after) !== null) {
      const increased = change.after > change.before;
      changeMark = increased ? " ↑" : " ↓";
      nextTitle = `${size} 单价${increased ? "上涨" : "下降"}：${formatYuan(change.before)} → ${formatYuan(change.after)}`;
    }
    const modelUnsupported = !model.supportedSizes.includes(size);
    const serverDisabled = modelUnsupported || (
      state.pricing.source === "live" && (!enabled || price === null)
    );
    let nextLabel = "";
    if (modelUnsupported) {
      nextLabel = `${size} · 该模型不支持`;
      nextTitle = `${model.shortLabel} 不支持 ${size}`;
    } else if (waitingForFirstPrice) {
      nextLabel = `${size} · 获取中…`;
    } else if (serverDisabled) {
      nextLabel = `${size} · 已停用`;
    } else if (price !== null) {
      nextLabel = `${size} · ${formatYuan(price)}${changeMark}`;
    } else {
      nextLabel = `${size} · 价格不可用`;
    }
    if (option.title !== nextTitle) {
      option.title = nextTitle;
      optionsChanged = true;
    }
    if (Boolean(option.disabled) !== serverDisabled) {
      option.disabled = serverDisabled;
      optionsChanged = true;
    }
    if (option.textContent !== nextLabel) {
      option.textContent = nextLabel;
      optionsChanged = true;
    }
  });

  // Reuse the open island-style menu items whenever their count is unchanged.
  // This keeps live prices current without detaching the option under the pointer.
  refreshIslandSelect(elements.resolution, optionsChanged);
  if (fitNoticeBaseText && elements.fitNotice) {
    elements.fitNotice.textContent = `${fitNoticeBaseText}${pricingCostNotice()}`;
  }
}

function loadCachedPricing() {
  try {
    const cached = JSON.parse(localStorage.getItem(PRICING_STORAGE) || "{}");
    if (cached.model !== selectedApiModel() || !cached.prices || !cached.enabled) return;
    let found = false;
    PRICING_SIZES.forEach((size) => {
      const price = normalizePriceValue(cached.prices[size]);
      state.pricing.prices[size] = price;
      state.pricing.enabled[size] = Boolean(cached.enabled[size]) && price !== null;
      if (price !== null) found = true;
    });
    if (!found) return;
    state.pricing.fetchedAt = Number(cached.fetchedAt) || 0;
    state.pricing.serviceUpdatedAt = String(cached.serviceUpdatedAt || "");
    state.pricing.source = "cache";
  } catch (_) {
    // Ignore missing or damaged non-sensitive price cache.
  }
}

function savePricingCache() {
  try {
    localStorage.setItem(PRICING_STORAGE, JSON.stringify({
      model: selectedApiModel(),
      prices: state.pricing.prices,
      enabled: state.pricing.enabled,
      fetchedAt: state.pricing.fetchedAt,
      serviceUpdatedAt: state.pricing.serviceUpdatedAt
    }));
  } catch (_) {
    // Price caching is optional; live verification still runs before generation.
  }
}

async function fetchPricingSnapshot(modelConfig) {
  const model = modelConfig || getSelectedModelConfig();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), PRICING_TIMEOUT_MS);
  try {
    const pricingUrl = `${API_CONFIG.pricingEndpoint}?_=${Date.now()}`;
    const response = await fetch(pricingUrl, {
      method: "GET",
      headers: {
        Accept: "application/json"
      },
      credentials: "omit",
      redirect: "error",
      signal: controller.signal
    });
    const rawBuffer = await readBoundedResponse(response, API_CONFIG.maxPricingBytes, "价格响应");
    const raw = utf8BytesToString(new Uint8Array(rawBuffer));
    let payload = null;
    try {
      payload = raw ? JSON.parse(raw) : null;
    } catch (_) {
      throw new Error("实时价格接口返回了无法解析的内容");
    }
    if (!response.ok) throw new Error(`实时价格接口请求失败（HTTP ${response.status}）`);
    const snapshot = extractPricingSnapshot(payload, model.pricingModel, PRICING_SIZES);
    if (!snapshot) throw new Error(`实时价格中没有找到 ${model.shortLabel}`);
    if (!PRICING_SIZES.some((size) => snapshot.enabled[size])) {
      throw new Error(`${model.shortLabel} 当前没有可用的实时价格`);
    }
    return { ...snapshot, apiModel: model.apiModel };
  } catch (error) {
    if (error && error.name === "AbortError") throw new Error("实时价格核对超时");
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

async function refreshLivePricing(reason) {
  const model = getSelectedModelConfig();
  const modelAtStart = model.apiModel;
  if (pricingRequest) {
    const activeRequest = pricingRequest;
    const activeResult = await activeRequest.promise;
    if (activeRequest.model === modelAtStart) return activeResult;
    if (selectedApiModel() !== modelAtStart) {
      return { ok: false, stale: true, reason: reason || "refresh", model: modelAtStart };
    }
    return await refreshLivePricing(reason);
  }
  state.pricing.checking = true;
  renderPricing();
  updateControls();

  const requestPromise = (async () => {
    try {
      const snapshot = await fetchPricingSnapshot(model);
      if (selectedApiModel() !== modelAtStart) {
        return { ok: false, stale: true, reason: reason || "refresh", model: modelAtStart };
      }
      const detectedChanges = {};
      PRICING_SIZES.forEach((size) => {
        const before = normalizePriceValue(state.pricing.prices[size]);
        const after = normalizePriceValue(snapshot.prices[size]);
        if (before !== null && after !== null && Math.abs(before - after) > 0.000001) {
          const change = { before, after, detectedAt: Date.now() };
          detectedChanges[size] = change;
          state.pricing.changes[size] = change;
          const pending = state.pricing.unacknowledgedIncreases[size];
          if (after > before) {
            state.pricing.unacknowledgedIncreases[size] = {
              before: pending ? pending.before : before,
              after,
              detectedAt: Date.now()
            };
          } else if (pending && after > pending.before) {
            state.pricing.unacknowledgedIncreases[size] = {
              before: pending.before,
              after,
              detectedAt: Date.now()
            };
          } else {
            delete state.pricing.unacknowledgedIncreases[size];
          }
        }
      });
      state.pricing.prices = snapshot.prices;
      state.pricing.enabled = snapshot.enabled;
      state.pricing.serviceUpdatedAt = snapshot.serviceUpdatedAt;
      state.pricing.fetchedAt = Date.now();
      state.pricing.source = "live";
      state.pricing.error = "";
      savePricingCache();
      return { ok: true, reason: reason || "refresh", changes: detectedChanges, model: modelAtStart };
    } catch (error) {
      if (selectedApiModel() !== modelAtStart) {
        return { ok: false, stale: true, reason: reason || "refresh", model: modelAtStart };
      }
      state.pricing.error = sanitizeMessage(error && (error.message || error));
      state.pricing.source = hasUsablePricing() ? "cache" : "none";
      return { ok: false, reason: reason || "refresh", error: state.pricing.error, model: modelAtStart };
    }
  })();
  pricingRequest = { model: modelAtStart, promise: requestPromise };

  try {
    return await requestPromise;
  } finally {
    if (pricingRequest && pricingRequest.promise === requestPromise) pricingRequest = null;
    state.pricing.checking = false;
    renderPricing();
    updateControls();
  }
}

function pricingRunConfirmationKey() {
  return [
    selectedApiModel(),
    String(elements.resolution && elements.resolution.value || "1K"),
    String(getGenerationCount()),
    String(elements.aspectRatio && elements.aspectRatio.value || "auto")
  ].join("|");
}

async function verifyLivePricingBeforeRun() {
  const selectedSize = String(elements.resolution.value || "1K");
  const refreshResult = await refreshLivePricing("run");
  if (!refreshResult.ok) {
    const confirmationKey = pricingRunConfirmationKey();
    const previous = state.pricingRunConfirmation;
    const confirmed = Boolean(
      previous && previous.key === confirmationKey &&
      Date.now() - Number(previous.createdAt || 0) <= PRICE_BYPASS_CONFIRM_MS
    );
    if (confirmed) {
      state.pricingRunConfirmation = null;
      const cachedPrice = normalizePriceValue(state.pricing.prices[selectedSize]);
      return {
        ok: true,
        size: selectedSize,
        unitPrice: cachedPrice,
        estimatedCost: cachedPrice === null ? null : cachedPrice * getGenerationCount(),
        priceUnverified: true,
        priceWarning: refreshResult.error || "当前无法查询实时价格"
      };
    }
    state.pricingRunConfirmation = { key: confirmationKey, createdAt: Date.now() };
    return {
      ok: false,
      title: "当前无法查询实时价格",
      detail: `${refreshResult.error || "价格接口暂不可用"}；本次未发送付费请求。确认继续时，请在 60 秒内再次点击“运行”`
    };
  }
  state.pricingRunConfirmation = null;
  const price = normalizePriceValue(state.pricing.prices[selectedSize]);
  if (!state.pricing.enabled[selectedSize] || price === null) {
    return {
      ok: false,
      title: `${selectedSize} 当前不可用`,
      detail: "价格页显示该规格已停用；本次未发送付费请求"
    };
  }
  const pendingIncrease = state.pricing.unacknowledgedIncreases[selectedSize];
  if (pendingIncrease) {
    delete state.pricing.unacknowledgedIncreases[selectedSize];
    renderPricing();
    return {
      ok: false,
      title: `${selectedSize} 单价已上涨`,
      detail: `${formatYuan(pendingIncrease.before)} → ${formatYuan(pendingIncrease.after)}；请确认预计费用后再次点击运行`
    };
  }
  return {
    ok: true,
    size: selectedSize,
    unitPrice: price,
    estimatedCost: price * getGenerationCount()
  };
}

function startPricingAutoRefresh() {
  if (pricingRefreshTimer !== null) clearInterval(pricingRefreshTimer);
  pricingRefreshTimer = setInterval(() => {
    refreshLivePricing("timer").catch(() => {});
  }, PRICING_REFRESH_MS);
}

function updateResolvedSize() {
  renderPricing();
  const model = getSelectedModelConfig();
  const basis = outputBasis();
  const autoRetouch = elements.aspectRatio.value === "auto";
  if (!basis) {
    elements.resolvedDimensions.textContent = `${model.shortLabel} · ${autoRetouch ? "修图" : "作图"} · ${elements.resolution.value || "1K"} · 等待参考图`;
    setFitNotice(autoRetouch
      ? `自动匹配画面比例${generationRequestNotice()}`
      : `固定比例作图${generationRequestNotice()}`);
    return;
  }

  try {
    const resolved = resolveModelOutputSize(
      elements.aspectRatio.value,
      elements.resolution.value,
      basis.bounds.width,
      basis.bounds.height,
      model
    );
    elements.resolvedDimensions.textContent = `${model.shortLabel} · ${resolved.automatic ? "修图 · " : "作图 · "}${resolved.ratio} · ${resolved.size}`;
    const sourceRatio = basis.bounds.width / basis.bounds.height;
    const targetRatio = resolved.width / resolved.height;
    const mismatch = Math.abs(Math.log(sourceRatio / targetRatio));
    const fitMessage = autoRetouch
      ? (mismatch > 0.025
        ? "自动匹配；回填时等比覆盖并居中裁切"
        : "自动匹配；不会拉伸图像")
      : "固定比例作图";
    setFitNotice(`${fitMessage}${generationRequestNotice()}`);
  } catch (error) {
    elements.resolvedDimensions.textContent = "尺寸错误";
    setFitNotice(sanitizeMessage(error.message));
  }
}

function getGenerationCount() {
  const value = Number(elements.generationCount.value);
  return Number.isInteger(value) && value >= 1 && value <= 4 ? value : 1;
}

function selectedLocalEditMode() {
  const value = String(elements.localEditMode && elements.localEditMode.value || "general");
  return LOCAL_EDIT_MODES.includes(value) ? value : "general";
}

function localEditModeLabel(mode) {
  const labels = {
    general: "通用局部",
    head: "换头",
    upper: "换上衣",
    pants: "换裤子",
    outfit: "整套换装"
  };
  return labels[String(mode || "")] || labels.general;
}

function expandSelectionContextBounds(bounds, documentWidth, documentHeight, mode) {
  if (!bounds) return null;
  const ratios = {
    general: { left: 0.28, right: 0.28, top: 0.28, bottom: 0.28 },
    head: { left: 0.38, right: 0.38, top: 0.28, bottom: 0.58 },
    upper: { left: 0.32, right: 0.32, top: 0.32, bottom: 0.32 },
    pants: { left: 0.3, right: 0.3, top: 0.42, bottom: 0.28 },
    outfit: { left: 0.24, right: 0.24, top: 0.22, bottom: 0.22 }
  };
  const ratio = ratios[String(mode || "")] || ratios.general;
  const minimum = Math.max(24, Math.min(96, Math.round(Math.min(bounds.width, bounds.height) * 0.08)));
  const expanded = {
    left: bounds.left - Math.max(minimum, Math.round(bounds.width * ratio.left)),
    top: bounds.top - Math.max(minimum, Math.round(bounds.height * ratio.top)),
    right: bounds.right + Math.max(minimum, Math.round(bounds.width * ratio.right)),
    bottom: bounds.bottom + Math.max(minimum, Math.round(bounds.height * ratio.bottom))
  };
  return clampBounds(expanded, documentWidth, documentHeight) || bounds;
}

function buildLocalEditPrompt(userPrompt, snapshot, mode) {
  const cleanPrompt = String(userPrompt || "").trim();
  if (!snapshot || snapshot.mode !== "selection") return cleanPrompt;
  const selectedMode = LOCAL_EDIT_MODES.includes(String(mode || "")) ? String(mode) : "general";
  const specific = {
    general: "只完成用户要求的局部修改",
    head: "只替换选区内的头部；保持原脖子、衣领、肩膀、身体、衣服和背景不变，并让下颌与原脖子自然衔接",
    upper: "只替换选区内的上衣；保持脸、头发、皮肤、手、裤子、鞋子、身体比例和背景不变",
    pants: "只替换选区内的裤子；保持人物上身、皮肤、手、上衣、鞋子、身体比例和背景不变",
    outfit: "只替换选区内的服装；保持人物身份、脸、头发、皮肤、手、身体比例、姿势和背景不变"
  }[selectedMode];
  const protection = [
    `局部编辑要求：${specific}。`,
    "图片中包含选区周围的衔接参考，请保持周围参考像素的构图、位置、光线和纹理稳定。",
    "不得移动主体，不得改变画面尺寸，不得重画选区外内容；选区边缘需要与原图自然连续。"
  ].join("");
  const separator = "\n\n";
  const allowedPromptLength = Math.max(0, 20000 - separator.length - protection.length);
  return `${cleanPrompt.slice(0, allowedPromptLength)}${separator}${protection}`;
}

function generationRequestNotice() {
  const count = getGenerationCount();
  return count > 1 ? `；${count} 张并发 ${count} 次请求` : "";
}

function saveSettings() {
  try {
    localStorage.setItem(SETTINGS_STORAGE, JSON.stringify({
      schemaVersion: SETTINGS_SCHEMA_VERSION,
      model: selectedApiModel(),
      aspectRatio: elements.aspectRatio.value,
      resolution: elements.resolution.value,
      generationCount: getGenerationCount(),
      precisionPlacement: elements.precisionPlacement.checked,
      localEditMode: selectedLocalEditMode(),
      favoritePrompts: state.favoritePrompts
    }));
  } catch (_) {
    // Non-sensitive preferences are optional.
  }
}

function loadSettings() {
  try {
    const settings = JSON.parse(localStorage.getItem(SETTINGS_STORAGE) || "{}");
    if (settings.model && elements.modelChannel.querySelector(`option[value="${settings.model}"]`)) {
      elements.modelChannel.value = settings.model;
    }
    if (settings.aspectRatio && elements.aspectRatio.querySelector(`option[value="${settings.aspectRatio}"]`)) {
      elements.aspectRatio.value = settings.aspectRatio;
    }
    if (
      Number(settings.schemaVersion) >= SETTINGS_SCHEMA_VERSION &&
      ["1K", "2K", "4K"].includes(settings.resolution)
    ) {
      elements.resolution.value = settings.resolution;
    }
    if ([1, 2, 3, 4].includes(Number(settings.generationCount))) {
      elements.generationCount.value = String(settings.generationCount);
    }
    if (typeof settings.precisionPlacement === "boolean") {
      elements.precisionPlacement.checked = settings.precisionPlacement;
    }
    if (LOCAL_EDIT_MODES.includes(String(settings.localEditMode || ""))) {
      elements.localEditMode.value = settings.localEditMode;
    }
    state.favoritePrompts = normalizePromptList(settings.favoritePrompts, MAX_FAVORITE_PROMPTS);
  } catch (_) {
    // Use defaults when preferences were cleared or corrupted.
  }
  syncModelCapabilities();
  renderPromptLibrary();
}

function safeStorageFileName(value) {
  const name = String(value || "");
  return /^[A-Za-z0-9][A-Za-z0-9._-]{0,220}$/.test(name) ? name : "";
}

function storageBounds(bounds) {
  if (!bounds) return null;
  const left = Number(bounds.left) || 0;
  const top = Number(bounds.top) || 0;
  const right = Number.isFinite(Number(bounds.right)) ? Number(bounds.right) : left + (Number(bounds.width) || 0);
  const bottom = Number.isFinite(Number(bounds.bottom)) ? Number(bounds.bottom) : top + (Number(bounds.height) || 0);
  return {
    left,
    top,
    right,
    bottom,
    width: Math.max(0, Number(bounds.width) || right - left),
    height: Math.max(0, Number(bounds.height) || bottom - top)
  };
}

function serializeSnapshot(snapshot, maskFileName) {
  if (!snapshot) return null;
  let mask = null;
  if (snapshot.mask) {
    mask = {
      fileName: safeStorageFileName(maskFileName),
      width: Number(snapshot.mask.width) || 0,
      height: Number(snapshot.mask.height) || 0,
      bounds: storageBounds(snapshot.mask.bounds)
    };
  } else if (snapshot.maskUnavailable && snapshot.persistedMask) {
    mask = {
      fileName: safeStorageFileName(snapshot.persistedMask.fileName),
      width: Number(snapshot.persistedMask.width) || 0,
      height: Number(snapshot.persistedMask.height) || 0,
      bounds: storageBounds(snapshot.persistedMask.bounds)
    };
  }
  return {
    id: String(snapshot.id || ""),
    sourceReferenceId: String(snapshot.sourceReferenceId || ""),
    mode: String(snapshot.mode || "import"),
    documentId: snapshot.documentId === null || snapshot.documentId === undefined
      ? null
      : Number(snapshot.documentId),
    documentTitle: String(snapshot.documentTitle || ""),
    documentWidth: Number(snapshot.documentWidth) || 0,
    documentHeight: Number(snapshot.documentHeight) || 0,
    documentResolution: Number(snapshot.documentResolution) || 72,
    documentMode: snapshot.documentMode === undefined ? null : snapshot.documentMode,
    bounds: storageBounds(snapshot.bounds),
    editBounds: storageBounds(snapshot.editBounds),
    localEditMode: LOCAL_EDIT_MODES.includes(String(snapshot.localEditMode || ""))
      ? String(snapshot.localEditMode)
      : "",
    solid: Boolean(snapshot.solid),
    mask,
    layerId: snapshot.layerId === null || snapshot.layerId === undefined ? null : Number(snapshot.layerId),
    layerName: String(snapshot.layerName || ""),
    insertionAnchorLayerId: snapshot.insertionAnchorLayerId === null || snapshot.insertionAnchorLayerId === undefined
      ? null
      : Number(snapshot.insertionAnchorLayerId),
    insertionAnchorLayerName: String(snapshot.insertionAnchorLayerName || ""),
    insertionAnchorParentId: snapshot.insertionAnchorParentId === null || snapshot.insertionAnchorParentId === undefined
      ? null
      : Number(snapshot.insertionAnchorParentId),
    capturedAt: new Date(snapshot.capturedAt || Date.now()).toISOString()
  };
}

function deserializeSnapshot(value, maskBytes, maskUnavailable) {
  if (!value || !value.bounds) return null;
  const bounds = storageBounds(value.bounds);
  if (!bounds || bounds.width <= 0 || bounds.height <= 0) return null;
  const persistedMask = value.mask ? {
    fileName: safeStorageFileName(value.mask.fileName),
    width: Number(value.mask.width) || 0,
    height: Number(value.mask.height) || 0,
    bounds: storageBounds(value.mask.bounds)
  } : null;
  const mask = persistedMask && maskBytes ? {
    bytes: maskBytes,
    width: persistedMask.width,
    height: persistedMask.height,
    bounds: persistedMask.bounds
  } : null;
  return {
    id: String(value.id || ""),
    sourceReferenceId: String(value.sourceReferenceId || ""),
    mode: String(value.mode || "import"),
    documentId: value.documentId === null || value.documentId === undefined ? null : Number(value.documentId),
    documentTitle: String(value.documentTitle || ""),
    documentWidth: Number(value.documentWidth) || 0,
    documentHeight: Number(value.documentHeight) || 0,
    documentResolution: Number(value.documentResolution) || 72,
    documentMode: value.documentMode === undefined ? null : value.documentMode,
    bounds,
    editBounds: storageBounds(value.editBounds),
    localEditMode: LOCAL_EDIT_MODES.includes(String(value.localEditMode || ""))
      ? String(value.localEditMode)
      : "",
    solid: Boolean(value.solid),
    mask,
    maskUnavailable: Boolean(persistedMask && maskUnavailable),
    persistedMask,
    layerId: value.layerId === null || value.layerId === undefined ? null : Number(value.layerId),
    layerName: String(value.layerName || ""),
    insertionAnchorLayerId: value.insertionAnchorLayerId === null || value.insertionAnchorLayerId === undefined
      ? null
      : Number(value.insertionAnchorLayerId),
    insertionAnchorLayerName: String(value.insertionAnchorLayerName || ""),
    insertionAnchorParentId: value.insertionAnchorParentId === null || value.insertionAnchorParentId === undefined
      ? null
      : Number(value.insertionAnchorParentId),
    capturedAt: new Date(value.capturedAt || Date.now())
  };
}

async function getFolderEntrySafely(folder, fileName) {
  const safeName = safeStorageFileName(fileName);
  if (!folder || !safeName) return null;
  try {
    return await folder.getEntry(safeName);
  } catch (_) {
    return null;
  }
}

async function getPersistentHistoryFolder() {
  if (!persistentHistoryFolderPromise) {
    persistentHistoryFolderPromise = (async () => {
      const dataFolder = await localFileSystem.getDataFolder();
      const existing = await getFolderEntrySafely(dataFolder, PERSISTENT_HISTORY_FOLDER);
      return existing || await dataFolder.createFolder(PERSISTENT_HISTORY_FOLDER);
    })().catch((error) => {
      persistentHistoryFolderPromise = null;
      throw error;
    });
  }
  return await persistentHistoryFolderPromise;
}

function snapshotMaskBytes(snapshot) {
  if (!snapshot || !snapshot.mask || !snapshot.mask.bytes) return null;
  const source = snapshot.mask.bytes;
  if (source instanceof Uint8Array) {
    const owned = new Uint8Array(source.byteLength);
    owned.set(source);
    return owned;
  }
  if (source instanceof ArrayBuffer) return new Uint8Array(source.slice(0));
  if (ArrayBuffer.isView(source)) {
    const view = new Uint8Array(source.buffer, source.byteOffset, source.byteLength);
    const owned = new Uint8Array(view.byteLength);
    owned.set(view);
    return owned;
  }
  return null;
}

async function writeSnapshotMask(folder, snapshot, fileName) {
  const bytes = snapshotMaskBytes(snapshot);
  if (!bytes) return null;
  const safeName = safeStorageFileName(fileName);
  if (!safeName) throw new Error("无法建立选区蒙版保存文件");
  const expected = (Number(snapshot.mask.width) || 0) * (Number(snapshot.mask.height) || 0);
  if (!(expected > 0) || bytes.byteLength !== expected) {
    throw new Error("选区蒙版数据不完整，无法保存生成历史");
  }
  const file = await folder.createFile(safeName, { overwrite: true });
  await file.write(exactArrayBuffer(bytes), { format: formats.binary });
  return file;
}

async function ensureSnapshotMaskStored(owner, prefix) {
  if (!owner || !owner.snapshot || !owner.snapshot.mask) return null;
  if (owner.maskFile && owner.maskFileName) return owner.maskFile;
  const folder = await getPersistentHistoryFolder();
  const safeId = String(owner.id || Date.now()).replace(/[^A-Za-z0-9_-]/g, "").slice(0, 120) || String(Date.now());
  owner.maskFileName = safeStorageFileName(owner.maskFileName) || `${prefix}-mask-${safeId}.bin`;
  owner.maskFile = await writeSnapshotMask(folder, owner.snapshot, owner.maskFileName);
  return owner.maskFile;
}

async function loadSnapshotMask(folder, maskRecord) {
  if (!maskRecord) return { bytes: null, file: null, fileName: "", unavailable: false };
  const fileName = safeStorageFileName(maskRecord.fileName);
  const width = Number(maskRecord.width) || 0;
  const height = Number(maskRecord.height) || 0;
  if (!fileName || !(width > 0) || !(height > 0)) {
    return { bytes: null, file: null, fileName, unavailable: true };
  }
  const file = await getFolderEntrySafely(folder, fileName);
  if (!file) return { bytes: null, file: null, fileName, unavailable: true };
  try {
    const raw = await file.read({ format: formats.binary });
    const view = new Uint8Array(exactArrayBuffer(raw));
    if (view.byteLength !== width * height) {
      return { bytes: null, file, fileName, unavailable: true };
    }
    const bytes = new Uint8Array(view.byteLength);
    bytes.set(view);
    return { bytes, file, fileName, unavailable: false };
  } catch (_) {
    return { bytes: null, file, fileName, unavailable: true };
  }
}

async function loadSerializedSnapshot(folder, value) {
  const loadedMask = await loadSnapshotMask(folder, value && value.mask);
  return {
    snapshot: deserializeSnapshot(value, loadedMask.bytes, loadedMask.unavailable),
    maskFile: loadedMask.file,
    maskFileName: loadedMask.fileName
  };
}

function serializePersistentResult(result) {
  return {
    id: String(result.id || ""),
    sequence: Number(result.sequence) || 0,
    fileName: safeStorageFileName(result.storageFileName || (result.file && result.file.name)),
    mime: String(result.mime || ""),
    extension: String(result.extension || ""),
    byteLength: Number(result.byteLength) || 0,
    width: Number(result.width) || 0,
    height: Number(result.height) || 0,
    count: Number(result.count) || 1,
    prompt: String(result.prompt || "").slice(0, 20000),
    requested: result.requested || null,
    createdAt: new Date(result.createdAt || Date.now()).toISOString(),
    insertedAt: result.insertedAt ? new Date(result.insertedAt).toISOString() : null,
    precisePlacement: typeof result.precisePlacement === "boolean" ? result.precisePlacement : null,
    imageFingerprint: String(result.imageFingerprint || ""),
    recoveredFromHistory: Boolean(result.recoveredFromHistory),
    historyRecordKey: String(result.historyRecordKey || ""),
    sourceJobId: String(result.sourceJobId || ""),
    snapshot: serializeSnapshot(result.snapshot, result.maskFileName)
  };
}

function serializePendingHistoryTask(task) {
  return {
    id: String(task.id || ""),
    sequence: Number(task.sequence) || 0,
    prompt: String(task.prompt || "").slice(0, 20000),
    requestPrompt: String(task.requestPrompt || task.prompt || "").slice(0, 20000),
    model: String(task.model || task.requested && task.requested.model || API_CONFIG.model),
    requested: task.requested || null,
    requestedCount: Number(task.requestedCount) || 1,
    submittedCount: Number(task.submittedCount) || 0,
    resolvedCount: Number(task.resolvedCount) || 0,
    knownFailedCount: Number(task.knownFailedCount) || 0,
    aspectRatio: String(task.aspectRatio || "auto"),
    resolution: String(task.resolution || "1K"),
    precisionPlacement: Boolean(task.precisionPlacement),
    localEditMode: LOCAL_EDIT_MODES.includes(String(task.localEditMode || ""))
      ? String(task.localEditMode)
      : "general",
    autoRecoveryExhausted: Boolean(task.autoRecoveryExhausted),
    autoRecoveryStartedAt: Math.max(0, Number(task.autoRecoveryStartedAt) || 0),
    createdAt: new Date(task.createdAt || Date.now()).toISOString(),
    historyBaselineKeys: Array.from(task.historyBaselineKeys || []).map(String),
    recoveredHistoryKeys: Array.from(task.recoveredHistoryKeys || []).map(String),
    snapshot: serializeSnapshot(task.snapshot, task.maskFileName)
  };
}

function pendingHistoryOutstandingCount(task) {
  if (!task) return 0;
  const submitted = Math.max(0, Math.min(Number(task.requestedCount) || 0, Number(task.submittedCount) || 0));
  const resolved = Math.max(0, Number(task.resolvedCount) || 0);
  const knownFailed = Math.max(0, Number(task.knownFailedCount) || 0);
  return Math.max(0, submitted - resolved - knownFailed);
}

async function persistHistoryStateNow() {
  const folder = await getPersistentHistoryFolder();
  for (const result of state.results) await ensureSnapshotMaskStored(result, "result");
  for (const task of state.pendingHistoryTasks) await ensureSnapshotMaskStored(task, "pending");
  const index = {
    schemaVersion: PERSISTENT_HISTORY_SCHEMA_VERSION,
    savedAt: new Date().toISOString(),
    resultSequence: Number(state.resultSequence) || 0,
    generationJobSequence: Number(state.generationJobSequence) || 0,
    results: state.results.filter((result) => result && result.file && !result.released).map(serializePersistentResult),
    pendingTasks: state.pendingHistoryTasks.map(serializePendingHistoryTask)
  };
  const file = await folder.createFile(PERSISTENT_HISTORY_INDEX, { overwrite: true });
  await file.write(JSON.stringify(index), { format: formats.utf8 });
  state.historyPersistenceError = "";
  return true;
}

function queuePersistHistoryState() {
  historyPersistenceQueue = historyPersistenceQueue.catch(() => false).then(async () => {
    try {
      return await persistHistoryStateNow();
    } catch (error) {
      state.historyPersistenceError = sanitizeMessage(error && (error.message || error));
      return false;
    }
  });
  return historyPersistenceQueue;
}

async function loadPersistentHistoryState() {
  state.loadingPersistentHistory = true;
  updateControls();
  let needsCleanup = false;
  try {
    const folder = await getPersistentHistoryFolder();
    const indexFile = await getFolderEntrySafely(folder, PERSISTENT_HISTORY_INDEX);
    if (!indexFile) return;
    let index = null;
    try {
      index = JSON.parse(String(await indexFile.read({ format: formats.utf8 }) || "{}"));
    } catch (error) {
      state.historyPersistenceError = "本地生成历史索引无法读取，将从新的结果重新记录";
      return;
    }
    if (Number(index.schemaVersion) !== PERSISTENT_HISTORY_SCHEMA_VERSION) return;

    const loadedResults = [];
    const resultRecords = Array.isArray(index.results) ? index.results.slice(0, MAX_RESULTS) : [];
    for (const record of resultRecords) {
      const fileName = safeStorageFileName(record && record.fileName);
      const file = await getFolderEntrySafely(folder, fileName);
      if (!file) {
        needsCleanup = true;
        continue;
      }
      let buffer = null;
      let detected = null;
      try {
        buffer = exactArrayBuffer(await file.read({ format: formats.binary }));
        detected = detectImageType(buffer);
        if (!buffer.byteLength || detected.width * detected.height > API_CONFIG.maxOutputPixels) {
          throw new Error("本地历史图片无效");
        }
      } catch (_) {
        await safeDelete(file);
        needsCleanup = true;
        continue;
      }
      const loadedSnapshot = await loadSerializedSnapshot(folder, record.snapshot);
      if (!loadedSnapshot.snapshot) {
        await safeDelete(file);
        await safeDelete(loadedSnapshot.maskFile);
        needsCleanup = true;
        continue;
      }
      const createdAt = new Date(record.createdAt || Date.now());
      const result = {
        id: String(record.id || `result-restored-${Date.now()}-${loadedResults.length + 1}`),
        sequence: Math.max(1, Number(record.sequence) || loadedResults.length + 1),
        file,
        storageFileName: fileName,
        previewUrl: null,
        mime: detected.mime,
        extension: detected.extension,
        byteLength: buffer.byteLength,
        width: detected.width,
        height: detected.height,
        count: Number(record.count) || 1,
        snapshot: loadedSnapshot.snapshot,
        maskFile: loadedSnapshot.maskFile,
        maskFileName: loadedSnapshot.maskFileName,
        requested: record.requested || null,
        prompt: String(record.prompt || "").slice(0, 20000),
        requestPrompt: String(record.requestPrompt || record.prompt || "").slice(0, 20000),
        taskArchive: null,
        imageFingerprint: String(record.imageFingerprint || imageBufferFingerprint(buffer)),
        recoveredFromHistory: Boolean(record.recoveredFromHistory),
        historyRecordKey: String(record.historyRecordKey || ""),
        sourceJobId: String(record.sourceJobId || ""),
        createdAt: Number.isNaN(createdAt.getTime()) ? new Date() : createdAt,
        insertedAt: record.insertedAt ? new Date(record.insertedAt) : null,
        precisePlacement: typeof record.precisePlacement === "boolean" ? record.precisePlacement : null,
        openedAt: null,
        openedFiles: [],
        persistent: true,
        released: false
      };
      await createResultPreview(result, buffer);
      loadedResults.push(result);
    }
    loadedResults.sort((left, right) => right.createdAt.getTime() - left.createdAt.getTime());
    state.results = loadedResults.slice(0, MAX_RESULTS);
    state.resultSequence = Math.max(
      Number(index.resultSequence) || 0,
      ...state.results.map((result) => Number(result.sequence) || 0)
    );
    state.generationJobSequence = Math.max(0, Number(index.generationJobSequence) || 0);

    const pendingTasks = [];
    const pendingRecords = Array.isArray(index.pendingTasks) ? index.pendingTasks : [];
    const now = Date.now();
    for (const record of pendingRecords) {
      const createdAt = new Date(record && record.createdAt || Date.now());
      const createdTime = createdAt.getTime();
      const loadedSnapshot = await loadSerializedSnapshot(folder, record && record.snapshot);
      if (
        !loadedSnapshot.snapshot || Number.isNaN(createdTime) ||
        now - createdTime > HISTORY_PENDING_RETENTION_MS
      ) {
        await safeDelete(loadedSnapshot.maskFile);
        needsCleanup = true;
        continue;
      }
      const requestedCount = Math.max(1, Math.min(4, Number(record.requestedCount) || 1));
      const autoRecoveryStartedAt = Math.max(0, Number(record.autoRecoveryStartedAt) || 0);
      const task = {
        id: String(record.id || `pending-${createdTime}-${pendingTasks.length + 1}`),
        sequence: Number(record.sequence) || pendingTasks.length + 1,
        prompt: String(record.prompt || "").slice(0, 20000),
        requestPrompt: String(record.requestPrompt || record.prompt || "").slice(0, 20000),
        model: String(record.model || record.requested && record.requested.model || API_CONFIG.model),
        requested: record.requested || null,
        requestedCount,
        submittedCount: Math.max(0, Math.min(requestedCount, Number(record.submittedCount) || 0)),
        resolvedCount: Math.max(0, Number(record.resolvedCount) || 0),
        knownFailedCount: Math.max(0, Number(record.knownFailedCount) || 0),
        aspectRatio: String(record.aspectRatio || "auto"),
        resolution: String(record.resolution || "1K"),
        precisionPlacement: Boolean(record.precisionPlacement),
        localEditMode: LOCAL_EDIT_MODES.includes(String(record.localEditMode || ""))
          ? String(record.localEditMode)
          : "general",
        autoRecoveryExhausted: Boolean(record.autoRecoveryExhausted) || Boolean(
          autoRecoveryStartedAt && now >= autoRecoveryStartedAt + HISTORY_RECOVERY_TIMEOUT_MS
        ),
        autoRecoveryStartedAt,
        createdAt,
        historyBaselineKeys: new Set(Array.isArray(record.historyBaselineKeys) ? record.historyBaselineKeys.map(String) : []),
        recoveredHistoryKeys: new Set(Array.isArray(record.recoveredHistoryKeys) ? record.recoveredHistoryKeys.map(String) : []),
        snapshot: loadedSnapshot.snapshot,
        maskFile: loadedSnapshot.maskFile,
        maskFileName: loadedSnapshot.maskFileName
      };
      const locallyStoredCount = state.results.filter((result) => result.sourceJobId === task.id).length;
      task.resolvedCount = Math.max(task.resolvedCount, locallyStoredCount);
      if (pendingHistoryOutstandingCount(task) <= 0) {
        await safeDelete(task.maskFile);
        needsCleanup = true;
        continue;
      }
      pendingTasks.push(task);
    }
    state.pendingHistoryTasks = pendingTasks;
    state.selectedResultId = state.results.length ? state.results[0].id : null;
    renderResultHistory();
  } catch (error) {
    state.historyPersistenceError = sanitizeMessage(error && (error.message || error));
  } finally {
    state.loadingPersistentHistory = false;
    updateControls();
    if (needsCleanup) queuePersistHistoryState();
  }
}

async function registerPendingHistoryTask(job) {
  const task = {
    id: job.id,
    sequence: job.sequence,
    prompt: job.prompt,
    requestPrompt: job.requestPrompt || job.prompt,
    model: job.model || job.requested && job.requested.model || API_CONFIG.model,
    requested: job.requested,
    requestedCount: job.requestedCount,
    submittedCount: 0,
    resolvedCount: 0,
    knownFailedCount: 0,
    aspectRatio: job.aspectRatio,
    resolution: job.resolution,
    precisionPlacement: job.precisionPlacement,
    localEditMode: job.localEditMode || "general",
    autoRecoveryExhausted: false,
    autoRecoveryStartedAt: 0,
    createdAt: job.createdAt,
    historyBaselineKeys: new Set(),
    recoveredHistoryKeys: new Set(),
    snapshot: job.snapshot,
    maskFile: null,
    maskFileName: ""
  };
  job.pendingHistoryTask = task;
  state.pendingHistoryTasks = state.pendingHistoryTasks.filter((item) => item.id !== task.id);
  state.pendingHistoryTasks.push(task);
  await ensureSnapshotMaskStored(task, "pending");
  const persisted = await queuePersistHistoryState();
  if (!persisted) {
    state.pendingHistoryTasks = state.pendingHistoryTasks.filter((item) => item.id !== task.id);
    await safeDelete(task.maskFile);
    task.maskFile = null;
    throw new Error("无法保存待找回任务；为避免断线后丢失结果，本次没有发送生成请求");
  }
  return task;
}

function pendingTaskForJob(job) {
  if (job && job.pendingHistoryTask) return job.pendingHistoryTask;
  return state.pendingHistoryTasks.find((task) => task.id === (job && job.id)) || null;
}

async function updatePendingHistoryTask(job) {
  const task = pendingTaskForJob(job);
  if (!task) return false;
  if (job && job.historyBaselineKeys) task.historyBaselineKeys = new Set(job.historyBaselineKeys);
  return await queuePersistHistoryState();
}

async function markPendingRequestSubmitted(job) {
  const task = pendingTaskForJob(job);
  if (!task) return false;
  const previous = Number(task.submittedCount) || 0;
  task.submittedCount = Math.min(task.requestedCount, Number(task.submittedCount || 0) + 1);
  const persisted = await updatePendingHistoryTask(job);
  if (!persisted) task.submittedCount = previous;
  return persisted;
}

async function unmarkPendingRequestSubmitted(job) {
  const task = pendingTaskForJob(job);
  if (!task) return false;
  task.submittedCount = Math.max(0, Number(task.submittedCount || 0) - 1);
  return await updatePendingHistoryTask(job);
}

async function markPendingRequestResolved(job, historyKey) {
  const task = pendingTaskForJob(job);
  if (!task) return false;
  task.resolvedCount = Math.min(task.requestedCount, Number(task.resolvedCount || 0) + 1);
  if (historyKey) task.recoveredHistoryKeys.add(String(historyKey));
  return await updatePendingHistoryTask(job);
}

async function markPendingRequestKnownFailed(job) {
  const task = pendingTaskForJob(job);
  if (!task) return false;
  task.knownFailedCount = Math.min(task.requestedCount, Number(task.knownFailedCount || 0) + 1);
  return await updatePendingHistoryTask(job);
}

async function removePendingHistoryTask(taskOrId) {
  const id = typeof taskOrId === "string" ? taskOrId : String(taskOrId && taskOrId.id || "");
  const index = state.pendingHistoryTasks.findIndex((task) => task.id === id);
  if (index < 0) return false;
  const removed = state.pendingHistoryTasks.splice(index, 1)[0];
  await safeDelete(removed.maskFile);
  removed.maskFile = null;
  await queuePersistHistoryState();
  return true;
}

function stringToUtf8Bytes(value) {
  const text = String(value || "");
  if (typeof TextEncoder !== "undefined") return new TextEncoder().encode(text);
  const bytes = [];
  const encoded = encodeURIComponent(text);
  for (let index = 0; index < encoded.length; index += 1) {
    if (encoded[index] === "%") {
      bytes.push(parseInt(encoded.slice(index + 1, index + 3), 16));
      index += 2;
    } else {
      bytes.push(encoded.charCodeAt(index));
    }
  }
  return new Uint8Array(bytes);
}

async function loadApiKey() {
  try {
    const stored = await secureStorage.getItem(API_KEY_STORAGE);
    if (stored && stored.length) {
      state.apiKey = typeof stored === "string"
        ? stored
        : utf8BytesToString(stored instanceof Uint8Array ? stored : new Uint8Array(stored));
      return Boolean(state.apiKey);
    }
  } catch (_) {
    state.apiKey = "";
  }
  return false;
}

async function saveApiKey(value) {
  const key = String(value || "").trim();
  if (!key) throw new Error("请输入 API Key");
  await secureStorage.setItem(API_KEY_STORAGE, stringToUtf8Bytes(key));
  state.apiKey = key;
}

async function clearStoredApiKey() {
  state.apiKey = "";
  try {
    const existing = await secureStorage.getItem(API_KEY_STORAGE);
    if (existing && existing.length) await secureStorage.removeItem(API_KEY_STORAGE);
  } catch (_) {
    // The next run still opens the key dialog even if storage cleanup failed.
  }
}

function showKeyDialog(resumeAfterSave) {
  state.resumeAfterKey = Boolean(resumeAfterSave);
  setKeyInputValue("");
  elements.keyError.textContent = "";
  elements.keyOverlay.classList.remove("is-hidden");
  setTimeout(() => elements.keyInput.focus(), 0);
}

function hideKeyDialog() {
  elements.keyOverlay.classList.add("is-hidden");
  setKeyInputValue("");
  elements.keyError.textContent = "";
}

async function safeDelete(entry) {
  if (!entry) return;
  try {
    await entry.delete();
  } catch (_) {
    // Temporary storage may already have removed the entry.
  }
}

function revokeReferencePreview(reference) {
  if (!reference || !reference.previewUrl) return;
  try {
    URL.revokeObjectURL(reference.previewUrl);
  } catch (_) {
    // The host may already have released the URL.
  }
  reference.previewUrl = null;
}

async function createReferencePreview(reference) {
  if (!reference || reference.released || !reference.file || typeof ImageBlob === "undefined") return;
  try {
    const fileBytes = await reference.file.read({ format: formats.binary });
    const imageBlob = new ImageBlob(exactArrayBuffer(fileBytes), {
      type: reference.mime || "image/jpeg"
    });
    reference.previewUrl = URL.createObjectURL(imageBlob);
  } catch (_) {
    reference.previewUrl = null;
  }
}

async function maybeReleaseReference(reference) {
  if (
    !reference || reference.released || reference.inReferenceList ||
    Number(reference.resultOwners) > 0
  ) return;
  revokeReferencePreview(reference);
  await safeDelete(reference.file);
  reference.file = null;
  reference.released = true;
}

async function releaseReference(reference) {
  if (!reference) return;
  reference.inReferenceList = false;
  await maybeReleaseReference(reference);
}

function retainGenerationJobReferences(job) {
  job.references.forEach((reference) => {
    reference.resultOwners = Number(reference.resultOwners || 0) + 1;
  });
}

async function releaseGenerationJobReferences(job) {
  const references = job.references.splice(0);
  for (const reference of references) {
    reference.resultOwners = Math.max(0, Number(reference.resultOwners || 0) - 1);
    await maybeReleaseReference(reference);
  }
}

function retainTaskArchive(taskArchive) {
  if (!taskArchive || !Array.isArray(taskArchive.references)) return;
  const previousOwners = Number(taskArchive.historyOwners || 0);
  taskArchive.historyOwners = previousOwners + 1;
  if (previousOwners > 0) return;
  taskArchive.references.forEach((reference) => {
    reference.resultOwners = Number(reference.resultOwners || 0) + 1;
  });
}

async function releaseTaskArchive(taskArchive) {
  if (!taskArchive || !Array.isArray(taskArchive.references)) return;
  const previousOwners = Number(taskArchive.historyOwners || 0);
  taskArchive.historyOwners = Math.max(0, previousOwners - 1);
  if (previousOwners !== 1) return;
  for (const reference of taskArchive.references) {
    reference.resultOwners = Math.max(0, Number(reference.resultOwners || 0) - 1);
    await maybeReleaseReference(reference);
  }
}

function getSelectedResult() {
  return state.results.find((result) => result.id === state.selectedResultId) || null;
}

function revokeResultPreview(result) {
  if (!result || !result.previewUrl) return;
  try {
    URL.revokeObjectURL(result.previewUrl);
  } catch (_) {
    // The host may already have released the URL.
  }
  result.previewUrl = null;
}

async function createResultPreview(result, buffer) {
  if (!result || typeof ImageBlob === "undefined") return;
  try {
    const imageBlob = new ImageBlob(exactArrayBuffer(buffer), { type: result.mime });
    result.previewUrl = URL.createObjectURL(imageBlob);
  } catch (_) {
    result.previewUrl = null;
  }
}

async function releaseResult(result) {
  if (!result || result.released) return;
  revokeResultPreview(result);
  const openedFiles = Array.isArray(result.openedFiles) ? result.openedFiles.splice(0) : [];
  for (const openedFile of openedFiles) await safeDelete(openedFile);
  await safeDelete(result.file);
  await safeDelete(result.maskFile);
  await releaseTaskArchive(result.taskArchive);
  result.taskArchive = null;
  result.file = null;
  result.maskFile = null;
  result.released = true;
}

function setImageSource(imageElement, item) {
  imageElement.removeAttribute("src");
  if (!item) return false;
  try {
    imageElement.src = item.previewUrl || item.file;
    return true;
  } catch (_) {
    imageElement.removeAttribute("src");
    return false;
  }
}

function formatResultTime(value) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

function renderSelectedResult() {
  const result = getSelectedResult();
  if (!result) {
    elements.resultImage.classList.add("is-hidden");
    elements.resultImage.removeAttribute("src");
    elements.resultEmpty.classList.remove("is-hidden");
    elements.insert.textContent = "插入图层";
    updateControls();
    return;
  }

  setImageSource(elements.resultImage, result);
  elements.resultImage.classList.remove("is-hidden");
  elements.resultEmpty.classList.add("is-hidden");
  if (hasPhotoshopDocument(result.snapshot)) {
    const supportsPrecisePlacement = hasPhotoshopTarget(result.snapshot);
    if (
      supportsPrecisePlacement &&
      result.insertedAt &&
      typeof result.precisePlacement === "boolean"
    ) {
      elements.precisionPlacement.checked = result.precisePlacement;
    }
    elements.insert.textContent = result.insertedAt
      ? (supportsPrecisePlacement && (hasSmartLocalTarget(result.snapshot) || result.precisePlacement !== false) ? "再次精确插入" : "再次插入")
      : "插入图层";
  } else {
    elements.insert.textContent = result.openedAt ? "再次在 PS 打开" : "在 PS 中打开";
  }
  updateControls();
}

function computeGenerationVisualProgress(job, now = Date.now()) {
  const requestedCount = Math.max(1, Number(job && job.requestedCount) || 1);
  const settledCount = Math.max(0, Math.min(requestedCount, Number(job && job.settledCount) || 0));
  const previous = Number(job.visualProgress) || 8;
  if (job.progressCompleting) {
    return Math.min(96, Math.max(8, previous));
  }
  if (["complete", "failed", "stopped"].includes(job.status)) {
    return 100;
  }
  if (settledCount >= requestedCount) {
    return Math.min(96, Math.max(8, previous));
  }

  const createdAt = job.createdAt instanceof Date
    ? job.createdAt.getTime()
    : new Date(job.createdAt || now).getTime();
  const elapsedSeconds = Math.max(0, (now - (Number.isFinite(createdAt) ? createdAt : now)) / 1000);
  const pendingEstimate = 8 + 88 * (1 - Math.exp(-elapsedSeconds / 55));
  const settledRatio = settledCount / requestedCount;
  const combinedEstimate = settledRatio * 100 + (1 - settledRatio) * pendingEstimate;
  return Math.min(96, Math.max(8, previous, combinedEstimate));
}

function generationProgressActivity(job) {
  if (job.status === "stopping") return "停止中";
  if (job.status === "recovering") return "从历史找回中";
  if (job.status === "complete") return "已完成";
  if (job.status === "stopped") return "已停止";
  if (job.status === "failed") return "已结束";
  return job.settledCount > 0 ? "继续生成中" : "生成中";
}

function generationPulsePosition(job, now = Date.now()) {
  const offset = (Number(job && job.sequence) || 0) * 3;
  const step = (Math.floor(now / GENERATION_PROGRESS_TICK_MS) + offset) % 20;
  return step <= 10 ? step * 10 : (20 - step) * 10;
}

function updateGenerationProgressVisuals() {
  if (!elements.generationQueue || !state.generationJobs.length) return;
  const now = Date.now();
  const items = Array.from(elements.generationQueue.children || []);
  state.generationJobs.forEach((job) => {
    const progress = computeGenerationVisualProgress(job, now);
    job.visualProgress = progress;
    const item = items.find((candidate) => (
      candidate.getAttribute &&
      candidate.getAttribute("data-generation-job-id") === job.id
    ));
    if (!item) return;
    const track = item.querySelector(".generation-job-progress");
    const fill = item.querySelector(".generation-job-progress-fill");
    if (track) {
      track.setAttribute("aria-valuenow", String(Math.round(progress)));
      track.setAttribute(
        "aria-valuetext",
        `${generationProgressActivity(job)}，已完成 ${job.completedCount} / ${job.requestedCount}`
      );
    }
    if (fill) {
      fill.style.width = `${Math.min(100, progress)}%`;
      fill.style.backgroundPosition = `${generationPulsePosition(job, now)}% 0`;
    }
  });
}

function syncGenerationProgressTimer() {
  if (state.generationJobs.length) {
    if (generationProgressTimer === null) {
      generationProgressTimer = setInterval(
        updateGenerationProgressVisuals,
        GENERATION_PROGRESS_TICK_MS
      );
    }
    return;
  }
  if (generationProgressTimer !== null) {
    clearInterval(generationProgressTimer);
    generationProgressTimer = null;
  }
}

function waitForGenerationProgressCompletion() {
  return new Promise((resolve) => {
    setTimeout(resolve, GENERATION_PROGRESS_COMPLETION_MS);
  });
}

function waitForGenerationProgressFrame() {
  return new Promise((resolve) => {
    setTimeout(resolve, 40);
  });
}

function renderGenerationQueue() {
  while (elements.generationQueue.firstChild) {
    elements.generationQueue.removeChild(elements.generationQueue.firstChild);
  }

  const jobs = state.generationJobs;
  elements.generationQueue.classList.toggle("is-hidden", !jobs.length);

  jobs.forEach((job) => {
    const item = document.createElement("div");
    item.className = "generation-job";
    item.title = job.prompt;
    item.setAttribute("data-generation-job-id", job.id);

    const row = document.createElement("div");
    row.className = "generation-job-row";

    const title = document.createElement("span");
    title.className = "generation-job-title";
    title.textContent = `任务 ${job.sequence} · ${job.modelLabel || getModelConfig(job.model).shortLabel} · ${truncatePromptLabel(job.prompt, 24)}`;

    const count = document.createElement("span");
    count.className = "generation-job-count";
    const costNote = normalizePriceValue(job.estimatedCost) !== null
      ? ` · 预计 ${formatYuan(job.estimatedCost)}${job.priceUnverified ? "（未核实）" : ""}`
      : (job.priceUnverified ? " · 价格未确认" : "");
    const failedLabel = job.status === "recovering" ? "待找回" : "失败";
    const failedNote = job.failedCount ? ` · ${failedLabel} ${job.failedCount}` : "";
    const recoveredNote = job.recoveredCount ? ` · 已找回 ${job.recoveredCount}` : "";
    count.textContent = `${job.completedCount} / ${job.requestedCount} · ${generationProgressActivity(job)}${costNote}${failedNote}${recoveredNote}`;

    const track = document.createElement("div");
    track.className = "generation-job-progress";
    track.setAttribute("role", "progressbar");
    track.setAttribute("aria-valuemin", "0");
    track.setAttribute("aria-valuemax", "100");
    track.title = "生成过程为平滑估算；接口返回后才会确认 100%";
    const fill = document.createElement("div");
    fill.className = "generation-job-progress-fill";
    const progress = computeGenerationVisualProgress(job);
    job.visualProgress = progress;
    track.setAttribute("aria-valuenow", String(Math.round(progress)));
    track.setAttribute(
      "aria-valuetext",
      `${generationProgressActivity(job)}，已完成 ${job.completedCount} / ${job.requestedCount}`
    );
    fill.style.width = `${Math.min(100, progress)}%`;
    fill.style.backgroundPosition = `${generationPulsePosition(job)}% 0`;

    row.appendChild(title);
    row.appendChild(count);
    track.appendChild(fill);
    item.appendChild(row);
    item.appendChild(track);
    elements.generationQueue.appendChild(item);
  });

  syncGenerationProgressTimer();
  updateControls();
}

function renderResultHistory() {
  while (elements.resultHistory.firstChild) {
    elements.resultHistory.removeChild(elements.resultHistory.firstChild);
  }

  if (!state.results.length) {
    const empty = document.createElement("span");
    empty.className = "result-history-empty";
    empty.textContent = "生成后的图片会保留在这里";
    elements.resultHistory.appendChild(empty);
  } else {
    state.results.forEach((result) => {
      const selected = result.id === state.selectedResultId;
      const item = document.createElement("div");
      item.className = "result-history-item";
      item.setAttribute("data-result-id", result.id);
      item.setAttribute("role", "button");
      item.setAttribute("tabindex", "0");
      item.setAttribute("aria-label", `查看第 ${result.sequence} 张生成图`);
      item.title = `${formatResultTime(result.createdAt)} · ${truncatePromptLabel(result.prompt, 46)}`;
      if (selected) item.classList.add("is-active");
      if (result.insertedAt || result.openedAt) item.classList.add("is-inserted");

      const image = document.createElement("img");
      image.alt = `生成历史 ${result.sequence}`;
      setImageSource(image, result);

      const number = document.createElement("span");
      number.className = "history-number";
      number.textContent = String(result.sequence);

      const remove = document.createElement("span");
      remove.className = "history-remove";
      remove.textContent = "×";
      remove.setAttribute("data-result-delete", result.id);
      remove.setAttribute("role", "button");
      remove.setAttribute("tabindex", "0");
      remove.setAttribute("aria-label", `删除第 ${result.sequence} 张生成图`);

      const selectedMarker = document.createElement("span");
      selectedMarker.className = "history-selected";
      selectedMarker.textContent = "已选";

      item.appendChild(image);
      item.appendChild(number);
      item.appendChild(remove);
      if (result.taskArchive && Array.isArray(result.taskArchive.references)) {
        const restore = document.createElement("button");
        restore.type = "button";
        restore.className = "history-restore";
        restore.setAttribute("data-result-restore", result.id);
        restore.setAttribute(
          "aria-label",
          `复用任务 ${result.taskArchive.sequence || result.sequence} 的参考图、提示词和尺寸`
        );
        const restoreLabel = document.createElement("span");
        restoreLabel.className = "history-restore-label";
        restoreLabel.textContent = "复用任务";
        restore.appendChild(restoreLabel);
        item.appendChild(restore);
      }
      if (selected) item.appendChild(selectedMarker);
      elements.resultHistory.appendChild(item);
    });
  }

  elements.resultHistoryCount.textContent = `${state.results.length} / ${MAX_RESULTS}`;
  syncResultHistoryTileLayout();
  renderSelectedResult();
}

function selectResult(resultId) {
  const result = state.results.find((item) => item.id === resultId);
  if (!result) return;
  state.selectedResultId = resultId;
  state.selectionRevision += 1;
  renderResultHistory();
  const actionText = hasPhotoshopDocument(result.snapshot) ? "插入图层" : "在 PS 中打开";
  setStatus(
    state.running ? "working" : "idle",
    `已选择生成图 ${result.sequence}`,
    state.running ? `其他图片仍在并发生成；当前结果可以先${actionText}` : `可预览或点击“${actionText}”`
  );
}

async function fillHistoryTask(resultId) {
  if (state.preparingJob || state.capturing || state.inserting) {
    setStatus("warning", "当前操作尚未完成", "请稍候再复用历史任务");
    return;
  }
  const result = state.results.find((item) => item.id === resultId);
  const taskArchive = result && result.taskArchive;
  if (!result || !taskArchive || !Array.isArray(taskArchive.references)) {
    setStatus("error", "无法回溯生成任务", "该历史图没有保存可恢复的任务快照");
    return;
  }
  const references = taskArchive.references.slice(0, MAX_REFERENCES);
  if (!references.length || references.some((reference) => !reference || reference.released || !reference.file)) {
    setStatus("error", "任务参考图已不可用", "请保留当前历史图，或重新获取参考图后生成");
    return;
  }

  const desiredReferences = new Set(references);
  const previousReferences = state.references.splice(0);
  for (const reference of previousReferences) {
    if (!desiredReferences.has(reference)) await releaseReference(reference);
  }
  references.forEach((reference) => {
    reference.inReferenceList = true;
  });
  state.references.push(...references);
  state.targetSnapshot = hasPhotoshopTarget(taskArchive.snapshot) ? taskArchive.snapshot : null;

  const archivedModel = String(taskArchive.model || taskArchive.requested && taskArchive.requested.model || API_CONFIG.model);
  const modelOption = elements.modelChannel.querySelector(`option[value="${archivedModel}"]`);
  const modelChanged = Boolean(modelOption && elements.modelChannel.value !== archivedModel);
  if (modelOption) elements.modelChannel.value = archivedModel;

  if (
    taskArchive.aspectRatio &&
    elements.aspectRatio.querySelector(`option[value="${taskArchive.aspectRatio}"]`)
  ) {
    elements.aspectRatio.value = taskArchive.aspectRatio;
  }
  if (["1K", "2K", "4K"].includes(taskArchive.resolution)) {
    elements.resolution.value = taskArchive.resolution;
  }
  if ([1, 2, 3, 4].includes(Number(taskArchive.generationCount))) {
    elements.generationCount.value = String(taskArchive.generationCount);
  }
  if (LOCAL_EDIT_MODES.includes(String(taskArchive.localEditMode || ""))) {
    elements.localEditMode.value = taskArchive.localEditMode;
  }
  if (modelChanged) {
    resetPricingStateForModel();
    loadCachedPricing();
  }
  syncModelCapabilities();

  const prompt = String(taskArchive.prompt || result.prompt || "").slice(0, 20000);
  setPromptValue(prompt);
  setPromptSelection(prompt.length, prompt.length, false);
  state.selectedResultId = result.id;
  state.selectionRevision += 1;

  syncIslandSelects();
  renderReferences();
  renderResultHistory();
  elements.precisionPlacement.checked = Boolean(taskArchive.precisionPlacement);
  updatePromptCount();
  updateResolvedSize();
  saveSettings();
  setStatus(
    state.running ? "working" : "success",
    `已复用任务 ${taskArchive.sequence}`,
    `已恢复 ${references.length} 张参考图、原提示词、${getSelectedModelConfig().shortLabel}、${taskArchive.resolution} 和 ${taskArchive.generationCount} 张生成数量`
  );
  if (modelChanged) refreshLivePricing("history-task").catch(() => {});
}

function insertReferenceMention(referenceId) {
  if (isPromptDisabled()) return;
  const index = state.references.findIndex((reference) => reference.id === referenceId);
  if (index < 0) return;
  const mention = `@图片${formatReferenceOrdinal(index + 1)}`;
  const value = getPromptValue();
  const selection = getPromptSelection();
  const start = Number.isInteger(selection.start) ? selection.start : value.length;
  const end = Number.isInteger(selection.end) ? selection.end : start;
  const leadingSpace = start > 0 && !/\s/.test(value.charAt(start - 1)) ? " " : "";
  const trailingSpace = end >= value.length || !/\s/.test(value.charAt(end)) ? " " : "";
  const insertion = `${leadingSpace}${mention}${trailingSpace}`;
  setPromptValue(`${value.slice(0, start)}${insertion}${value.slice(end)}`);
  const caret = start + insertion.length;
  setPromptSelection(caret, caret, false);
  updatePromptCount();
  setStatus(
    state.running ? "working" : "idle",
    `已加入 ${mention}`,
    state.running
      ? "当前并发任务继续运行；此编号用于下一次提交"
      : "提示词中的图片编号与当前参考图上传顺序一致"
  );
}

async function removeResult(resultId) {
  if (state.running || state.capturing || state.inserting) return;
  const index = state.results.findIndex((result) => result.id === resultId);
  if (index < 0) return;
  const removed = state.results.splice(index, 1)[0];
  const removedSelected = state.selectedResultId === removed.id;
  await releaseResult(removed);
  if (removedSelected) {
    state.selectedResultId = state.results.length ? state.results[0].id : null;
  }
  await queuePersistHistoryState();
  renderResultHistory();
  setStatus("idle", "已删除历史图", state.results.length ? `还保留 ${state.results.length} 张` : "生成历史已清空");
}

function chooseReplacementTarget() {
  const replacement = state.references.find((reference) => reference.mode === "selection") || null;
  state.targetSnapshot = replacement ? replacement.snapshot : null;
}

function swapReferences(firstId, secondId) {
  if (state.preparingJob || state.capturing || state.inserting || firstId === secondId) return;
  const firstIndex = state.references.findIndex((reference) => reference.id === firstId);
  const secondIndex = state.references.findIndex((reference) => reference.id === secondId);
  if (firstIndex < 0 || secondIndex < 0) return;
  const temporary = state.references[firstIndex];
  state.references[firstIndex] = state.references[secondIndex];
  state.references[secondIndex] = temporary;
  renderReferences();
  setStatus("idle", "参考图顺序已交换", `图 ${firstIndex + 1} 与图 ${secondIndex + 1} 已交换`);
}

async function removeReference(referenceId) {
  if (state.preparingJob || state.capturing || state.inserting) return;
  const index = state.references.findIndex((reference) => reference.id === referenceId);
  if (index < 0) return;
  const removed = state.references.splice(index, 1)[0];
  const removedTarget = state.targetSnapshot && state.targetSnapshot.sourceReferenceId === removed.id;
  await releaseReference(removed);
  if (removedTarget) chooseReplacementTarget();
  renderReferences();
  setStatus(
    "idle",
    "已移除参考图",
    state.references.length ? `当前还有 ${state.references.length} 张参考图` : "可重新获取选区或导入图片"
  );
}

async function clearAllReferences() {
  if (state.preparingJob || state.capturing || state.inserting) return;
  const previous = state.references.splice(0);
  state.targetSnapshot = null;
  for (const reference of previous) await releaseReference(reference);
  renderReferences();
  setStatus("idle", "已清空参考图", "生成结果仍保留；可重新获取选区或导入图片继续生成");
}

function normalizeImagingBounds(bounds, width, height) {
  const left = Number(bounds && bounds.left) || 0;
  const top = Number(bounds && bounds.top) || 0;
  const right = bounds && Number.isFinite(Number(bounds.right)) ? Number(bounds.right) : left + width;
  const bottom = bounds && Number.isFinite(Number(bounds.bottom)) ? Number(bounds.bottom) : top + height;
  return { left, top, right, bottom };
}

function isUnsupportedDocumentMode(mode) {
  return [
    constants.DocumentMode.BITMAP,
    constants.DocumentMode.INDEXEDCOLOR,
    constants.DocumentMode.MULTICHANNEL,
    constants.DocumentMode.DUOTONE
  ].includes(mode);
}

async function savePixelCapture(document, layerId, bounds, inputFile) {
  const options = {
    documentID: document.id,
    componentSize: 8,
    // JPEG has no alpha channel. Photoshop mats transparent pixels on white
    // without creating or activating a temporary document.
    applyAlpha: true,
    colorSpace: "RGB",
    colorProfile: "sRGB IEC61966-2.1",
    sourceBounds: {
      left: bounds.left,
      top: bounds.top,
      right: bounds.right,
      bottom: bounds.bottom
    }
  };
  if (layerId !== null && layerId !== undefined) options.layerID = Number(layerId);

  const captured = await imaging.getPixels(options);
  if (!captured || !captured.imageData) {
    throw new Error(layerId === null || layerId === undefined
      ? "当前区域没有可读取的像素"
      : "当前图层没有可读取的像素，请选择包含画面的图层");
  }

  try {
    const width = Math.round(Number(captured.imageData.width));
    const height = Math.round(Number(captured.imageData.height));
    if (!(width > 0) || !(height > 0)) {
      throw new Error(layerId === null || layerId === undefined
        ? "当前区域没有可读取的像素"
        : "当前图层没有可读取的像素，请选择包含画面的图层");
    }

    const encoded = await imaging.encodeImageData({
      imageData: captured.imageData,
      base64: false
    });
    const jpegBytes = encoded instanceof Uint8Array ? encoded : new Uint8Array(encoded || []);
    if (!jpegBytes.byteLength) throw new Error("Photoshop 未能编码参考图");
    await inputFile.write(exactArrayBuffer(jpegBytes), { format: formats.binary });

    return normalizeImagingBounds(captured.sourceBounds, width, height);
  } finally {
    captured.imageData.dispose();
  }
}

function colorToHex(color) {
  if (!color) return "";
  const normalized = normalizeRgbColor(color);
  return `#${[normalized.r, normalized.g, normalized.b]
    .map((channel) => channel.toString(16).padStart(2, "0"))
    .join("")}`.toUpperCase();
}

function readPhotoshopForegroundColor() {
  const solidColor = app.foregroundColor;
  const rgb = solidColor && solidColor.rgb;
  if (!rgb) throw new Error("无法读取 Photoshop 前景色");
  return normalizeRgbColor({ r: rgb.red, g: rgb.green, b: rgb.blue });
}

function renderColorReplacementControls() {
  const replacement = state.colorReplacement;
  const entries = [
    {
      slot: "source",
      button: elements.sampleSourceColor,
      swatch: elements.sourceColorSwatch,
      label: elements.sourceColorLabel,
      emptyLabel: "吸取原色",
      prefix: "原"
    },
    {
      slot: "target",
      button: elements.sampleTargetColor,
      swatch: elements.targetColorSwatch,
      label: elements.targetColorLabel,
      emptyLabel: "吸取目标色",
      prefix: "目标"
    }
  ];
  entries.forEach((entry) => {
    const color = replacement[entry.slot];
    const sampling = replacement.samplingSlot === entry.slot;
    entry.button.classList.toggle("is-sampling", sampling);
    entry.button.setAttribute("aria-pressed", sampling ? "true" : "false");
    entry.swatch.classList.toggle("has-color", Boolean(color));
    entry.swatch.style.backgroundColor = color ? colorToHex(color) : "";
    entry.label.textContent = sampling
      ? "用 PS 吸管点颜色"
      : (color ? `${entry.prefix} ${colorToHex(color)}` : entry.emptyLabel);
  });
  updateControls();
}

function stopColorSampling() {
  if (colorSamplingTimer !== null) {
    clearInterval(colorSamplingTimer);
    colorSamplingTimer = null;
  }
  state.colorReplacement.samplingSlot = null;
  colorSamplingInitialHex = "";
  colorSamplingStartedAt = 0;
  renderColorReplacementControls();
}

function commitSampledColor(slot, color) {
  const normalized = normalizeRgbColor(color);
  state.colorReplacement[slot] = normalized;
  if (slot === "source") {
    state.colorReplacement.sourceDocumentId = app.documents.length ? app.activeDocument.id : null;
  }
  stopColorSampling();
  setStatus(
    "success",
    slot === "source" ? "已吸取衣服原色" : "已吸取目标颜色",
    `${colorToHex(normalized)}${slot === "source" ? "；再吸取想换成的颜色" : "；框选衣服后点击“PS 换色”"}`
  );
}

function pollColorSampling() {
  const slot = state.colorReplacement.samplingSlot;
  if (!slot) return;
  if (Date.now() - colorSamplingStartedAt >= COLOR_SAMPLE_TIMEOUT_MS) {
    stopColorSampling();
    setStatus("warning", "取色等待已结束", "可重新点击取色按钮；也可以先用 PS 吸管选好前景色，再点两次按钮确认");
    return;
  }
  try {
    const color = readPhotoshopForegroundColor();
    if (colorToHex(color) !== colorSamplingInitialHex) commitSampledColor(slot, color);
  } catch (_) {
    // Photoshop may briefly withhold the foreground color while another modal tool is active.
  }
}

async function startColorSampling(slot) {
  if (state.colorReplacing || state.preparingJob || state.capturing || state.inserting) return;
  if (!app.documents.length) {
    setStatus("warning", "请先打开图片", "需要从 Photoshop 画面中吸取颜色");
    return;
  }
  if (state.colorReplacement.samplingSlot === slot) {
    try {
      commitSampledColor(slot, readPhotoshopForegroundColor());
    } catch (error) {
      setStatus("error", "无法读取颜色", error.message || error);
    }
    return;
  }

  if (colorSamplingTimer !== null) clearInterval(colorSamplingTimer);
  try {
    colorSamplingInitialHex = colorToHex(readPhotoshopForegroundColor());
  } catch (error) {
    setStatus("error", "无法读取颜色", error.message || error);
    return;
  }
  state.colorReplacement.samplingSlot = slot;
  colorSamplingStartedAt = Date.now();
  colorSamplingTimer = setInterval(pollColorSampling, COLOR_SAMPLE_POLL_MS);
  renderColorReplacementControls();
  let toolReady = false;
  try {
    await core.executeAsModal(async () => {
      await batchPlayChecked([{
        _obj: "select",
        _target: [{ _ref: "eyedropperTool" }],
        _options: { dialogOptions: "dontDisplay" }
      }]);
    }, { commandName: "切换到吸管工具" });
    toolReady = true;
  } catch (_) {
    // Older Photoshop builds can reject tool changes from a panel; the I key remains available.
  }
  setStatus(
    "working",
    slot === "source" ? "正在等待衣服原色" : "正在等待目标颜色",
    toolReady
      ? "已切换到 Photoshop 吸管工具，请在画面上点一下颜色；如果前景色已经选好，再点一次当前按钮即可确认"
      : "切回 Photoshop，按 I 使用吸管点一下颜色；如果前景色已经选好，再点一次当前按钮即可确认"
  );
}

function clearColorReplacement() {
  if (state.colorReplacing) return;
  if (colorSamplingTimer !== null) clearInterval(colorSamplingTimer);
  colorSamplingTimer = null;
  state.colorReplacement = {
    source: null,
    target: null,
    sourceDocumentId: null,
    samplingSlot: null
  };
  colorSamplingInitialHex = "";
  colorSamplingStartedAt = 0;
  renderColorReplacementControls();
  setStatus("idle", "换色颜色已清除", "重新吸取衣服原色和目标颜色即可");
}

async function applyLocalColorReplacement() {
  if (state.colorReplacing || state.preparingJob || state.capturing || state.inserting) return;
  const sourceColor = state.colorReplacement.source;
  const targetColor = state.colorReplacement.target;
  if (!sourceColor || !targetColor) {
    setStatus("warning", "还没有选好颜色", "请先吸取衣服原色和目标颜色");
    return;
  }
  if (colorToHex(sourceColor) === colorToHex(targetColor)) {
    setStatus("warning", "两个颜色相同", "请重新吸取一个不同的目标颜色");
    return;
  }

  stopColorSampling();
  const sourceDocument = findOpenDocument(state.colorReplacement.sourceDocumentId);
  if (!sourceDocument) {
    setStatus("warning", "原图片已经关闭", "请重新打开图片并吸取衣服原色");
    return;
  }

  state.colorReplacing = true;
  updateControls();
  setStatus("working", "正在 Photoshop 内换色", "只处理衣服选区，并在原图上方建立新图层");
  try {
    const summary = await core.executeAsModal(async (executionContext) => {
      let captured = null;
      let selectionObject = null;
      let outputImageData = null;
      let suspension = null;
      try {
        await selectDocument(sourceDocument.id);
        let rawBounds = null;
        try {
          rawBounds = sourceDocument.selection && sourceDocument.selection.bounds;
        } catch (_) {
          rawBounds = null;
        }
        if (!rawBounds) throw new Error("请先在 Photoshop 中框选需要换色的衣服区域");
        const bounds = clampBounds(rawBounds, sourceDocument.width, sourceDocument.height);
        if (!bounds) throw new Error("当前选区没有可处理的有效像素");
        const pixelCount = bounds.width * bounds.height;
        if (pixelCount > COLOR_REPLACE_MAX_PIXELS) {
          throw new Error("衣服选区过大，请把选区缩小后再换色");
        }

        executionContext.reportProgress({ value: 0.12, commandName: "正在读取衣服选区" });
        captured = await imaging.getPixels({
          documentID: sourceDocument.id,
          componentSize: 8,
          applyAlpha: true,
          colorSpace: "RGB",
          colorProfile: "sRGB IEC61966-2.1",
          sourceBounds: {
            left: bounds.left,
            top: bounds.top,
            right: bounds.right,
            bottom: bounds.bottom
          }
        });
        selectionObject = await imaging.getSelection({
          documentID: sourceDocument.id,
          sourceBounds: {
            left: bounds.left,
            top: bounds.top,
            right: bounds.right,
            bottom: bounds.bottom
          }
        });
        if (!captured || !captured.imageData || !selectionObject || !selectionObject.imageData) {
          throw new Error("Photoshop 未能读取当前衣服选区");
        }
        const width = Math.round(Number(captured.imageData.width));
        const height = Math.round(Number(captured.imageData.height));
        if (width !== bounds.width || height !== bounds.height ||
          Number(selectionObject.imageData.width) !== width || Number(selectionObject.imageData.height) !== height) {
          throw new Error("选区边界已变化，请重新框选后再试");
        }

        const rawPixels = await captured.imageData.getData({ chunky: true });
        const rawSelection = await selectionObject.imageData.getData({ chunky: true });
        const components = Math.round(Number(captured.imageData.components)) || Math.round(rawPixels.length / pixelCount);
        executionContext.reportProgress({ value: 0.36, commandName: "正在保留纹理和明暗" });
        const recolored = recolorSelectedPixels(
          rawPixels,
          rawSelection,
          width,
          height,
          components,
          sourceColor,
          targetColor,
          COLOR_REPLACE_TOLERANCE
        );
        const minimumMatch = Math.max(4, Math.round(pixelCount * 0.00005));
        if (recolored.matchedPixels < minimumMatch || recolored.strengthTotal < 2) {
          throw new Error("选区内没有找到足够的原色，请在衣服中间位置重新吸取一次原色");
        }

        outputImageData = await imaging.createImageDataFromBuffer(recolored.pixels, {
          width,
          height,
          components: 4,
          chunky: true,
          colorSpace: "RGB",
          colorProfile: "sRGB IEC61966-2.1"
        });
        suspension = await executionContext.hostControl.suspendHistory({
          documentID: sourceDocument.id,
          name: "衣服换色"
        });
        const anchorLayer = sourceDocument.activeLayers && sourceDocument.activeLayers.length
          ? sourceDocument.activeLayers[0]
          : null;
        const layerName = `衣服换色 ${colorToHex(sourceColor)} → ${colorToHex(targetColor)}`;
        const recolorLayer = await sourceDocument.createLayer(constants.LayerKind.NORMAL, { name: layerName });
        if (anchorLayer && Number(anchorLayer.id) !== Number(recolorLayer.id)) {
          try {
            await recolorLayer.move(anchorLayer, constants.ElementPlacement.PLACEBEFORE);
          } catch (_) {
            // Keeping the recolor layer at the document top is a safe fallback.
          }
        }
        await selectDocumentAndLayer(sourceDocument.id, recolorLayer.id);
        executionContext.reportProgress({ value: 0.72, commandName: "正在写入换色图层" });
        await imaging.putPixels({
          documentID: sourceDocument.id,
          layerID: recolorLayer.id,
          imageData: outputImageData,
          replace: true,
          targetBounds: { left: bounds.left, top: bounds.top },
          commandName: "写入衣服换色结果"
        });
        await selectDocumentAndLayer(sourceDocument.id, recolorLayer.id);
        await executionContext.hostControl.resumeHistory(suspension, true);
        suspension = null;
        executionContext.reportProgress({ value: 1, commandName: "衣服换色完成" });
        return {
          matchedPixels: recolored.matchedPixels,
          layerName,
          documentTitle: sourceDocument.title || sourceDocument.name || "当前文档"
        };
      } catch (error) {
        if (suspension) {
          try {
            await executionContext.hostControl.resumeHistory(suspension, false);
          } catch (_) {
            // The modal scope also rolls back an unresumed history suspension.
          }
        }
        throw error;
      } finally {
        if (outputImageData) outputImageData.dispose();
        if (selectionObject && selectionObject.imageData) selectionObject.imageData.dispose();
        if (captured && captured.imageData) captured.imageData.dispose();
      }
    }, { commandName: "衣服换色" });
    setStatus("success", "衣服换色完成", `已在“${summary.documentTitle}”中新建“${summary.layerName}”，原图层没有修改`);
  } catch (error) {
    setStatus("error", "衣服换色失败", error.message || error);
  } finally {
    state.colorReplacing = false;
    updateControls();
  }
}

function renderPaletteMatchControls() {
  const sample = state.paletteSample;
  const previewColor = sample && sample.stats && sample.stats.previewColor;
  elements.paletteSampleSwatch.classList.toggle("has-color", Boolean(previewColor));
  elements.paletteSampleSwatch.style.backgroundColor = previewColor ? colorToHex(previewColor) : "";
  elements.paletteSampleLabel.textContent = previewColor
    ? `参考 ${colorToHex(previewColor)}`
    : "① 获取参考衣服";
  updateControls();
}

function clearPaletteSample() {
  if (state.paletteProcessing) return;
  state.paletteSample = null;
  renderPaletteMatchControls();
  setStatus("idle", "参考衣服颜色已清除", "重新框选参考衣服，再点“获取参考衣服”即可");
}

async function capturePaletteSample() {
  if (state.paletteProcessing || state.preparingJob || state.capturing || state.inserting) return;
  if (!app.documents.length) {
    setStatus("warning", "请先打开图片", "需要先框选颜色作为参考的衣服");
    return;
  }
  const sourceDocument = app.activeDocument;
  state.paletteProcessing = true;
  updateControls();
  setStatus("working", "正在获取参考衣服颜色", "会读取选区里的高光、阴影和整体色调，不调用生成接口");
  try {
    const sample = await core.executeAsModal(async (executionContext) => {
      let captured = null;
      let selectionObject = null;
      try {
        await selectDocument(sourceDocument.id);
        let rawBounds = null;
        try {
          rawBounds = sourceDocument.selection && sourceDocument.selection.bounds;
        } catch (_) {
          rawBounds = null;
        }
        if (!rawBounds) throw new Error("请先在 Photoshop 中框选作为颜色参考的衣服");
        const bounds = clampBounds(rawBounds, sourceDocument.width, sourceDocument.height);
        if (!bounds) throw new Error("参考衣服选区没有有效像素");
        const pixelCount = bounds.width * bounds.height;
        if (pixelCount > PALETTE_MATCH_MAX_PIXELS) {
          throw new Error("参考衣服选区过大，请把选区缩小后再获取");
        }
        executionContext.reportProgress({ value: 0.18, commandName: "正在读取参考衣服" });
        captured = await imaging.getPixels({
          documentID: sourceDocument.id,
          componentSize: 8,
          applyAlpha: true,
          colorSpace: "RGB",
          colorProfile: "sRGB IEC61966-2.1",
          sourceBounds: {
            left: bounds.left,
            top: bounds.top,
            right: bounds.right,
            bottom: bounds.bottom
          }
        });
        selectionObject = await imaging.getSelection({
          documentID: sourceDocument.id,
          sourceBounds: {
            left: bounds.left,
            top: bounds.top,
            right: bounds.right,
            bottom: bounds.bottom
          }
        });
        if (!captured || !captured.imageData || !selectionObject || !selectionObject.imageData) {
          throw new Error("Photoshop 未能读取参考衣服选区");
        }
        const width = Math.round(Number(captured.imageData.width));
        const height = Math.round(Number(captured.imageData.height));
        if (width !== bounds.width || height !== bounds.height ||
          Number(selectionObject.imageData.width) !== width || Number(selectionObject.imageData.height) !== height) {
          throw new Error("参考选区边界已变化，请重新框选后再试");
        }
        const pixels = await captured.imageData.getData({ chunky: true });
        const selection = await selectionObject.imageData.getData({ chunky: true });
        const components = Math.round(Number(captured.imageData.components)) || Math.round(pixels.length / pixelCount);
        executionContext.reportProgress({ value: 0.58, commandName: "正在分析颜色层次" });
        const stats = analyzeColorRegion(pixels, selection, width, height, components, 80000);
        executionContext.reportProgress({ value: 1, commandName: "参考颜色已获取" });
        return {
          stats,
          documentId: sourceDocument.id,
          documentTitle: sourceDocument.title || sourceDocument.name || "当前文档",
          bounds,
          capturedAt: Date.now()
        };
      } finally {
        if (selectionObject && selectionObject.imageData) selectionObject.imageData.dispose();
        if (captured && captured.imageData) captured.imageData.dispose();
      }
    }, { commandName: "获取参考衣服颜色" });
    state.paletteSample = sample;
    renderPaletteMatchControls();
    setStatus(
      "success",
      "参考衣服颜色已获取",
      `${colorToHex(sample.stats.previewColor)}；现在框选需要换色的衣服，再点“匹配当前衣服”`
    );
  } catch (error) {
    setStatus("error", "获取参考衣服失败", error.message || error);
  } finally {
    state.paletteProcessing = false;
    updateControls();
  }
}

async function applyPaletteMatch() {
  if (state.paletteProcessing || state.preparingJob || state.capturing || state.inserting) return;
  const sample = state.paletteSample;
  if (!sample || !sample.stats) {
    setStatus("warning", "还没有参考衣服", "先框选颜色正确的衣服，再点“获取参考衣服”");
    return;
  }
  if (!app.documents.length) {
    setStatus("warning", "请先打开图片", "需要框选要换色的衣服");
    return;
  }
  const targetDocument = app.activeDocument;
  state.paletteProcessing = true;
  updateControls();
  setStatus("working", "正在匹配衣服颜色", "正在把参考衣服的高光、阴影和色调迁移到当前选区");
  try {
    const summary = await core.executeAsModal(async (executionContext) => {
      let captured = null;
      let selectionObject = null;
      let outputImageData = null;
      let suspension = null;
      try {
        await selectDocument(targetDocument.id);
        let rawBounds = null;
        try {
          rawBounds = targetDocument.selection && targetDocument.selection.bounds;
        } catch (_) {
          rawBounds = null;
        }
        if (!rawBounds) throw new Error("请先在 Photoshop 中框选需要换色的衣服");
        const bounds = clampBounds(rawBounds, targetDocument.width, targetDocument.height);
        if (!bounds) throw new Error("目标衣服选区没有有效像素");
        if (Number(sample.documentId) === Number(targetDocument.id) &&
          bounds.left === sample.bounds.left && bounds.top === sample.bounds.top &&
          bounds.right === sample.bounds.right && bounds.bottom === sample.bounds.bottom) {
          throw new Error("当前还是参考衣服选区，请先改选需要换色的另一件衣服");
        }
        const pixelCount = bounds.width * bounds.height;
        if (pixelCount > PALETTE_MATCH_MAX_PIXELS) {
          throw new Error("目标衣服选区过大，请把选区缩小后再匹配");
        }
        executionContext.reportProgress({ value: 0.12, commandName: "正在读取目标衣服" });
        captured = await imaging.getPixels({
          documentID: targetDocument.id,
          componentSize: 8,
          applyAlpha: true,
          colorSpace: "RGB",
          colorProfile: "sRGB IEC61966-2.1",
          sourceBounds: {
            left: bounds.left,
            top: bounds.top,
            right: bounds.right,
            bottom: bounds.bottom
          }
        });
        selectionObject = await imaging.getSelection({
          documentID: targetDocument.id,
          sourceBounds: {
            left: bounds.left,
            top: bounds.top,
            right: bounds.right,
            bottom: bounds.bottom
          }
        });
        if (!captured || !captured.imageData || !selectionObject || !selectionObject.imageData) {
          throw new Error("Photoshop 未能读取目标衣服选区");
        }
        const width = Math.round(Number(captured.imageData.width));
        const height = Math.round(Number(captured.imageData.height));
        if (width !== bounds.width || height !== bounds.height ||
          Number(selectionObject.imageData.width) !== width || Number(selectionObject.imageData.height) !== height) {
          throw new Error("目标选区边界已变化，请重新框选后再试");
        }
        const pixels = await captured.imageData.getData({ chunky: true });
        const selection = await selectionObject.imageData.getData({ chunky: true });
        const components = Math.round(Number(captured.imageData.components)) || Math.round(pixels.length / pixelCount);
        executionContext.reportProgress({ value: 0.34, commandName: "正在匹配高光和阴影" });
        const targetStats = analyzeColorRegion(pixels, selection, width, height, components, 80000);
        const transferred = transferColorRegion(
          pixels,
          selection,
          width,
          height,
          components,
          sample.stats,
          targetStats
        );
        if (transferred.affectedPixels < Math.max(4, Math.round(pixelCount * 0.00005))) {
          throw new Error("目标衣服选区中的有效像素太少");
        }
        outputImageData = await imaging.createImageDataFromBuffer(transferred.pixels, {
          width,
          height,
          components: 4,
          chunky: true,
          colorSpace: "RGB",
          colorProfile: "sRGB IEC61966-2.1"
        });
        suspension = await executionContext.hostControl.suspendHistory({
          documentID: targetDocument.id,
          name: "衣服区域颜色匹配"
        });
        const anchorLayer = targetDocument.activeLayers && targetDocument.activeLayers.length
          ? targetDocument.activeLayers[0]
          : null;
        const layerName = `衣服颜色匹配 ${colorToHex(sample.stats.previewColor)}`;
        const matchedLayer = await targetDocument.createLayer(constants.LayerKind.NORMAL, { name: layerName });
        if (anchorLayer && Number(anchorLayer.id) !== Number(matchedLayer.id)) {
          try {
            await matchedLayer.move(anchorLayer, constants.ElementPlacement.PLACEBEFORE);
          } catch (_) {
            // Keeping the result at the document top is a safe fallback.
          }
        }
        await selectDocumentAndLayer(targetDocument.id, matchedLayer.id);
        executionContext.reportProgress({ value: 0.78, commandName: "正在写入颜色匹配图层" });
        await imaging.putPixels({
          documentID: targetDocument.id,
          layerID: matchedLayer.id,
          imageData: outputImageData,
          replace: true,
          targetBounds: { left: bounds.left, top: bounds.top },
          commandName: "写入衣服颜色匹配结果"
        });
        await selectDocumentAndLayer(targetDocument.id, matchedLayer.id);
        await executionContext.hostControl.resumeHistory(suspension, true);
        suspension = null;
        executionContext.reportProgress({ value: 1, commandName: "衣服颜色匹配完成" });
        return {
          layerName,
          targetTitle: targetDocument.title || targetDocument.name || "当前文档"
        };
      } catch (error) {
        if (suspension) {
          try {
            await executionContext.hostControl.resumeHistory(suspension, false);
          } catch (_) {
            // The modal scope also rolls back an unresumed history suspension.
          }
        }
        throw error;
      } finally {
        if (outputImageData) outputImageData.dispose();
        if (selectionObject && selectionObject.imageData) selectionObject.imageData.dispose();
        if (captured && captured.imageData) captured.imageData.dispose();
      }
    }, { commandName: "衣服区域颜色匹配" });
    setStatus(
      "success",
      "衣服颜色已匹配",
      `已在“${summary.targetTitle}”中新建“${summary.layerName}”，原图层没有修改`
    );
  } catch (error) {
    setStatus("error", "衣服颜色匹配失败", error.message || error);
  } finally {
    state.paletteProcessing = false;
    updateControls();
  }
}

async function captureSource(mode) {
  if (state.preparingJob || state.capturing || state.inserting) return null;
  if (state.references.length + 1 > MAX_REFERENCES) {
    setStatus("warning", "参考图已满", `最多只能添加 ${MAX_REFERENCES} 张参考图`);
    return null;
  }

  state.capturing = true;
  updateControls();
  setStatus("working", `正在获取${formatReferenceType(mode)}`, "正在后台读取像素，不会切换 Photoshop 文档");

  let inputFile = null;
  let snapshot = null;
  let layerName = "";

  try {
    const temporaryFolder = await localFileSystem.getTemporaryFolder();
    const captureId = `${Date.now()}-${state.referenceSequence + 1}`;
    inputFile = await temporaryFolder.createFile(`katu-reference-${captureId}.jpg`, { overwrite: true });

    await core.executeAsModal(async () => {
      if (!app.documents.length) throw new Error("请先在 Photoshop 中打开一张图片");
      const document = app.activeDocument;
      const documentWidth = Math.round(Number(document.width));
      const documentHeight = Math.round(Number(document.height));
      if (document.artboards && document.artboards.length) {
        throw new Error("当前版本暂不支持画板文档，请先在普通画布中使用");
      }
      if (isUnsupportedDocumentMode(document.mode)) {
        throw new Error("当前颜色模式不支持回填，请转换为 RGB、CMYK、灰度或 Lab");
      }

      let rawBounds = null;
      let layerId = null;
      let solid = true;
      const insertionAnchor = document.activeLayers && document.activeLayers.length
        ? document.activeLayers[0]
        : null;
      const insertionAnchorLayerId = insertionAnchor ? insertionAnchor.id : null;
      const insertionAnchorLayerName = insertionAnchor ? (insertionAnchor.name || "") : "";
      let insertionAnchorParentId = null;
      try {
        const parent = insertionAnchor && insertionAnchor.parent;
        if (parent && Number.isFinite(Number(parent.id)) && Number(parent.id) !== Number(document.id)) {
          insertionAnchorParentId = Number(parent.id);
        }
      } catch (_) {
        insertionAnchorParentId = null;
      }
      if (mode === "canvas") {
        rawBounds = { left: 0, top: 0, right: documentWidth, bottom: documentHeight };
      } else if (mode === "layer") {
        if (!document.activeLayers || document.activeLayers.length !== 1) {
          throw new Error("请先在 Photoshop 图层面板中只选择一个图层");
        }
        const activeLayer = document.activeLayers[0];
        if (!activeLayer) throw new Error("没有检测到活动图层，请先在图层面板中选择一个图层");
        rawBounds = activeLayer.boundsNoEffects || activeLayer.bounds;
        layerId = activeLayer.id;
        layerName = activeLayer.name || "未命名图层";
      } else {
        rawBounds = document.selection.bounds;
        if (!rawBounds) throw new Error("没有检测到选区，请先用选框或套索工具创建选区");
        solid = Boolean(document.selection.solid);
      }

      const bounds = clampBounds(rawBounds, documentWidth, documentHeight);
      if (!bounds) throw new Error(mode === "layer" ? "当前图层没有可获取的画布内像素" : "选区没有与画布相交的有效像素区域");
      const localEditMode = selectedLocalEditMode();
      const editBounds = mode === "selection" ? bounds : null;
      const captureBounds = mode === "selection"
        ? expandSelectionContextBounds(bounds, documentWidth, documentHeight, localEditMode)
        : bounds;
      if (captureBounds.width * captureBounds.height > API_CONFIG.maxInputPixels) {
        throw new Error("参考区域过大，请缩小到约 4000 万像素以内再试");
      }

      let mask = null;
      if (mode === "selection") {
        const maskObject = await imaging.getSelection({
          documentID: document.id,
          sourceBounds: {
            left: editBounds.left,
            top: editBounds.top,
            right: editBounds.right,
            bottom: editBounds.bottom
          }
        });
        try {
          const raw = await maskObject.imageData.getData({ chunky: true });
          const owned = new Uint8Array(raw.length);
          owned.set(raw);
          let fullyOpaque = owned.length > 0;
          for (let index = 0; index < owned.length; index += 1) {
            if (owned[index] !== 255) {
              fullyOpaque = false;
              break;
            }
          }
          solid = fullyOpaque;
          mask = {
            bytes: owned,
            width: maskObject.imageData.width,
            height: maskObject.imageData.height,
            bounds: normalizeImagingBounds(maskObject.sourceBounds, maskObject.imageData.width, maskObject.imageData.height)
          };
        } finally {
          maskObject.imageData.dispose();
        }
      }

      let capturedBounds = captureBounds;
      if (mode === "layer") {
        const actualBounds = await savePixelCapture(document, layerId, captureBounds, inputFile);
        capturedBounds = clampBounds(actualBounds, documentWidth, documentHeight) || captureBounds;
      } else {
        await savePixelCapture(document, null, captureBounds, inputFile);
      }
      const referenceId = `ref-${captureId}`;
      snapshot = {
        id: `${document.id}-${captureId}`,
        sourceReferenceId: referenceId,
        mode,
        documentId: document.id,
        documentTitle: document.title || document.name || "未命名文档",
        documentWidth,
        documentHeight,
        documentResolution: Number(document.resolution) || 72,
        documentMode: document.mode,
        bounds: capturedBounds,
        editBounds,
        localEditMode: mode === "selection" ? localEditMode : "",
        solid,
        mask,
        layerId,
        layerName,
        insertionAnchorLayerId,
        insertionAnchorLayerName,
        insertionAnchorParentId,
        capturedAt: new Date()
      };
    }, { commandName: `获取 AI ${formatReferenceType(mode)}参考图` });

    const inputMetadata = await inputFile.getMetadata();
    const inputSize = Number(inputMetadata && inputMetadata.size);
    if (!(inputSize > 0)) throw new Error("获取到的参考图为空");
    if (inputSize > API_CONFIG.maxUploadBytes) {
      throw new Error("参考图导出后超过 64 MB，请缩小区域或简化画面后再试");
    }

    state.referenceSequence += 1;
    const reference = {
      id: snapshot.sourceReferenceId,
      mode,
      file: inputFile,
      mime: "image/jpeg",
      previewUrl: null,
      bounds: snapshot.bounds,
      snapshot,
      layerName,
      capturedAt: snapshot.capturedAt,
      inReferenceList: true,
      resultOwners: 0,
      released: false
    };
    await createReferencePreview(reference);

    state.references.push(reference);
    const assignedAsTarget = mode === "selection" && !state.targetSnapshot;
    if (assignedAsTarget) {
      state.targetSnapshot = snapshot;
      elements.precisionPlacement.checked = true;
    }
    renderReferences();

    const primaryReference = getPrimaryReference();
    const isPrimaryGenerationReference = !state.targetSnapshot && primaryReference && primaryReference.id === reference.id;
    const targetNote = mode === "selection"
      ? (assignedAsTarget
        ? `已设为回填目标；${localEditModeLabel(snapshot.localEditMode)}会带入周边衔接，插入时选区外保持原图`
        : "已追加为辅助选区；精确回填仍使用第一个选区")
      : (isPrimaryGenerationReference
        ? "已作为图一主参考图，可直接生成；未获取选区时不启用精确回填"
        : "已追加为辅助参考图；不会覆盖当前主图依据");
    const actionText = `已添加${formatReferenceLabel(reference, state.references.length - 1)}参考图`;
    setStatus("success", actionText, targetNote);
    if (state.running) renderGenerationQueue();
    return reference;
  } catch (error) {
    await safeDelete(inputFile);
    setStatus("error", `无法获取${formatReferenceType(mode)}`, error.message || error);
    if (state.running) renderGenerationQueue();
    throw error;
  } finally {
    state.capturing = false;
    updateControls();
  }
}

async function importReferenceImages() {
  if (state.preparingJob || state.capturing || state.inserting) return [];
  const availableSlots = MAX_REFERENCES - state.references.length;
  if (availableSlots <= 0) {
    setStatus("warning", "参考图已满", `最多只能添加 ${MAX_REFERENCES} 张参考图`);
    return [];
  }

  state.capturing = true;
  updateControls();
  setStatus("working", "请选择参考图片", "支持一次多选 PNG、JPEG 和 WebP 图片");

  try {
    const selected = await localFileSystem.getFileForOpening({
      allowMultiple: true,
      types: ["png", "jpg", "jpeg", "webp"]
    });
    const selectedFiles = Array.isArray(selected) ? selected : (selected ? [selected] : []);
    if (!selectedFiles.length) {
      setStatus("idle", "已取消导入", "没有添加新的参考图片");
      return [];
    }

    const filesToImport = selectedFiles.slice(0, availableSlots);
    const limitedCount = Math.max(0, selectedFiles.length - filesToImport.length);
    const temporaryFolder = await localFileSystem.getTemporaryFolder();
    const batchId = Date.now();
    const imported = [];
    const failures = [];

    for (let index = 0; index < filesToImport.length; index += 1) {
      const sourceFile = filesToImport[index];
      const originalName = String(sourceFile && sourceFile.name || `图片 ${index + 1}`);
      let copiedFile = null;
      try {
        let declaredSize = 0;
        try {
          const metadata = await sourceFile.getMetadata();
          declaredSize = Number(metadata && metadata.size) || 0;
        } catch (_) {
          declaredSize = 0;
        }
        if (declaredSize > API_CONFIG.maxUploadBytes) {
          throw new Error("文件超过 64 MB");
        }

        const sourceBytes = await sourceFile.read({ format: formats.binary });
        const sourceBuffer = exactArrayBuffer(sourceBytes);
        if (!sourceBuffer.byteLength) throw new Error("图片文件为空");
        if (sourceBuffer.byteLength > API_CONFIG.maxUploadBytes) {
          throw new Error("文件超过 64 MB");
        }
        const detected = detectImageType(sourceBuffer);
        if (detected.width * detected.height > API_CONFIG.maxInputPixels) {
          throw new Error("图片超过约 4000 万像素");
        }

        const referenceId = `ref-import-${batchId}-${index + 1}-${state.referenceSequence + 1}`;
        copiedFile = await temporaryFolder.createFile(
          `katu-import-${batchId}-${index + 1}.${detected.extension}`,
          { overwrite: true }
        );
        await copiedFile.write(sourceBuffer, { format: formats.binary });

        const capturedAt = new Date();
        const bounds = {
          left: 0,
          top: 0,
          right: detected.width,
          bottom: detected.height,
          width: detected.width,
          height: detected.height
        };
        const snapshot = {
          id: `import-${referenceId}`,
          sourceReferenceId: referenceId,
          mode: "import",
          documentId: null,
          documentTitle: originalName,
          documentWidth: detected.width,
          documentHeight: detected.height,
          documentResolution: 72,
          documentMode: null,
          bounds,
          solid: true,
          mask: null,
          layerId: null,
          layerName: originalName,
          insertionAnchorLayerId: null,
          insertionAnchorLayerName: "",
          insertionAnchorParentId: null,
          capturedAt
        };
        const reference = {
          id: referenceId,
          mode: "import",
          file: copiedFile,
          mime: detected.mime,
          previewUrl: null,
          bounds,
          snapshot,
          layerName: originalName,
          originalName,
          capturedAt,
          inReferenceList: true,
          resultOwners: 0,
          released: false
        };
        await createReferencePreview(reference);
        state.referenceSequence += 1;
        state.references.push(reference);
        imported.push(reference);
        copiedFile = null;
      } catch (error) {
        await safeDelete(copiedFile);
        failures.push(`${originalName}：${sanitizeMessage(error.message || error)}`);
      }
    }

    renderReferences();
    if (!imported.length) {
      setStatus("error", "未能导入图片", failures[0] || "请选择有效的 PNG、JPEG 或 WebP 图片");
      return [];
    }

    const notes = [];
    if (limitedCount) notes.push(`参考图上限为 ${MAX_REFERENCES} 张，另有 ${limitedCount} 张未导入`);
    if (failures.length) notes.push(`${failures.length} 张无效或读取失败`);
    notes.push(
      state.targetSnapshot
        ? "已加入参考图队列，仍按当前选区精确回填"
        : "面板中的图一会作为主参考图，可直接运行；生成后可在 Photoshop 中打开"
    );
    setStatus(
      failures.length || limitedCount ? "warning" : "success",
      `已导入 ${imported.length} 张参考图片`,
      notes.join("；")
    );
    return imported;
  } finally {
    state.capturing = false;
    updateControls();
  }
}

function responseContentLength(response) {
  const raw = response.headers.get("content-length");
  if (raw === null || raw === "") return null;
  const value = Number(raw);
  return Number.isFinite(value) && value >= 0 ? value : null;
}

function responseChunk(value) {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
  throw new Error("接口返回了无法读取的数据块");
}

async function readBoundedResponse(response, maxBytes, label) {
  const declaredLength = responseContentLength(response);
  if (declaredLength !== null && declaredLength > maxBytes) {
    throw new Error(`${label}超过插件的安全上限`);
  }

  if (response.body && typeof response.body.getReader === "function") {
    const reader = response.body.getReader();
    const chunks = [];
    let total = 0;
    try {
      while (true) {
        const part = await reader.read();
        if (part.done) break;
        const chunk = responseChunk(part.value);
        total += chunk.byteLength;
        if (total > maxBytes) {
          try {
            await reader.cancel("response too large");
          } catch (_) {
            // The body may already have closed while the limit was enforced.
          }
          throw new Error(`${label}超过插件的安全上限`);
        }
        chunks.push(chunk);
      }
    } finally {
      if (typeof reader.releaseLock === "function") reader.releaseLock();
    }

    const output = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) {
      output.set(chunk, offset);
      offset += chunk.byteLength;
    }
    return output.buffer;
  }

  const buffer = exactArrayBuffer(await response.arrayBuffer());
  if (buffer.byteLength > maxBytes) throw new Error(`${label}超过插件的安全上限`);
  return buffer;
}

function httpErrorMessage(status, payload, retryAfter) {
  const fallbackMap = {
    400: "请求参数不正确",
    401: "API Key 无效或已失效",
    403: "当前 API Key 没有调用权限",
    413: "参考图过大，服务端拒绝接收",
    429: retryAfter ? `请求过于频繁，请在 ${retryAfter} 后重试` : "请求过于频繁，请稍后重试",
    502: "生成服务网关错误（HTTP 502）",
    503: "生成服务暂时不可用（HTTP 503）",
    504: "接口网关超时（HTTP 504）"
  };
  const fallback = fallbackMap[status] || (status >= 500 ? "生成服务暂时不可用" : `接口请求失败（HTTP ${status}）`);
  return extractErrorMessage(payload, fallback);
}

function createHttpResponseError(status, payload, retryAfter) {
  const error = new Error(httpErrorMessage(status, payload, retryAfter));
  error.httpStatus = Number(status) || 0;
  error.responseReceived = true;
  error.billingUncertain = error.httpStatus >= 500;
  return error;
}

async function readImageResponse(response) {
  const buffer = await readBoundedResponse(response, API_CONFIG.maxImageBytes, "返回图片");
  if (!buffer.byteLength) throw new Error("接口返回了空图片");
  const type = detectImageType(buffer);
  if (type.width * type.height > API_CONFIG.maxOutputPixels) {
    throw new Error("返回图片像素过大，已拒绝交给 Photoshop 解码");
  }
  return { buffer, type, count: 1 };
}

async function requestImageEdit({ apiKey, model, prompt, size, imageFiles, signal }) {
  const form = new FormData();
  form.append("model", model || API_CONFIG.model);
  form.append("prompt", prompt);
  form.append("size", size);
  form.append("response_format", API_CONFIG.responseFormat);
  if (!Array.isArray(imageFiles) || !imageFiles.length) throw new Error("没有可上传的参考图");
  imageFiles.forEach((imageFile, index) => {
    form.append("image", imageFile, imageFile.name || `reference-${index + 1}.png`);
  });

  const response = await fetch(API_CONFIG.endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`
    },
    credentials: "omit",
    redirect: "error",
    body: form,
    signal
  });

  try {
    const contentType = String(response.headers.get("content-type") || "").toLowerCase();
    if (response.ok && contentType.startsWith("image/")) return await readImageResponse(response);

    let rawBuffer = null;
    try {
      rawBuffer = await readBoundedResponse(response, API_CONFIG.maxJsonBytes, "接口响应");
    } catch (error) {
      if (!response.ok) {
        throw createHttpResponseError(response.status, null, response.headers.get("retry-after"));
      }
      throw error;
    }
    let raw = utf8BytesToString(new Uint8Array(rawBuffer));
    rawBuffer = null;
    let payload = null;
    try {
      payload = raw ? JSON.parse(raw) : null;
    } catch (_) {
      if (!response.ok) {
        throw createHttpResponseError(response.status, null, response.headers.get("retry-after"));
      }
      throw new Error("接口返回了无法解析的内容");
    }
    raw = null;

    if (!response.ok) {
      throw createHttpResponseError(response.status, payload, response.headers.get("retry-after"));
    }

    const candidate = extractImageCandidate(payload);
    if (!candidate) throw new Error(extractErrorMessage(payload, "响应中没有找到生成图片"));
    payload = null;

    if (candidate.kind === "url") {
      throw new Error("接口返回了图片 URL；为保护 API Key，插件只接受 b64_json 或直接图片响应");
    }

    const buffer = base64ToArrayBuffer(candidate.value, API_CONFIG.maxImageBytes);
    const type = detectImageType(buffer);
    if (type.width * type.height > API_CONFIG.maxOutputPixels) {
      throw new Error("返回图片像素过大，已拒绝交给 Photoshop 解码");
    }
    return { buffer, type, count: candidate.count };
  } catch (error) {
    if (error && typeof error === "object") {
      error.responseReceived = true;
      if (!error.httpStatus && !response.ok) error.httpStatus = response.status;
      if (response.status >= 500) error.billingUncertain = true;
    }
    throw error;
  }
}

function normalizeHistoryMatchText(value) {
  return String(value || "").trim().replace(/\s+/g, " ");
}

function historyModelMatches(expected, actual) {
  const actualToken = normalizeModelIdentifier(actual);
  if (!actualToken) return true;
  const config = getModelConfig(expected);
  return [config.apiModel, config.pricingModel].concat(config.aliases || [])
    .some((alias) => normalizeModelIdentifier(alias) === actualToken);
}

function imageBufferFingerprint(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer || 0);
  let hash = 2166136261;
  const stride = Math.max(1, Math.floor(bytes.length / 8192));
  for (let index = 0; index < bytes.length; index += stride) {
    hash ^= bytes[index];
    hash = Math.imul(hash, 16777619) >>> 0;
  }
  if (bytes.length) {
    hash ^= bytes[bytes.length - 1];
    hash = Math.imul(hash, 16777619) >>> 0;
  }
  return `${bytes.length}:${hash.toString(16).padStart(8, "0")}`;
}

async function fetchGenerationHistory(apiKey, parentSignal) {
  const controller = new AbortController();
  const abortHistory = () => controller.abort();
  let timeoutHandle = null;
  if (parentSignal && parentSignal.aborted) abortHistory();
  else if (parentSignal && typeof parentSignal.addEventListener === "function") {
    parentSignal.addEventListener("abort", abortHistory);
  }
  timeoutHandle = setTimeout(abortHistory, HISTORY_REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(`${API_CONFIG.historyEndpoint}?page=1&page_size=50`, {
      method: "GET",
      headers: { Authorization: `Bearer ${apiKey}` },
      credentials: "omit",
      redirect: "error",
      signal: controller.signal
    });
    const rawBuffer = await readBoundedResponse(response, API_CONFIG.maxJsonBytes, "历史接口响应");
    const raw = utf8BytesToString(new Uint8Array(rawBuffer));
    let payload = null;
    try {
      payload = raw ? JSON.parse(raw) : null;
    } catch (_) {
      if (!response.ok) {
        throw createHttpResponseError(response.status, null, response.headers.get("retry-after"));
      }
      throw new Error("历史接口返回了无法解析的内容");
    }
    if (!response.ok) {
      throw createHttpResponseError(response.status, payload, response.headers.get("retry-after"));
    }
    return payload;
  } finally {
    if (timeoutHandle) clearTimeout(timeoutHandle);
    if (parentSignal && typeof parentSignal.removeEventListener === "function") {
      parentSignal.removeEventListener("abort", abortHistory);
    }
  }
}

function historyRecordMatchScore(record, job) {
  const key = historyRecordKey(record);
  if (key && job.historyBaselineKeys && job.historyBaselineKeys.has(key)) return -Infinity;
  const metadata = historyRecordMetadata(record);
  const candidate = extractHistoryImageCandidate(record);
  if (!candidate) return -Infinity;

  const status = normalizeHistoryMatchText(metadata.status).toLowerCase();
  if (/fail|error|cancel|失败|取消/.test(status)) return -Infinity;

  const expectedPrompt = normalizeHistoryMatchText(job.requestPrompt || job.prompt);
  const actualPrompt = normalizeHistoryMatchText(metadata.prompt);
  if (actualPrompt && expectedPrompt && actualPrompt !== expectedPrompt) return -Infinity;

  const expectedModel = normalizeHistoryMatchText(
    job.model || job.requested && job.requested.model || API_CONFIG.model
  ).toLowerCase();
  const actualModel = normalizeHistoryMatchText(metadata.model).toLowerCase();
  const matchingModel = historyModelMatches(expectedModel, actualModel);
  if (actualModel && !matchingModel) return -Infinity;

  const actualSize = normalizeHistoryMatchText(metadata.size).toUpperCase();
  const expectedSizes = new Set([
    normalizeHistoryMatchText(job.requested && job.requested.size).toUpperCase(),
    normalizeHistoryMatchText(job.resolution).toUpperCase()
  ].filter(Boolean));
  if (actualSize && expectedSizes.size && !expectedSizes.has(actualSize)) return -Infinity;

  const createdAt = Number(metadata.createdAt) || 0;
  const jobCreatedAt = job.createdAt instanceof Date ? job.createdAt.getTime() : Number(job.createdAt) || 0;
  if (createdAt && jobCreatedAt && createdAt < jobCreatedAt - 120000) return -Infinity;
  if (createdAt && jobCreatedAt && createdAt > jobCreatedAt + HISTORY_RECORD_MATCH_MAX_LAG_MS) return -Infinity;

  if (!actualPrompt) {
    const hasSafeFallback = Boolean(key && createdAt && (actualModel || actualSize));
    if (!hasSafeFallback) return -Infinity;
  }

  let score = 0;
  if (actualPrompt && actualPrompt === expectedPrompt) score += 100;
  if (actualModel && matchingModel) score += 20;
  if (actualSize && expectedSizes.has(actualSize)) score += 20;
  if (createdAt && jobCreatedAt) {
    score += Math.max(0, 20 - Math.abs(createdAt - jobCreatedAt) / 30000);
  }
  if (key) score += 5;
  return score;
}

function matchingHistoryRecords(payload, job) {
  return extractHistoryRecords(payload)
    .map((record) => ({
      record,
      key: historyRecordKey(record),
      score: historyRecordMatchScore(record, job),
      createdAt: Number(historyRecordMetadata(record).createdAt) || 0
    }))
    .filter((item) => Number.isFinite(item.score))
    .sort((left, right) => right.score - left.score || right.createdAt - left.createdAt);
}

function historyImageUrl(value) {
  const text = String(value || "").trim();
  if (text.startsWith("/")) return `https://www.katuai.cn${text}`;
  if (/^https:\/\/www\.katuai\.cn(?:\/|$)/i.test(text)) return text;
  throw new Error("历史记录返回了不受信任的图片地址");
}

async function historyCandidateToImage(candidate, apiKey, signal, depth = 0) {
  if (depth > 2) throw new Error("历史图片地址跳转次数过多");
  if (!candidate || !candidate.value) throw new Error("历史记录中没有生成图片");
  if (candidate.kind === "base64") {
    const buffer = base64ToArrayBuffer(candidate.value, API_CONFIG.maxImageBytes);
    const type = detectImageType(buffer);
    if (type.width * type.height > API_CONFIG.maxOutputPixels) {
      throw new Error("历史图片像素过大，已拒绝交给 Photoshop 解码");
    }
    return { buffer, type, count: Number(candidate.count) || 1 };
  }
  if (candidate.kind !== "url") throw new Error("历史记录中的图片格式无法识别");

  const controller = new AbortController();
  const abortDownload = () => controller.abort();
  let timeoutHandle = null;
  if (signal && signal.aborted) abortDownload();
  else if (signal && typeof signal.addEventListener === "function") {
    signal.addEventListener("abort", abortDownload);
  }
  timeoutHandle = setTimeout(abortDownload, HISTORY_REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(historyImageUrl(candidate.value), {
      method: "GET",
      headers: { Authorization: `Bearer ${apiKey}` },
      credentials: "omit",
      redirect: "error",
      signal: controller.signal
    });
    if (!response.ok) {
      throw createHttpResponseError(response.status, null, response.headers.get("retry-after"));
    }
    const contentType = String(response.headers.get("content-type") || "").toLowerCase();
    if (contentType.includes("json")) {
      const rawBuffer = await readBoundedResponse(response, API_CONFIG.maxJsonBytes, "历史图片响应");
      const payload = JSON.parse(utf8BytesToString(new Uint8Array(rawBuffer)) || "null");
      const nestedCandidate = extractHistoryImageCandidate(payload) || extractImageCandidate(payload);
      if (!nestedCandidate || nestedCandidate.value === candidate.value) {
        throw new Error("历史图片接口没有返回可读取的图片");
      }
      return await historyCandidateToImage(nestedCandidate, apiKey, signal, depth + 1);
    }
    return await readImageResponse(response);
  } finally {
    if (timeoutHandle) clearTimeout(timeoutHandle);
    if (signal && typeof signal.removeEventListener === "function") {
      signal.removeEventListener("abort", abortDownload);
    }
  }
}

function waitForHistoryPoll(signal) {
  return new Promise((resolve, reject) => {
    let timer = null;
    const abortWait = () => {
      if (timer !== null) clearTimeout(timer);
      if (signal && typeof signal.removeEventListener === "function") {
        signal.removeEventListener("abort", abortWait);
      }
      const error = new Error("任务已取消");
      error.name = "AbortError";
      reject(error);
    };
    if (signal && signal.aborted) {
      abortWait();
      return;
    }
    if (signal && typeof signal.addEventListener === "function") {
      signal.addEventListener("abort", abortWait);
    }
    timer = setTimeout(() => {
      if (signal && typeof signal.removeEventListener === "function") {
        signal.removeEventListener("abort", abortWait);
      }
      resolve();
    }, HISTORY_RECOVERY_POLL_MS);
  });
}

function historyRecoverableOutcome(outcome) {
  if (!outcome || outcome.ok || outcome.skipped || !outcome.requestSubmitted) return false;
  if (isAbortError(outcome.error) && !outcome.timedOut) return false;
  const status = Number(outcome.error && outcome.error.httpStatus) || 0;
  return outcome.timedOut || status >= 500 || status === 0;
}

function serverMayStillCompleteOutcome(outcome) {
  if (!outcome || outcome.ok || !outcome.requestSubmitted) return false;
  if (outcome.timedOut || isAbortError(outcome.error)) return true;
  const status = Number(outcome.error && outcome.error.httpStatus) || 0;
  return status >= 500 || status === 0;
}

async function storeResult(image, snapshot, requested, prompt, options = {}) {
  const historyFolder = await getPersistentHistoryFolder();
  let file = null;
  let result = null;
  try {
    const fileTag = String(options.fileTag || state.resultSequence + 1).replace(/[^A-Za-z0-9_-]/g, "");
    const storageFileName = `result-${Date.now()}-${state.resultSequence + 1}-${fileTag}.${image.type.extension}`;
    file = await historyFolder.createFile(
      storageFileName,
      { overwrite: true }
    );
    await file.write(image.buffer, { format: formats.binary });
    state.resultSequence += 1;
    result = {
      id: `result-${Date.now()}-${state.resultSequence}`,
      sequence: state.resultSequence,
      file,
      storageFileName,
      previewUrl: null,
      mime: image.type.mime,
      extension: image.type.extension,
      byteLength: image.buffer.byteLength,
      width: image.type.width,
      height: image.type.height,
      count: image.count || 1,
      snapshot,
      maskFile: null,
      maskFileName: "",
      requested,
      prompt: String(prompt || "").trim(),
      taskArchive: options.taskArchive || null,
      imageFingerprint: String(options.imageFingerprint || imageBufferFingerprint(image.buffer)),
      recoveredFromHistory: Boolean(options.recoveredFromHistory),
      historyRecordKey: String(options.historyRecordKey || ""),
      sourceJobId: String(options.sourceJobId || ""),
      createdAt: options.createdAt ? new Date(options.createdAt) : new Date(),
      insertedAt: null,
      precisePlacement: null,
      openedAt: null,
      openedFiles: [],
      persistent: true,
      released: false
    };

    await createResultPreview(result, image.buffer);
    await ensureSnapshotMaskStored(result, "result");
    retainTaskArchive(result.taskArchive);
    state.results.unshift(result);
    state.results.sort((left, right) => (
      new Date(right.createdAt || 0).getTime() - new Date(left.createdAt || 0).getTime()
    ));
    if (options.selectResult !== false) {
      state.selectedResultId = result.id;
    }
    while (state.results.length > MAX_RESULTS) {
      let expiredIndex = state.results.length - 1;
      while (expiredIndex >= 0 && state.results[expiredIndex].id === state.selectedResultId) {
        expiredIndex -= 1;
      }
      if (expiredIndex < 0) break;
      const expired = state.results.splice(expiredIndex, 1)[0];
      await releaseResult(expired);
    }
    await queuePersistHistoryState();
    renderResultHistory();
    return result;
  } catch (error) {
    if (result) {
      revokeResultPreview(result);
      await safeDelete(result.maskFile);
    }
    await safeDelete(file);
    throw error;
  }
}

function pendingOutstandingTasks() {
  const activeIds = new Set(state.generationJobs.map((job) => job.id));
  return state.pendingHistoryTasks.filter((task) => (
    !activeIds.has(task.id) && pendingHistoryOutstandingCount(task) > 0
  ));
}

function pendingTasksForStartupRecovery() {
  const now = Date.now();
  return pendingOutstandingTasks().filter((task) => (
    !task.autoRecoveryExhausted && (
      !Number(task.autoRecoveryStartedAt) ||
      now < Number(task.autoRecoveryStartedAt) + HISTORY_RECOVERY_TIMEOUT_MS
    )
  ));
}

async function recoverPendingHistoryTasksOnStartup() {
  if (state.recoveringPendingHistory || !state.apiKey) return;
  if (!pendingTasksForStartupRecovery().length) return;

  const controller = new AbortController();
  pendingHistoryRecoveryController = controller;
  state.pendingHistoryRecoveryStopRequested = false;
  state.recoveringPendingHistory = true;
  updateControls();
  const recoveryStartedAt = Date.now();
  const startupTasks = pendingTasksForStartupRecovery();
  startupTasks.forEach((task) => {
    if (!Number(task.autoRecoveryStartedAt)) task.autoRecoveryStartedAt = recoveryStartedAt;
  });
  await queuePersistHistoryState();
  const deadline = Math.max(
    recoveryStartedAt,
    ...startupTasks.map((task) => Number(task.autoRecoveryStartedAt) + HISTORY_RECOVERY_TIMEOUT_MS)
  );
  let recoveredCount = 0;
  let lastError = null;
  let invalidKey = false;
  setStatus(
    "working",
    "正在找回上次未显示的图片",
    "只查询最近 3 天的生成历史，不会重新发送生成请求"
  );

  try {
    while (!controller.signal.aborted && Date.now() < deadline) {
      const tasks = pendingTasksForStartupRecovery();
      if (!tasks.length) break;
      try {
        const payload = await fetchGenerationHistory(state.apiKey, controller.signal);
        const recoveredHistoryKeys = [];
        state.pendingHistoryTasks.forEach((task) => {
          recoveredHistoryKeys.push(...Array.from(task.recoveredHistoryKeys || []));
        });
        const usedHistoryKeys = new Set([
          ...state.results.map((result) => result.historyRecordKey).filter(Boolean),
          ...recoveredHistoryKeys
        ]);
        const usedFingerprints = new Set(state.results.map((result) => result.imageFingerprint).filter(Boolean));

        for (const task of tasks) {
          let outstanding = pendingHistoryOutstandingCount(task);
          if (!outstanding) continue;
          const matches = matchingHistoryRecords(payload, task);
          for (const item of matches) {
            if (!outstanding || controller.signal.aborted) break;
            if (item.key && usedHistoryKeys.has(item.key)) continue;
            const candidate = extractHistoryImageCandidate(item.record);
            if (!candidate) continue;
            try {
              const image = await historyCandidateToImage(candidate, state.apiKey, controller.signal);
              const fingerprint = imageBufferFingerprint(image.buffer);
              if (usedFingerprints.has(fingerprint)) {
                if (item.key) {
                  task.recoveredHistoryKeys.add(String(item.key));
                  usedHistoryKeys.add(String(item.key));
                  await queuePersistHistoryState();
                }
                continue;
              }
              const metadata = historyRecordMetadata(item.record);
              const result = await storeResult(
                image,
                task.snapshot,
                task.requested,
                task.prompt,
                {
                  fileTag: `${task.sequence}-startup-history-${task.resolvedCount + 1}`,
                  selectResult: !getSelectedResult(),
                  taskArchive: null,
                  imageFingerprint: fingerprint,
                  recoveredFromHistory: true,
                  historyRecordKey: item.key || "",
                  sourceJobId: task.id,
                  createdAt: Number(metadata.createdAt) || Date.now()
                }
              );
              usedFingerprints.add(fingerprint);
              if (!state.selectedResultId) state.selectedResultId = result.id;
              recoveredCount += 1;
              task.resolvedCount = Math.min(task.requestedCount, Number(task.resolvedCount || 0) + 1);
              if (item.key) {
                task.recoveredHistoryKeys.add(String(item.key));
                usedHistoryKeys.add(String(item.key));
              }
              outstanding = pendingHistoryOutstandingCount(task);
              await queuePersistHistoryState();
              setStatus(
                "working",
                `已找回 ${recoveredCount} 张上次未显示的图片`,
                outstanding ? `任务 ${task.sequence} 还有 ${outstanding} 张继续查询` : `任务 ${task.sequence} 已找齐`
              );
            } catch (error) {
              if (isAbortError(error) && controller.signal.aborted) throw error;
              if (error && error.httpStatus === 401) throw error;
              lastError = error;
            }
          }
          if (pendingHistoryOutstandingCount(task) <= 0) {
            await removePendingHistoryTask(task);
          }
        }
      } catch (error) {
        if (isAbortError(error) && controller.signal.aborted) break;
        lastError = error;
        if (error && error.httpStatus === 401) {
          invalidKey = true;
          await clearStoredApiKey();
          break;
        }
      }

      const remainingTasks = pendingTasksForStartupRecovery();
      if (!remainingTasks.length || controller.signal.aborted || Date.now() >= deadline) break;
      const remainingImages = remainingTasks.reduce(
        (total, task) => total + pendingHistoryOutstandingCount(task),
        0
      );
      setStatus(
        "working",
        "正在继续查询上次的生成任务",
        `还有 ${remainingImages} 张暂未出现；10 秒后继续查询，不会重新生成`
      );
      try {
        await waitForHistoryPoll(controller.signal);
      } catch (error) {
        if (isAbortError(error) && controller.signal.aborted) break;
        throw error;
      }
    }
  } finally {
    if (pendingHistoryRecoveryController === controller) pendingHistoryRecoveryController = null;
    state.recoveringPendingHistory = false;
    updateControls();
  }

  const remainingTasks = pendingOutstandingTasks();
  const now = Date.now();
  const exhaustedTasks = remainingTasks.filter((task) => (
    Number(task.autoRecoveryStartedAt) &&
    now >= Number(task.autoRecoveryStartedAt) + HISTORY_RECOVERY_TIMEOUT_MS
  ));
  const recoveryTimedOut = Boolean(!controller.signal.aborted && !invalidKey && exhaustedTasks.length);
  if (exhaustedTasks.length) {
    exhaustedTasks.forEach((task) => {
      task.autoRecoveryExhausted = true;
    });
    await queuePersistHistoryState();
  }
  const remainingImages = remainingTasks.reduce(
    (total, task) => total + pendingHistoryOutstandingCount(task),
    0
  );
  const stoppedByUser = state.pendingHistoryRecoveryStopRequested;
  state.pendingHistoryRecoveryStopRequested = false;
  if (stoppedByUser) {
    setStatus(
      "warning",
      "已停止查询上次的生成任务",
      remainingImages
        ? `还有 ${remainingImages} 张待找回，记录已经保留；下次打开插件会继续查询`
        : "已找到的图片仍保留在生成历史中"
    );
  } else if (invalidKey) {
    setStatus("error", "API Key 已失效", "旧密钥已清除；重新输入后会继续查询未显示的图片");
  } else if (!remainingImages) {
    setStatus(
      "success",
      recoveredCount ? `已找回 ${recoveredCount} 张历史图片` : "上次的生成任务已核对完成",
      recoveredCount ? "图片已放回生成历史，可直接查看或插入" : "没有需要继续找回的图片"
    );
  } else if (recoveryTimedOut) {
    setStatus(
      "warning",
      `还有 ${remainingImages} 张暂未找到，自动查询已结束`,
      "单个任务最多自动查询 2 分钟；下次打开 Photoshop 不会重复查询，可稍后到 API 历史页面查看"
    );
  } else {
    const errorNote = lastError ? `；最后一次提示：${sanitizeMessage(lastError.message || lastError)}` : "";
    setStatus(
      "warning",
      `还有 ${remainingImages} 张暂未找到`,
      `任务记录已经保存，下次打开 Photoshop 会继续查询${errorNote}`
    );
  }
}

async function batchPlayChecked(descriptors) {
  const results = await action.batchPlay(descriptors, {});
  for (const result of results) {
    if (result && String(result._obj).toLowerCase() === "error") {
      throw new Error(result.message || "Photoshop 操作失败");
    }
  }
  return results;
}

async function selectDocument(documentId) {
  await batchPlayChecked([
    {
      _obj: "select",
      _target: [{ _ref: "document", _id: documentId }]
    }
  ]);
}

async function selectDocumentAndLayer(documentId, layerId) {
  await batchPlayChecked([
    {
      _obj: "select",
      _target: [{ _ref: "document", _id: documentId }]
    },
    {
      _obj: "select",
      _target: [{ _ref: "layer", _id: layerId }],
      makeVisible: false
    }
  ]);
}

async function selectLayerMask(documentId, layerId) {
  await selectDocumentAndLayer(documentId, layerId);
  await batchPlayChecked([
    {
      _obj: "select",
      _target: [{ _ref: "channel", _enum: "channel", _value: "mask" }],
      makeVisible: false,
      _options: { dialogOptions: "dontDisplay" }
    }
  ]);
}

async function createHideAllLayerMask() {
  await batchPlayChecked([
    {
      _obj: "make",
      new: { _class: "channel" },
      at: { _ref: "channel", _enum: "channel", _value: "mask" },
      using: { _enum: "userMaskEnabled", _value: "hideAll" }
    }
  ]);
}

async function convertActiveLayerToSmartObject() {
  await batchPlayChecked([
    {
      _obj: "newPlacedLayer",
      _options: { dialogOptions: "dontDisplay" }
    }
  ]);
}

function findOpenDocument(documentId) {
  for (let index = 0; index < app.documents.length; index += 1) {
    const document = app.documents[index];
    if (document.id === documentId) return document;
  }
  return null;
}

function documentMatchesSnapshot(document, snapshot) {
  if (!document || !snapshot) return false;
  const title = String(document.title || document.name || "").trim();
  const expectedTitle = String(snapshot.documentTitle || "").trim();
  return Boolean(expectedTitle) && title === expectedTitle &&
    Math.round(Number(document.width)) === Math.round(Number(snapshot.documentWidth)) &&
    Math.round(Number(document.height)) === Math.round(Number(snapshot.documentHeight)) &&
    String(document.mode) === String(snapshot.documentMode) &&
    Math.abs((Number(document.resolution) || 72) - (Number(snapshot.documentResolution) || 72)) <= 0.01;
}

function findOpenDocumentForSnapshot(snapshot) {
  const byId = findOpenDocument(snapshot && snapshot.documentId);
  if (byId) return byId;
  const matches = [];
  for (let index = 0; index < app.documents.length; index += 1) {
    const document = app.documents[index];
    if (documentMatchesSnapshot(document, snapshot)) matches.push(document);
  }
  if (matches.length > 1) {
    throw new Error("找到多个同名、同尺寸的 Photoshop 文档，请只保留原文档后再插入");
  }
  if (!matches.length) return null;
  snapshot.documentId = matches[0].id;
  return matches[0];
}

function findLayerById(layers, layerId) {
  if (!layers || layerId === null || layerId === undefined) return null;
  const wanted = Number(layerId);
  for (let index = 0; index < layers.length; index += 1) {
    const layer = layers[index];
    if (Number(layer.id) === wanted) return layer;
    let children = null;
    try {
      children = layer.layers;
    } catch (_) {
      children = null;
    }
    if (children && children.length) {
      const nested = findLayerById(children, wanted);
      if (nested) return nested;
    }
  }
  return null;
}

function formatLayerTimestamp(value) {
  const date = value instanceof Date ? value : new Date(value);
  const safe = Number.isNaN(date.getTime()) ? new Date() : date;
  return [
    String(safe.getMonth() + 1).padStart(2, "0"),
    String(safe.getDate()).padStart(2, "0"),
    "-",
    String(safe.getHours()).padStart(2, "0"),
    String(safe.getMinutes()).padStart(2, "0"),
    String(safe.getSeconds()).padStart(2, "0")
  ].join("");
}

function buildGeneratedLayerName(result) {
  const compact = String(result && result.prompt || "")
    .replace(/[\u0000-\u001f\u007f]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const summary = Array.from(compact || "局部生成").slice(0, 18).join("");
  const resolution = result && result.requested && result.requested.resolution
    ? result.requested.resolution
    : "AI";
  return `AI｜${summary}｜${resolution}｜${formatLayerTimestamp(result && result.createdAt)}`;
}

async function moveAboveInsertionAnchor(insertedLayer, targetDocument, snapshot) {
  const anchor = findLayerById(targetDocument.layers, snapshot.insertionAnchorLayerId);
  if (!anchor || Number(anchor.id) === Number(insertedLayer.id)) return false;
  let placementTarget = anchor;
  try {
    const parent = anchor.parent;
    const siblings = parent && parent.layers ? parent.layers : targetDocument.layers;
    let anchorIndex = -1;
    for (let index = 0; index < siblings.length; index += 1) {
      if (Number(siblings[index].id) === Number(anchor.id)) {
        anchorIndex = index;
        break;
      }
    }
    // Photoshop lists the top layer first. Keep a normal AI layer outside an
    // existing clipping stack so it cannot become a new clipping base.
    for (let index = anchorIndex - 1; index >= 0; index -= 1) {
      const candidate = siblings[index];
      if (!candidate || candidate.isClippingMask !== true) break;
      placementTarget = candidate;
    }
  } catch (_) {
    placementTarget = anchor;
  }
  try {
    await insertedLayer.move(placementTarget, constants.ElementPlacement.PLACEBEFORE);
    return true;
  } catch (_) {
    try {
      await insertedLayer.bringToFront();
    } catch (_) {
      // Cross-document duplication normally starts at the document top already.
    }
    return false;
  }
}

function numericLayerBounds(bounds) {
  return {
    left: Number(bounds.left) || 0,
    top: Number(bounds.top) || 0,
    right: Number(bounds.right) || 0,
    bottom: Number(bounds.bottom) || 0
  };
}

async function clearActivePixelSelection(document) {
  if (!document || !document.selection || !document.selection.bounds) return false;
  await document.selection.deselect();
  return true;
}

function prepareLocalEditMask(snapshot) {
  if (!snapshot || !snapshot.mask || !snapshot.mask.bytes) {
    return { bytes: null, featherRadius: 0 };
  }
  const source = snapshot.mask.bytes;
  const width = Math.round(Number(snapshot.mask.width));
  const height = Math.round(Number(snapshot.mask.height));
  const pixelCount = width * height;
  if (
    !snapshot.editBounds || width <= 0 || height <= 0 ||
    source.length < pixelCount || pixelCount > 12 * 1024 * 1024
  ) {
    return { bytes: source, featherRadius: 0 };
  }

  const selectedMode = String(snapshot.localEditMode || "general");
  const ratio = selectedMode === "head" ? 0.012 : 0.008;
  const featherRadius = Math.max(2, Math.min(selectedMode === "head" ? 14 : 10, Math.round(Math.min(width, height) * ratio)));
  const limit = featherRadius + 1;
  const distance = new Uint16Array(pixelCount);

  for (let y = 0; y < height; y += 1) {
    const row = y * width;
    for (let x = 0; x < width; x += 1) {
      const index = row + x;
      if (!source[index]) continue;
      distance[index] = Math.min(limit, x + 1, y + 1, width - x, height - y);
    }
  }
  for (let y = 0; y < height; y += 1) {
    const row = y * width;
    for (let x = 0; x < width; x += 1) {
      const index = row + x;
      if (!distance[index]) continue;
      let value = distance[index];
      if (x > 0 && distance[index - 1] + 1 < value) value = distance[index - 1] + 1;
      if (y > 0 && distance[index - width] + 1 < value) value = distance[index - width] + 1;
      distance[index] = Math.min(limit, value);
    }
  }
  for (let y = height - 1; y >= 0; y -= 1) {
    const row = y * width;
    for (let x = width - 1; x >= 0; x -= 1) {
      const index = row + x;
      if (!distance[index]) continue;
      let value = distance[index];
      if (x + 1 < width && distance[index + 1] + 1 < value) value = distance[index + 1] + 1;
      if (y + 1 < height && distance[index + width] + 1 < value) value = distance[index + width] + 1;
      distance[index] = Math.min(limit, value);
    }
  }

  const output = new Uint8Array(pixelCount);
  for (let index = 0; index < pixelCount; index += 1) {
    if (!source[index]) continue;
    const ramp = Math.min(1, distance[index] / limit);
    output[index] = Math.min(source[index], Math.round(255 * ramp));
  }
  return { bytes: output, featherRadius };
}

async function createInsertionSourceFile(result) {
  if (!result || result.released || !result.file) throw new Error("生成结果原始文件已不可用");
  const storedBytes = await result.file.read({ format: formats.binary });
  const storedBuffer = exactArrayBuffer(storedBytes);
  if (!storedBuffer.byteLength || (
    Number(result.byteLength) > 0 && storedBuffer.byteLength !== Number(result.byteLength)
  )) {
    throw new Error("生成结果原始文件大小校验失败，请重新生成");
  }

  const detected = detectImageType(storedBuffer);
  if (
    detected.mime !== result.mime ||
    (Number(result.width) > 0 && detected.width !== Number(result.width)) ||
    (Number(result.height) > 0 && detected.height !== Number(result.height))
  ) {
    throw new Error("生成结果原始文件内容校验失败，请重新生成");
  }

  const temporaryFolder = await localFileSystem.getTemporaryFolder();
  let insertionFile = null;
  try {
    insertionFile = await temporaryFolder.createFile(
      `katu-insert-${result.id}-${Date.now()}.${detected.extension}`,
      { overwrite: true }
    );
    await insertionFile.write(storedBuffer, { format: formats.binary });
    return insertionFile;
  } catch (error) {
    await safeDelete(insertionFile);
    throw error;
  }
}

async function openResultInPhotoshop(result) {
  const openingFile = await createInsertionSourceFile(result);
  try {
    let openedDocument = null;
    await core.executeAsModal(async () => {
      openedDocument = await app.open(openingFile);
    }, { commandName: "在 Photoshop 中打开 AI 生成原图" });
    if (!Array.isArray(result.openedFiles)) result.openedFiles = [];
    result.openedFiles.push(openingFile);
    return openedDocument;
  } catch (error) {
    await safeDelete(openingFile);
    throw error;
  }
}

async function insertResult(result, precisePlacement) {
  if (!result || !result.snapshot) throw new Error("没有可插入的生成结果");
  const snapshot = result.snapshot;
  const precise = precisePlacement !== false;
  const targetDocument = findOpenDocumentForSnapshot(snapshot);
  if (!targetDocument) throw new Error("没有找到生成时的 Photoshop 文档；请先重新打开原文档再插入");
  if (
    Math.round(Number(targetDocument.width)) !== snapshot.documentWidth ||
    Math.round(Number(targetDocument.height)) !== snapshot.documentHeight
  ) {
    throw new Error("原文档画布尺寸已改变，请重新获取参考图后生成");
  }
  if (targetDocument.mode !== snapshot.documentMode) {
    throw new Error("原文档颜色模式已改变，请重新获取参考图后生成");
  }
  if (Math.abs((Number(targetDocument.resolution) || 72) - snapshot.documentResolution) > 0.01) {
    throw new Error("原文档分辨率已改变，请重新获取参考图后生成");
  }
  if (precise && snapshot.maskUnavailable) {
    throw new Error("这张历史图保存的原选区蒙版已缺失，无法安全地精确回填；可关闭精确放回后插入");
  }

  let insertedLayerId = null;
  let placedAboveAnchor = false;
  let maskCreated = false;
  let maskFocused = false;
  let selectionCleared = false;
  let featherRadius = 0;
  const insertionFile = await createInsertionSourceFile(result);
  try {
    await core.executeAsModal(async (executionContext) => {
      let suspension = null;
      let generatedDocument = null;
      let generatedSourceLayer = null;
      let maskImageData = null;
      try {
      executionContext.reportProgress({ value: 0.12, commandName: "正在解码生成图片" });
      generatedDocument = await app.open(insertionFile);
      await executionContext.hostControl.registerAutoCloseDocument(generatedDocument.id);
      if (!generatedDocument.layers.length) throw new Error("生成图片中没有可用图层");
      generatedSourceLayer = generatedDocument.layers[0];

      await selectDocumentAndLayer(generatedDocument.id, generatedSourceLayer.id);
      await convertActiveLayerToSmartObject();
      generatedSourceLayer = generatedDocument.layers[0];
      if (!generatedSourceLayer) throw new Error("无法建立保留原始清晰度的智能对象");

      if (precise) {
        const targetWidth = snapshot.bounds.width;
        const targetHeight = snapshot.bounds.height;
        const crop = computeCoverCrop(
          generatedDocument.width,
          generatedDocument.height,
          targetWidth,
          targetHeight
        );
        if (
          crop.left !== 0 || crop.top !== 0 ||
          crop.right !== Math.round(Number(generatedDocument.width)) ||
          crop.bottom !== Math.round(Number(generatedDocument.height))
        ) {
          await generatedDocument.crop({
            left: crop.left,
            top: crop.top,
            right: crop.right,
            bottom: crop.bottom
          });
        }
        await generatedDocument.resizeImage(targetWidth, targetHeight, targetDocument.resolution);
      }
      executionContext.reportProgress({
        value: 0.48,
        commandName: precise ? "正在精确适配原选区" : "正在准备智能对象图层"
      });

      suspension = await executionContext.hostControl.suspendHistory({
        documentID: targetDocument.id,
        name: precise ? "AI 局部生成（精确回填）" : "AI 图生图插入"
      });

      let insertedLayer = null;
      if (precise) {
        await selectDocument(targetDocument.id);
        selectionCleared = await clearActivePixelSelection(targetDocument);
        await selectDocumentAndLayer(generatedDocument.id, generatedSourceLayer.id);
        insertedLayer = await generatedSourceLayer.duplicate(targetDocument);
        insertedLayer.name = buildGeneratedLayerName(result);
        insertedLayerId = insertedLayer.id;
        await selectDocumentAndLayer(targetDocument.id, insertedLayer.id);
        const copiedBounds = numericLayerBounds(insertedLayer.boundsNoEffects);
        const targetCenterX = (snapshot.bounds.left + snapshot.bounds.right) / 2;
        const targetCenterY = (snapshot.bounds.top + snapshot.bounds.bottom) / 2;
        const copiedCenterX = (copiedBounds.left + copiedBounds.right) / 2;
        const copiedCenterY = (copiedBounds.top + copiedBounds.bottom) / 2;
        await insertedLayer.translate(targetCenterX - copiedCenterX, targetCenterY - copiedCenterY);
        placedAboveAnchor = await moveAboveInsertionAnchor(insertedLayer, targetDocument, snapshot);
        await selectDocumentAndLayer(targetDocument.id, insertedLayer.id);
      } else {
        await selectDocumentAndLayer(generatedDocument.id, generatedSourceLayer.id);
        insertedLayer = await generatedSourceLayer.duplicate(targetDocument);
        insertedLayer.name = buildGeneratedLayerName(result);
        insertedLayerId = insertedLayer.id;
        await selectDocumentAndLayer(targetDocument.id, insertedLayer.id);
        placedAboveAnchor = await moveAboveInsertionAnchor(insertedLayer, targetDocument, snapshot);
        await selectDocumentAndLayer(targetDocument.id, insertedLayer.id);
        const copiedBounds = numericLayerBounds(insertedLayer.boundsNoEffects);
        const targetCenterX = (snapshot.bounds.left + snapshot.bounds.right) / 2;
        const targetCenterY = (snapshot.bounds.top + snapshot.bounds.bottom) / 2;
        const copiedCenterX = (copiedBounds.left + copiedBounds.right) / 2;
        const copiedCenterY = (copiedBounds.top + copiedBounds.bottom) / 2;
        await insertedLayer.translate(targetCenterX - copiedCenterX, targetCenterY - copiedCenterY);
      }

      if (precise) {
        executionContext.reportProgress({
          value: 0.72,
          commandName: snapshot.mask ? "正在还原选区羽化蒙版" : "正在创建可编辑图层蒙版"
        });
        await selectDocumentAndLayer(targetDocument.id, insertedLayer.id);
        await createHideAllLayerMask();
        maskCreated = true;
        const maskWidth = snapshot.mask ? snapshot.mask.width : snapshot.bounds.width;
        const maskHeight = snapshot.mask ? snapshot.mask.height : snapshot.bounds.height;
        const maskBounds = snapshot.mask ? snapshot.mask.bounds : snapshot.bounds;
        const preparedMask = snapshot.mask
          ? prepareLocalEditMask(snapshot)
          : { bytes: new Uint8Array(maskWidth * maskHeight).fill(255), featherRadius: 0 };
        const maskBytes = preparedMask.bytes;
        featherRadius = preparedMask.featherRadius;
        maskImageData = await imaging.createImageDataFromBuffer(maskBytes, {
          width: maskWidth,
          height: maskHeight,
          components: 1,
          chunky: false,
          colorSpace: "Grayscale",
          colorProfile: "Gray Gamma 2.2"
        });
        await imaging.putLayerMask({
          documentID: targetDocument.id,
          layerID: insertedLayer.id,
          kind: "user",
          imageData: maskImageData,
          replace: false,
          targetBounds: {
            left: maskBounds.left,
            top: maskBounds.top
          },
          commandName: "以蒙版还原原选区"
        });
      }

      if (executionContext.isCancelled) throw new Error("插入操作已取消");
      await selectDocumentAndLayer(targetDocument.id, insertedLayer.id);
      executionContext.reportProgress({ value: 1, commandName: "插入完成" });
      await executionContext.hostControl.resumeHistory(suspension, true);
      suspension = null;
      if (maskCreated) {
        try {
          await selectLayerMask(targetDocument.id, insertedLayer.id);
          maskFocused = true;
        } catch (_) {
          try {
            await selectDocumentAndLayer(targetDocument.id, insertedLayer.id);
          } catch (_) {
            // The layer is already inserted; thumbnail focus is non-critical.
          }
        }
      }
      } catch (error) {
        if (suspension) {
          try {
            await executionContext.hostControl.resumeHistory(suspension, false);
          } catch (_) {
            // A thrown modal scope also rolls back an unresumed suspension.
          }
        }
        throw error;
      } finally {
        if (maskImageData) maskImageData.dispose();
        // generatedDocument is registered for automatic close at modal exit.
      }
    }, { commandName: "插入 AI 生成原图" });
  } finally {
    await safeDelete(insertionFile);
  }

  return {
    insertedLayerId,
    placedAboveAnchor,
    maskCreated,
    maskFocused,
    selectionCleared,
    featherRadius,
    preservedResolution: true
  };
}

function isAbortError(error) {
  return error && (error.name === "AbortError" || /aborted|取消/i.test(String(error.message || error)));
}

async function runGenerationJob(job) {
  let returnedMultiple = false;
  let unexpectedError = null;
  let recoverySummary = { attempted: 0, recovered: 0, lastError: null };
  const completedAction = hasPhotoshopDocument(job.snapshot) ? "插入" : "在 Photoshop 中打开";

  const acceptGeneratedImage = async (image, index, options = {}) => {
    const fingerprint = imageBufferFingerprint(image.buffer);
    const alreadyStored = job.imageFingerprints.has(fingerprint) || state.results.some(
      (result) => result.imageFingerprint === fingerprint
    );
    if (options.recoveredFromHistory && alreadyStored) return null;
    const result = await storeResult(
      image,
      job.snapshot,
      job.requested,
      job.prompt,
      {
        fileTag: options.recoveredFromHistory
          ? String(job.sequence) + "-history-" + String(index + 1)
          : String(job.sequence) + "-" + String(index + 1),
        selectResult: false,
        taskArchive: job.taskArchive,
        imageFingerprint: fingerprint,
        recoveredFromHistory: Boolean(options.recoveredFromHistory),
        historyRecordKey: options.historyRecordKey || "",
        sourceJobId: job.id
      }
    );
    job.imageFingerprints.add(fingerprint);
    const firstCompleted = job.completedCount === 0;
    job.completedCount += 1;
    if (options.recoveredFromHistory) {
      job.recoveredCount += 1;
      job.failedCount = Math.max(0, job.failedCount - 1);
    }
    await markPendingRequestResolved(job, options.historyRecordKey || "");
    if (result.count > 1) returnedMultiple = true;
    const shouldAutoSelect = !getSelectedResult() || (
      job.autoSelect && state.selectionRevision === job.selectionRevisionAtStart
    );
    if (firstCompleted && shouldAutoSelect) {
      state.selectedResultId = result.id;
      state.selectionRevision += 1;
      renderResultHistory();
    }
    renderGenerationQueue();
    return result;
  };

  const runConcurrentRequest = async (index) => {
    const requestController = new AbortController();
    let timeoutHandle = null;
    let timedOut = false;
    let requestSubmitted = false;
    let responseReceived = false;
    const abortRequest = () => requestController.abort();
    job.requestControllers.push(requestController);

    if (job.controller.signal.aborted) {
      abortRequest();
    } else if (typeof job.controller.signal.addEventListener === "function") {
      job.controller.signal.addEventListener("abort", abortRequest);
    }

    try {
      if (job.controller.signal.aborted) {
        const stopped = new Error("任务已取消");
        stopped.name = "AbortError";
        throw stopped;
      }
      const pendingSaved = await markPendingRequestSubmitted(job);
      if (!pendingSaved) {
        throw new Error("无法保存本次待找回记录；为避免断线后丢失结果，生成请求未发送");
      }
      if (job.controller.signal.aborted || requestController.signal.aborted) {
        await unmarkPendingRequestSubmitted(job);
        const stopped = new Error("任务已取消");
        stopped.name = "AbortError";
        throw stopped;
      }
      timeoutHandle = setTimeout(() => {
        timedOut = true;
        requestController.abort();
      }, API_CONFIG.timeoutMs);
      requestSubmitted = true;
      const image = await requestImageEdit({
        apiKey: job.apiKey,
        model: job.model,
        prompt: job.requestPrompt || job.prompt,
        size: job.requested.size,
        imageFiles: job.imageFiles,
        signal: requestController.signal
      });
      responseReceived = true;
      if (job.controller.signal.aborted) {
        const stopped = new Error("任务已取消");
        stopped.name = "AbortError";
        throw stopped;
      }

      const result = await acceptGeneratedImage(image, index);
      return { ok: true, index, result };
    } catch (error) {
      job.failedCount += 1;
      if (error && error.httpStatus === 401) await clearStoredApiKey();
      const outcome = {
        ok: false,
        index,
        error,
        timedOut,
        requestSubmitted,
        responseReceived: responseReceived || Boolean(error && error.responseReceived)
      };
      if (requestSubmitted && !serverMayStillCompleteOutcome(outcome)) {
        await markPendingRequestKnownFailed(job);
      }
      return outcome;
    } finally {
      if (timeoutHandle) clearTimeout(timeoutHandle);
      if (typeof job.controller.signal.removeEventListener === "function") {
        job.controller.signal.removeEventListener("abort", abortRequest);
      }
      const requestIndex = job.requestControllers.indexOf(requestController);
      if (requestIndex >= 0) job.requestControllers.splice(requestIndex, 1);
      job.settledCount += 1;
      renderGenerationQueue();
      const remaining = job.requestedCount - job.settledCount;
      if (remaining > 0 && !state.inserting) {
        const readyNote = job.completedCount > 0
          ? "已完成 " + job.completedCount + " 张，可先选择并" + completedAction + "；"
          : "";
        const failedNote = job.failedCount > 0 ? "失败 " + job.failedCount + " 张；" : "";
        setStatus(
          "working",
          "任务 " + job.sequence + " 并发生成中 " + job.settledCount + " / " + job.requestedCount,
          readyNote + failedNote + "还有 " + remaining + " 张处理中"
        );
      }
    }
  };

  const recoverFromHistory = async (recoverableOutcomes) => {
    const pending = recoverableOutcomes.slice();
    const pendingTask = pendingTaskForJob(job);
    const usedHistoryKeys = new Set([
      ...state.results.map((result) => result.historyRecordKey).filter(Boolean),
      ...Array.from(pendingTask && pendingTask.recoveredHistoryKeys || [])
    ]);
    if (pendingTask && !Number(pendingTask.autoRecoveryStartedAt)) {
      pendingTask.autoRecoveryStartedAt = Date.now();
      await queuePersistHistoryState();
    }
    const deadline = pendingTask && Number(pendingTask.autoRecoveryStartedAt)
      ? Number(pendingTask.autoRecoveryStartedAt) + HISTORY_RECOVERY_TIMEOUT_MS
      : Date.now() + HISTORY_RECOVERY_TIMEOUT_MS;
    let lastError = null;
    job.status = "recovering";
    renderGenerationQueue();
    updateControls();
    setStatus(
      "warning",
      "任务 " + job.sequence + " 连接已断开，正在找回",
      "生成请求不会重发；正在从最近 3 天的 API 历史中查找已生成图片"
    );

    while (pending.length && !job.controller.signal.aborted && Date.now() < deadline) {
      try {
        const payload = await fetchGenerationHistory(job.apiKey, job.controller.signal);
        const matches = matchingHistoryRecords(payload, job);
        for (const item of matches) {
          if (!pending.length) break;
          if (item.key && usedHistoryKeys.has(item.key)) continue;
          const candidate = extractHistoryImageCandidate(item.record);
          if (!candidate) continue;
          try {
            const image = await historyCandidateToImage(candidate, job.apiKey, job.controller.signal);
            const fingerprint = imageBufferFingerprint(image.buffer);
            if (job.imageFingerprints.has(fingerprint)) {
              if (item.key) usedHistoryKeys.add(item.key);
              continue;
            }
            const outcome = pending[0];
            const result = await acceptGeneratedImage(image, outcome.index, {
              recoveredFromHistory: true,
              historyRecordKey: item.key
            });
            if (!result) {
              if (item.key) usedHistoryKeys.add(item.key);
              continue;
            }
            pending.shift();
            outcome.ok = true;
            outcome.recovered = true;
            outcome.result = result;
            outcome.historyRecordKey = item.key;
            if (item.key) usedHistoryKeys.add(item.key);
            setStatus(
              "working",
              "任务 " + job.sequence + " 已从历史找回 " + job.recoveredCount + " 张",
              pending.length ? "还有 " + pending.length + " 张继续查询中；不会重新发送生成请求" : "正在整理找回的图片"
            );
          } catch (error) {
            if (isAbortError(error) && job.controller.signal.aborted) throw error;
            if (error && error.httpStatus === 401) throw error;
            lastError = error;
          }
        }
      } catch (error) {
        if (isAbortError(error) && job.controller.signal.aborted) throw error;
        lastError = error;
        if (error && error.httpStatus === 401) {
          await clearStoredApiKey();
          break;
        }
      }

      if (pending.length && !job.controller.signal.aborted && Date.now() < deadline) {
        setStatus(
          "working",
          "任务 " + job.sequence + " 正在查询生成历史",
          "暂时还没找到全部图片；10 秒后继续查询，不会重新扣费生成"
        );
        await waitForHistoryPoll(job.controller.signal);
      }
    }

    if (pending.length && !job.controller.signal.aborted && Date.now() >= deadline && pendingTask) {
      pendingTask.autoRecoveryExhausted = true;
      await queuePersistHistoryState();
    }
    return {
      attempted: recoverableOutcomes.length,
      recovered: recoverableOutcomes.length - pending.length,
      lastError
    };
  };

  let outcomes = [];
  try {
    try {
      const baselinePayload = await fetchGenerationHistory(job.apiKey, job.controller.signal);
      job.historyBaselineKeys = new Set(
        extractHistoryRecords(baselinePayload).map(historyRecordKey).filter(Boolean)
      );
      await updatePendingHistoryTask(job);
    } catch (error) {
      job.historyBaselineError = error;
    }

    outcomes = await Promise.all(
      Array.from(
        { length: job.requestedCount },
        (_, index) => runConcurrentRequest(index)
      )
    );

    const recoverableOutcomes = outcomes.filter(historyRecoverableOutcome);
    if (recoverableOutcomes.length && !job.controller.signal.aborted) {
      recoverySummary = await recoverFromHistory(recoverableOutcomes);
    }
  } catch (error) {
    if (!(isAbortError(error) && job.controller.signal.aborted)) {
      unexpectedError = error;
      job.controller.abort();
      job.requestControllers.forEach((requestController) => requestController.abort());
    }
  }

  const stopped = job.controller.signal.aborted;
  const failures = outcomes.filter((outcome) => !outcome.ok);
  const firstFailure = failures.length ? failures[0] : null;
  const unresolvedHistory = failures.filter(historyRecoverableOutcome);
  let statusKind = "success";
  let statusTitle = "任务 " + job.sequence + " 已完成";
  let statusDetail = hasPhotoshopDocument(job.snapshot)
    ? "点击生成历史选择图片，再点击“插入图层”"
    : "点击生成历史选择图片，再点击“在 PS 中打开”";

  if (unexpectedError) {
    statusKind = job.completedCount > 0 ? "warning" : "error";
    statusTitle = job.completedCount > 0
      ? "任务 " + job.sequence + " 已保留 " + job.completedCount + " 张"
      : "任务 " + job.sequence + " 运行异常";
    statusDetail = unexpectedError.message || unexpectedError;
  } else if (stopped) {
    statusKind = "warning";
    statusTitle = "任务 " + job.sequence + " 已停止，保留 " + job.completedCount + " 张";
    statusDetail = job.completedCount > 0
      ? "已完成的图片仍可在历史中选择并" + completedAction
      : "已经提交的请求不保证能在服务端取消或退费";
  } else if (job.completedCount === job.requestedCount) {
    statusKind = "success";
    statusTitle = recoverySummary.recovered > 0
      ? "任务 " + job.sequence + " 已完成，历史找回 " + recoverySummary.recovered + " 张"
      : "任务 " + job.sequence + " 已并发生成 " + job.completedCount + " 张";
    statusDetail = (returnedMultiple ? "接口个别响应包含多张，插件每次保留第一张；" : "") +
      (recoverySummary.recovered > 0 ? "断线结果已找回，没有重新生成；" : "") + "结果已进入生成历史";
  } else if (job.completedCount > 0) {
    statusKind = "warning";
    statusTitle = "任务 " + job.sequence + " 已生成 " + job.completedCount + " / " + job.requestedCount + " 张";
    statusDetail = unresolvedHistory.length
      ? "还有 " + unresolvedHistory.length + " 张暂未从历史找到；插件没有重新生成，请稍后到 API 历史中查看。已找回或成功的图片仍可" + completedAction
      : (firstFailure && firstFailure.error ? firstFailure.error.message || firstFailure.error : "部分请求未完成") + "；成功结果仍可选择并" + completedAction;
  } else if (firstFailure && firstFailure.error && firstFailure.error.httpStatus === 401) {
    statusKind = "error";
    statusTitle = "API Key 无效";
    statusDetail = "本机保存的旧密钥已清除；下次运行会重新要求输入";
  } else if (unresolvedHistory.length) {
    statusKind = "warning";
    statusTitle = "任务 " + job.sequence + " 暂未从历史找到结果";
    statusDetail = "生成请求没有重发，也不会再次扣费生成。服务端可能仍在处理，请稍后查询最近 3 天的 API 历史" +
      (recoverySummary.lastError ? "；最后一次查询提示：" + String(recoverySummary.lastError.message || recoverySummary.lastError) : "");
  } else if (firstFailure && firstFailure.responseReceived) {
    statusKind = "warning";
    statusTitle = "图片已返回，但本地处理失败";
    statusDetail = String(firstFailure.error.message || firstFailure.error) + "；请勿立即重复付费生成";
  } else {
    statusKind = "error";
    statusTitle = "任务 " + job.sequence + " 生成失败";
    statusDetail = firstFailure && firstFailure.error ? String(firstFailure.error.message || firstFailure.error) : "接口请求未完成";
  }

  if (job.priceUnverified) {
    statusDetail = String(statusDetail) + "；本次实时价格未确认，实际费用请以服务端账单为准";
  }

  job.status = stopped ? "stopped" : (job.completedCount > 0 ? "complete" : "failed");
  job.progressCompleting = true;
  job.visualProgress = Math.min(96, Math.max(8, Number(job.visualProgress) || 8));
  renderGenerationQueue();
  await waitForGenerationProgressFrame();
  job.progressCompleting = false;
  job.visualProgress = 100;
  updateGenerationProgressVisuals();
  await waitForGenerationProgressCompletion();
  try {
    await releaseGenerationJobReferences(job);
  } catch (error) {
    statusKind = "warning";
    statusDetail = String(statusDetail) + "；临时参考图稍后由宿主释放";
  }

  const pendingTask = pendingTaskForJob(job);
  if (pendingTask) {
    if (pendingHistoryOutstandingCount(pendingTask) > 0) {
      await updatePendingHistoryTask(job);
    } else {
      await removePendingHistoryTask(pendingTask);
      job.pendingHistoryTask = null;
    }
  }

  const jobIndex = state.generationJobs.indexOf(job);
  if (jobIndex >= 0) state.generationJobs.splice(jobIndex, 1);
  state.running = state.generationJobs.length > 0;
  renderGenerationQueue();
  if (!state.inserting) setStatus(statusKind, statusTitle, statusDetail);
  updateControls();
}

async function handleRun() {
  if (state.preparingJob || state.capturing || state.inserting) return;
  if (state.generationJobs.length >= MAX_ACTIVE_JOBS) {
    setStatus("warning", "并发任务已满", "最多同时保留 " + MAX_ACTIVE_JOBS + " 个生成任务");
    return;
  }

  const prompt = getPromptValue().trim();
  if (!prompt) {
    setStatus("error", "缺少提示词", "请描述你希望如何修改当前参考图");
    elements.prompt.focus();
    return;
  }
  if (!state.references.length) {
    setStatus("error", "没有参考图", "请获取 Photoshop 选区、图层或全图，或点击“＋”导入本机图片");
    return;
  }
  const snapshot = getGenerationSnapshot();
  if (!snapshot) {
    setStatus("error", "缺少主参考图", "请重新获取或导入一张有效参考图");
    return;
  }
  const localEditMode = selectedLocalEditMode();
  const requestPrompt = buildLocalEditPrompt(prompt, snapshot, localEditMode);
  if (!state.apiKey) {
    setStatus("warning", "需要 API Key", "请在弹出的本地密钥窗口中填写一次");
    showKeyDialog(true);
    return;
  }

  state.preparingJob = true;
  updateControls();
  const modelConfig = getSelectedModelConfig();
  let preparedJob = null;
  setStatus(
    "working",
    "正在核对实时价格",
    `${modelConfig.shortLabel} · ${elements.resolution.value} × ${getGenerationCount()} 张；核对完成前不会发送付费请求`
  );
  try {
    const priceCheck = await verifyLivePricingBeforeRun();
    if (!priceCheck.ok) {
      setStatus("warning", priceCheck.title, priceCheck.detail);
      return;
    }
    const checkedEstimate = normalizePriceValue(priceCheck.estimatedCost);
    const priceSummary = checkedEstimate === null
      ? "当前价格无法查询"
      : `预计 ${formatYuan(checkedEstimate)}${priceCheck.priceUnverified ? "（未核实）" : ""}`;
    setStatus(
      priceCheck.priceUnverified ? "warning" : "working",
      priceCheck.priceUnverified ? "实时价格未确认，已按二次点击继续" : "正在建立生成任务",
      `${priceCheck.size} × ${getGenerationCount()} 张，${priceSummary}；${snapshot.mode === "import" ? "正在保存主导入图和参考图" : "正在保存本次选区和参考图"}`
    );
    const references = state.references.slice();
    const requestedCount = getGenerationCount();
    const requested = resolveModelOutputSize(
      elements.aspectRatio.value,
      elements.resolution.value,
      snapshot.bounds.width,
      snapshot.bounds.height,
      modelConfig
    );
    requested.model = modelConfig.apiModel;
    requested.modelLabel = modelConfig.shortLabel;
    let totalUploadBytes = 0;
    for (const reference of references) {
      const metadata = await reference.file.getMetadata();
      totalUploadBytes += Number(metadata.size) || 0;
    }
    if (totalUploadBytes > API_CONFIG.maxUploadBytes) {
      throw new Error("全部参考图合计超过 64 MB，请删除部分参考图或缩小获取区域");
    }

    saveSettings();
    state.generationJobSequence += 1;
    const jobId = "job-" + Date.now() + "-" + state.generationJobSequence;
    const jobCreatedAt = new Date();
    const job = {
      id: jobId,
      sequence: state.generationJobSequence,
      prompt,
      requestPrompt,
      model: modelConfig.apiModel,
      modelLabel: modelConfig.shortLabel,
      snapshot,
      references,
      imageFiles: references.map((reference) => reference.file),
      apiKey: state.apiKey,
      requested,
      requestedCount,
      aspectRatio: elements.aspectRatio.value,
      resolution: elements.resolution.value,
      precisionPlacement: hasSmartLocalTarget(snapshot) ? true : elements.precisionPlacement.checked,
      localEditMode,
      unitPrice: priceCheck.unitPrice,
      estimatedCost: priceCheck.estimatedCost,
      priceUnverified: Boolean(priceCheck.priceUnverified),
      priceWarning: String(priceCheck.priceWarning || ""),
      completedCount: 0,
      failedCount: 0,
      settledCount: 0,
      recoveredCount: 0,
      historyBaselineKeys: new Set(),
      historyBaselineError: null,
      imageFingerprints: new Set(),
      status: "running",
      controller: new AbortController(),
      requestControllers: [],
      autoSelect: state.generationJobs.length === 0,
      selectionRevisionAtStart: state.selectionRevision,
      visualProgress: 8,
      progressCompleting: false,
      createdAt: jobCreatedAt
    };
    preparedJob = job;
    job.taskArchive = {
      id: jobId,
      sequence: job.sequence,
      prompt,
      model: job.model,
      modelLabel: job.modelLabel,
      snapshot,
      references: references.slice(),
      requested,
      generationCount: requestedCount,
      aspectRatio: job.aspectRatio,
      resolution: job.resolution,
      precisionPlacement: job.precisionPlacement,
      localEditMode: job.localEditMode,
      createdAt: jobCreatedAt,
      historyOwners: 0
    };
    await registerPendingHistoryTask(job);
    retainGenerationJobReferences(job);
    job.generationReferencesRetained = true;
    state.generationJobs.push(job);
    state.running = true;
    renderGenerationQueue();
    setStatus(
      job.priceUnverified ? "warning" : "working",
      "任务 " + job.sequence + (job.priceUnverified ? " 已开始（价格未确认）" : " 已进入并发生成区"),
      `${job.modelLabel} · ${priceCheck.size} × ${requestedCount} 张，${priceSummary}；可继续提交下一张图；断线时会自动查询历史，不会重发生成请求`
    );
    runGenerationJob(job).catch(async (error) => {
      job.controller.abort();
      job.requestControllers.forEach((requestController) => requestController.abort());
      try {
        await releaseGenerationJobReferences(job);
      } catch (_) {
        // Host cleanup will release any remaining temporary reference.
      }
      const pendingTask = pendingTaskForJob(job);
      if (pendingTask) {
        if (pendingHistoryOutstandingCount(pendingTask) > 0) await updatePendingHistoryTask(job);
        else await removePendingHistoryTask(pendingTask);
      }
      const jobIndex = state.generationJobs.indexOf(job);
      if (jobIndex >= 0) state.generationJobs.splice(jobIndex, 1);
      state.running = state.generationJobs.length > 0;
      renderGenerationQueue();
      setStatus("error", "并发任务异常结束", error.message || error);
      updateControls();
    });
    preparedJob = null;
  } catch (error) {
    if (preparedJob) {
      const jobIndex = state.generationJobs.indexOf(preparedJob);
      if (jobIndex >= 0) state.generationJobs.splice(jobIndex, 1);
      if (preparedJob.generationReferencesRetained) {
        try {
          await releaseGenerationJobReferences(preparedJob);
        } catch (_) {
          // References still shown in the panel remain owned by the panel.
        }
      }
      const pendingTask = pendingTaskForJob(preparedJob);
      if (pendingTask && pendingHistoryOutstandingCount(pendingTask) <= 0) {
        await removePendingHistoryTask(pendingTask);
      }
    }
    setStatus("error", "无法建立生成任务", error.message || error);
  } finally {
    state.preparingJob = false;
    updateControls();
  }
}

function handleStop() {
  const stopGeneration = state.generationJobs.some((job) => !job.controller.signal.aborted);
  const stopHistory = Boolean(
    state.recoveringPendingHistory && pendingHistoryRecoveryController &&
    !pendingHistoryRecoveryController.signal.aborted
  );
  if (!stopGeneration && !stopHistory) return;
  if (stopHistory) {
    state.pendingHistoryRecoveryStopRequested = true;
    pendingHistoryRecoveryController.abort();
  }
  setStatus(
    "warning",
    stopGeneration && stopHistory
      ? "正在停止生成和历史查询"
      : (stopHistory ? "正在停止历史查询" : "正在停止并发任务"),
    stopHistory
      ? "未找回的任务记录会保留；下次打开插件还会继续查询"
      : "正在取消所有未完成的客户端请求"
  );
  state.generationJobs.forEach((job) => {
    job.status = "stopping";
    job.requestControllers.forEach((requestController) => requestController.abort());
    job.controller.abort();
  });
  renderGenerationQueue();
  updateControls();
}

async function handleInsert() {
  const result = getSelectedResult();
  if (!result || state.inserting || state.capturing) return;
  const generationInProgress = state.running;
  state.inserting = true;
  updateControls();
  if (!hasPhotoshopDocument(result.snapshot)) {
    setStatus(
      "working",
      "正在 Photoshop 中打开生成图",
      generationInProgress ? "其他图片会继续并发生成" : "将生成好的原图打开为新的 Photoshop 文档"
    );
    try {
      await openResultInPhotoshop(result);
      result.openedAt = new Date();
      await queuePersistHistoryState();
      renderResultHistory();
      setStatus(
        state.running ? "working" : "success",
        state.running ? "生成图已打开，其他图片仍在生成" : "生成图已在 Photoshop 中打开",
        "打开的是接口返回的原始生成图，不会使用或覆盖当前 Photoshop 图层"
      );
    } catch (error) {
      setStatus("error", "打开生成图失败", error.message || error);
    } finally {
      state.inserting = false;
      updateControls();
    }
    return;
  }
  const supportsPrecisePlacement = hasPhotoshopTarget(result.snapshot);
  const precise = hasSmartLocalTarget(result.snapshot)
    ? true
    : (
      supportsPrecisePlacement
        ? (
          result.insertedAt && typeof result.precisePlacement === "boolean"
            ? result.precisePlacement
            : elements.precisionPlacement.checked
        )
        : false
    );
  setStatus(
    "working",
    "正在插入图层",
    generationInProgress
      ? "其他图片会继续并发生成；当前选中结果正在插入"
      : (precise ? "将精确适配并放回生成时保存的原选区" : "将按生成尺寸居中放到目标区域")
  );
  try {
    const inserted = await insertResult(result, precise);
    result.insertedAt = new Date();
    result.precisePlacement = precise;
    await queuePersistHistoryState();
    renderResultHistory();
    const placementNote = inserted.placedAboveAnchor
      ? "已放在生成时活动图层的上方"
      : "原活动图层无法定位，新图层保留在文档顶部";
    const maskNote = precise
      ? `${inserted.selectionCleared ? "活动选区已取消，图片未被裁切；" : ""}${inserted.preservedResolution ? "已用智能对象保留生成图清晰度；" : ""}${inserted.featherRadius ? `边缘已向内柔化 ${inserted.featherRadius}px；` : ""}${inserted.maskFocused ? "蒙版已选中，可直接细修" : "已创建可编辑蒙版"}`
      : "";
    const smartObjectNote = !precise && inserted.preservedResolution
      ? "已用智能对象保留生成图清晰度"
      : "";
    setStatus(
      state.running ? "working" : "success",
      state.running ? "图层已插入，其他图片仍在生成" : "图层已插入",
      precise
        ? `已精确放回原选区；${placementNote}；${maskNote}`
        : `已按生成尺寸居中插入；${placementNote}${smartObjectNote ? `；${smartObjectNote}` : ""}`
    );
  } catch (error) {
    setStatus("error", "插入失败", error.message || error);
  } finally {
    state.inserting = false;
    updateControls();
  }
}

function bindEvents() {
  let draggedReferenceId = null;
  let suppressReferenceMention = false;
  const clearReferenceDragStyles = () => {
    const children = elements.referenceList.children || [];
    for (let index = 0; index < children.length; index += 1) {
      children[index].classList.remove("is-dragging", "is-drop-target");
    }
  };

  const capture = (mode) => async () => {
    try {
      await captureSource(mode);
    } catch (_) {
      // captureSource already reports a concise error.
    }
  };

  elements.statusClose.addEventListener("click", hideStatus);
  elements.pluginVersion.addEventListener("click", () => {
    (async () => {
      if (!state.updateAvailable) {
        const available = await checkForPluginUpdate(true);
        if (!available) return;
      }
      await launchPluginUpdater();
    })().catch((error) => {
      setStatus("error", "无法启动更新", error.message || error);
    });
  });
  elements.captureSelection.addEventListener("click", capture("selection"));
  elements.captureLayer.addEventListener("click", capture("layer"));
  elements.captureCanvas.addEventListener("click", capture("canvas"));
  elements.referenceAdd.addEventListener("click", () => {
    importReferenceImages().catch((error) => {
      setStatus("error", "无法导入图片", error.message || error);
    });
  });
  elements.clearReferences.addEventListener("click", clearAllReferences);
  elements.referenceList.addEventListener("mousedown", freezePromptSelectionCapture);
  elements.referenceList.addEventListener("click", (event) => {
    let target = event.target;
    while (target && target !== elements.referenceList) {
      const referenceId = target.getAttribute && target.getAttribute("data-reference-id");
      if (referenceId) {
        event.preventDefault();
        event.stopPropagation();
        removeReference(referenceId).catch((error) => {
          setStatus("error", "无法删除参考图", error.message || error);
        });
        return;
      }
      const promptReferenceId = target.getAttribute && target.getAttribute("data-reference-prompt-id");
      if (promptReferenceId) {
        if (suppressReferenceMention) {
          suppressReferenceMention = false;
          return;
        }
        insertReferenceMention(promptReferenceId);
        return;
      }
      target = target.parentNode;
    }
  });
  elements.referenceList.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    const referenceId = event.target && event.target.getAttribute
      ? event.target.getAttribute("data-reference-id")
      : null;
    if (!referenceId) return;
    event.preventDefault();
    event.stopPropagation();
    removeReference(referenceId).catch((error) => {
      setStatus("error", "无法删除参考图", error.message || error);
    });
  });

  elements.referenceList.addEventListener("dragstart", (event) => {
    if (state.preparingJob || state.capturing || state.inserting) {
      event.preventDefault();
      return;
    }
    let target = event.target;
    while (target && target !== elements.referenceList) {
      const referenceId = target.getAttribute && target.getAttribute("data-reference-drag-id");
      if (referenceId) {
        draggedReferenceId = referenceId;
        suppressReferenceMention = true;
        target.classList.add("is-dragging");
        try {
          event.dataTransfer.effectAllowed = "move";
          event.dataTransfer.setData("text/plain", referenceId);
        } catch (_) {
          // UXP can expose drag events without the full browser DataTransfer API.
        }
        return;
      }
      target = target.parentNode;
    }
  });
  elements.referenceList.addEventListener("dragover", (event) => {
    if (!draggedReferenceId) return;
    let target = event.target;
    while (target && target !== elements.referenceList) {
      const referenceId = target.getAttribute && target.getAttribute("data-reference-drag-id");
      if (referenceId && referenceId !== draggedReferenceId) {
        event.preventDefault();
        clearReferenceDragStyles();
        target.classList.add("is-drop-target");
        return;
      }
      target = target.parentNode;
    }
  });
  elements.referenceList.addEventListener("drop", (event) => {
    if (!draggedReferenceId) return;
    let target = event.target;
    while (target && target !== elements.referenceList) {
      const referenceId = target.getAttribute && target.getAttribute("data-reference-drag-id");
      if (referenceId) {
        event.preventDefault();
        swapReferences(draggedReferenceId, referenceId);
        break;
      }
      target = target.parentNode;
    }
    draggedReferenceId = null;
    clearReferenceDragStyles();
  });
  elements.referenceList.addEventListener("dragend", () => {
    draggedReferenceId = null;
    clearReferenceDragStyles();
    setTimeout(() => {
      suppressReferenceMention = false;
    }, 0);
  });

  elements.prompt.addEventListener("focus", () => {
    promptHasFocus = true;
    schedulePromptSelectionCapture(true);
  });
  elements.prompt.addEventListener("blur", () => {
    promptHasFocus = false;
    promptPointerActive = false;
    freezePromptSelectionCapture();
  });
  elements.prompt.addEventListener("mousedown", () => {
    freezePromptSelectionCapture();
    promptPointerActive = true;
  });
  elements.prompt.addEventListener("mouseup", (event) => {
    rememberPromptPointerSelection(event);
    promptPointerActive = false;
  });
  elements.prompt.addEventListener("click", (event) => {
    rememberPromptPointerSelection(event);
  });
  elements.prompt.addEventListener("select", () => {
    const selection = rememberPromptSelection();
    if (selection) promptSelectionFreezeUntil = Date.now() + 350;
  });
  elements.prompt.addEventListener("keyup", () => {
    promptSelectionFreezeUntil = 0;
    rememberPromptSelection();
  });
  elements.prompt.addEventListener("input", () => {
    promptSelectionFreezeUntil = 0;
    rememberPromptSelection();
    updatePromptCount();
  });
  elements.prompt.addEventListener("change", () => {
    promptSelectionFreezeUntil = 0;
    rememberPromptSelection();
    updatePromptCount();
  });
  document.addEventListener("selectionchange", () => {
    if (promptHasFocus || promptPointerActive) schedulePromptSelectionCapture();
  });
  elements.prompt.addEventListener("keydown", (event) => {
    if (event.isComposing) return;
    if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
      event.preventDefault();
      handleRun();
    }
  });
  elements.promptLibrary.addEventListener("change", applyPromptLibrarySelection);
  elements.favoritePrompt.addEventListener("click", toggleFavoritePrompt);
  elements.capturePaletteSample.addEventListener("click", () => {
    capturePaletteSample().catch((error) => setStatus("error", "获取参考衣服失败", error.message || error));
  });
  elements.applyPaletteMatch.addEventListener("click", () => {
    applyPaletteMatch().catch((error) => setStatus("error", "衣服颜色匹配失败", error.message || error));
  });
  elements.clearPaletteSample.addEventListener("click", clearPaletteSample);
  elements.modelChannel.addEventListener("change", () => {
    resetPricingStateForModel();
    syncModelCapabilities();
    loadCachedPricing();
    updateResolvedSize();
    saveSettings();
    const model = getSelectedModelConfig();
    setStatus("working", `正在刷新 ${model.shortLabel} 价格`, "价格确认完成前仍可编辑参考图和提示词");
    refreshLivePricing("model-change").then((result) => {
      if (!result || result.stale || selectedApiModel() !== model.apiModel) return;
      if (result.ok) {
        setStatus("success", `已切换到 ${model.shortLabel}`, "运行时会使用该渠道，并按该模型的实时价格核对");
      } else {
        setStatus("warning", `${model.shortLabel} 价格暂时无法查询`, "仍可在运行时按二次确认继续生成");
      }
    }).catch(() => {});
  });
  elements.aspectRatio.addEventListener("change", () => {
    if (elements.aspectRatio.value === "auto") {
      elements.resolution.value = "1K";
    }
    updateResolvedSize();
    saveSettings();
  });
  elements.resolution.addEventListener("change", () => {
    updateResolvedSize();
    saveSettings();
  });
  elements.generationCount.addEventListener("change", () => {
    updateResolvedSize();
    saveSettings();
  });
  elements.localEditMode.addEventListener("change", () => {
    const snapshot = getGenerationSnapshot();
    if (snapshot && snapshot.mode === "selection") snapshot.localEditMode = selectedLocalEditMode();
    renderReferences();
    saveSettings();
    setStatus(
      "success",
      `已切换为${localEditModeLabel(selectedLocalEditMode())}`,
      snapshot && snapshot.mode === "selection"
        ? "运行时会保护选区外内容；若想使用该模式专用的周边范围，可重新获取一次选区"
        : "获取 Photoshop 选区后会自动带入周边衔接参考"
    );
  });
  elements.precisionPlacement.addEventListener("change", () => {
    const result = getSelectedResult();
    if (result && result.insertedAt && hasPhotoshopTarget(result.snapshot)) {
      result.precisePlacement = elements.precisionPlacement.checked;
      renderSelectedResult();
      queuePersistHistoryState();
    }
    saveSettings();
  });
  elements.run.addEventListener("click", handleRun);
  elements.stop.addEventListener("click", handleStop);
  elements.insert.addEventListener("click", handleInsert);
  elements.resultHistory.addEventListener("click", (event) => {
    let target = event.target;
    while (target && target !== elements.resultHistory) {
      const restoreId = target.getAttribute && target.getAttribute("data-result-restore");
      if (restoreId) {
        event.preventDefault();
        event.stopPropagation();
        fillHistoryTask(restoreId).catch((error) => {
          setStatus("error", "无法复用历史任务", error.message || error);
        });
        return;
      }
      const deleteId = target.getAttribute && target.getAttribute("data-result-delete");
      if (deleteId) {
        event.preventDefault();
        event.stopPropagation();
        removeResult(deleteId).catch((error) => {
          setStatus("error", "无法删除历史图", error.message || error);
        });
        return;
      }
      const resultId = target.getAttribute && target.getAttribute("data-result-id");
      if (resultId) {
        selectResult(resultId);
        return;
      }
      target = target.parentNode;
    }
  });
  elements.resultHistory.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    const restoreId = event.target && event.target.getAttribute
      ? event.target.getAttribute("data-result-restore")
      : null;
    if (restoreId) {
      event.preventDefault();
      event.stopPropagation();
      fillHistoryTask(restoreId).catch((error) => {
        setStatus("error", "无法复用历史任务", error.message || error);
      });
      return;
    }
    const deleteId = event.target && event.target.getAttribute
      ? event.target.getAttribute("data-result-delete")
      : null;
    if (deleteId) {
      event.preventDefault();
      event.stopPropagation();
      removeResult(deleteId).catch((error) => {
        setStatus("error", "无法删除历史图", error.message || error);
      });
      return;
    }
    const resultId = event.target && event.target.getAttribute
      ? event.target.getAttribute("data-result-id")
      : null;
    if (resultId) {
      event.preventDefault();
      selectResult(resultId);
    }
  });

  elements.cancelKey.addEventListener("click", () => {
    state.resumeAfterKey = false;
    hideKeyDialog();
    setStatus("idle", "已取消密钥输入", "没有发送生成请求");
  });
  elements.saveKey.addEventListener("click", async () => {
    const key = getKeyInputValue();
    if (!key) {
      elements.keyError.textContent = "请输入 API Key";
      elements.keyInput.focus();
      return;
    }
    elements.saveKey.disabled = true;
    elements.cancelKey.disabled = true;
    try {
      await saveApiKey(key);
      state.pendingHistoryTasks.forEach((task) => {
        task.autoRecoveryExhausted = false;
        task.autoRecoveryStartedAt = 0;
      });
      await queuePersistHistoryState();
      const resume = state.resumeAfterKey;
      state.resumeAfterKey = false;
      hideKeyDialog();
      setStatus("success", "API Key 已安全保存", resume ? "正在继续刚才的生成任务" : "可以开始运行");
      if (resume) await handleRun();
      if (pendingTasksForStartupRecovery().length && !state.recoveringPendingHistory) {
        recoverPendingHistoryTasksOnStartup().catch((error) => {
          if (!isAbortError(error)) setStatus("warning", "历史任务查询已暂停", error.message || error);
        });
      }
    } catch (error) {
      elements.keyError.textContent = sanitizeMessage(error.message || error);
    } finally {
      elements.saveKey.disabled = false;
      elements.cancelKey.disabled = false;
    }
  });
  elements.keyInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      elements.saveKey.click();
    }
    if (event.key === "Escape") elements.cancelKey.click();
  });

  window.addEventListener("focus", () => {
    if (Date.now() - Number(state.pricing.fetchedAt || 0) >= PRICING_REFRESH_MS / 2) {
      refreshLivePricing("focus").catch(() => {});
    }
  });
  window.addEventListener("resize", scheduleReferenceTileLayout);
  window.addEventListener("resize", scheduleNotificationLayout);
  window.addEventListener("scroll", scheduleNotificationLayout);

  window.addEventListener("unload", () => {
    if (pricingRefreshTimer !== null) clearInterval(pricingRefreshTimer);
    if (promptSelectionCaptureTimer !== null) clearTimeout(promptSelectionCaptureTimer);
    if (referenceLayoutTimer !== null) clearTimeout(referenceLayoutTimer);
    if (notificationLayoutTimer !== null) clearTimeout(notificationLayoutTimer);
    if (generationProgressTimer !== null) clearInterval(generationProgressTimer);
    if (statusHideTimer !== null) clearTimeout(statusHideTimer);
    if (pendingHistoryRecoveryController) pendingHistoryRecoveryController.abort();
    state.generationJobs.forEach((job) => {
      job.requestControllers.forEach((requestController) => requestController.abort());
      job.controller.abort();
    });
    state.references.forEach(revokeReferencePreview);
    state.results.forEach(revokeResultPreview);
  });
}

async function initialize() {
  cacheElements();
  initializeIslandSelects();
  loadSettings();
  loadCachedPricing();
  loadUpdateCheckCache();
  bindEvents();
  renderPaletteMatchControls();
  updatePromptCount();
  renderReferences();
  renderResultHistory();
  renderGenerationQueue();
  syncNotificationLayout();
  updateControls();
  await loadPersistentHistoryState();
  await loadApiKey();
  startPricingAutoRefresh();
  refreshLivePricing("startup").catch(() => {});
  if (state.historyPersistenceError) {
    setStatus("warning", "本地生成历史读取不完整", state.historyPersistenceError);
  } else if (state.results.length) {
    setStatus("success", `已恢复 ${state.results.length} 张生成历史`, "可直接查看；重新打开原 Photoshop 文档后也能继续插入");
  } else {
    setStatus("idle", "准备就绪", "可获取 Photoshop 选区、图层或全图，也可点击“＋”导入图片");
  }
  if (pendingTasksForStartupRecovery().length) {
    if (state.apiKey) {
      recoverPendingHistoryTasksOnStartup().catch((error) => {
        if (!isAbortError(error)) setStatus("warning", "历史任务查询已暂停", error.message || error);
      });
    } else {
      setStatus("warning", "有上次未显示的生成图片", "下次输入 API Key 后会自动查询历史，不会重新生成");
    }
  }
  const updateCheckDue = Date.now() - state.updateLastCheckedAt >= UPDATE_CONFIG.automaticCheckIntervalMs;
  if (updateCheckDue) {
    setTimeout(() => {
      checkForPluginUpdate(false).catch(() => {});
    }, 2500);
  }
}

initialize().catch((error) => {
  if (elements.status) setStatus("error", "插件初始化失败", error.message || error);
});

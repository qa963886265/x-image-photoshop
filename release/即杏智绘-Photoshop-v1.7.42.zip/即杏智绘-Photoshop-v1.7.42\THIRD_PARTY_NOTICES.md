# Third-party notices

## animal-island-ui

- Project: `guokaigdg/animal-island-ui`
- Source: https://github.com/guokaigdg/animal-island-ui
- Creator: guokaigdg
- License: Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)
- Upstream revision used: `3541a72`

This non-commercial internal Photoshop plugin includes adapted local copies of the following project resources:

- `src/assets/img/icons/icon-leaf.png`
- `src/assets/img/cursor/cursor-icon.png`
- `src/assets/img/dividers/divider-line-brown.svg`
- `demo/img/content_bg_pc.jpg`
- Visual styling and interaction patterns adapted from `src/components/Input/input.module.less`, `src/components/Select/select.module.less`, `src/components/Switch/switch.module.less`, `src/components/Radio/radio.module.less`, `src/components/Button/button.module.less`, and the project Notification component

The resources were renamed or reorganized only as needed for local Photoshop UXP loading. The surrounding plugin interface was adapted to plain HTML and CSS so it can run without React, npm, external scripts, or network-loaded fonts. The upstream web fonts are not used because Photoshop UXP does not support `@font-face`; the plugin uses locally installed system fonts instead.

The complete upstream license text is included at:

`assets/animal-island-ui/LICENSE.txt`

This plugin and its bundled animal-island-ui resources are intended only for personal or internal non-commercial use. They must not be sold, redistributed as a paid product, or used in a commercial service without obtaining suitable permission from the original rights holder.

animal-island-ui is an independent project and is not an official Nintendo product. This plugin does not claim endorsement by animal-island-ui, its creator, Nintendo, or Adobe.
